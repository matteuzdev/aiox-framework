# Changelog

All notable changes to GOWA CLI will be documented in this file.

Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
adhering to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.6.0] — 2026-03-23

### Added
- `gowa group list` — List all joined WhatsApp groups with `--name` filter and `--limit`
- `gowa group info <jid>` — Show group details with `--members` and `--role` filter
- `gowa group create <name>` — Create groups with optional `--members`
- `gowa group leave <jid>` — Leave a group (requires `--accept-risk`)
- `gowa group invite-link <jid>` — Get/reset group invite link
- `gowa group join <link>` — Join group via invite link or code
- Group-specific rate limiting: 5/hour, 20/day for create/join operations
- New exit codes: 3 (not_found), 4 (permission_error)
- GroupManager interface for testable group operations
- Group-specific error translation (permission denied, not found, group full)
- Validation helpers: ValidateGroupJID, ValidateGroupName, ParseInviteCode

## [0.5.0] - 2026-03-23

### Added
- Incoming message persistence — daemon saves all received messages to SQLite msgstore
- Robust reconnect with handlers for all whatsmeow events (LoggedOut, TemporaryBan, StreamReplaced, etc.)
- Circuit breaker integration in daemon (5 failures/30min → 30min cooldown via AutoReconnectHook)
- Graceful shutdown with session persistence (container.Close flushes WAL, 5s handler drain, 10s hard deadline)
- `chat messages --since/--until/--search` filters now work at daemon level (were silently ignored)
- Rate limiter enforced at daemon RPC level (prevents bypass via direct socket access)
- `safety.rate-status` RPC method — query remaining rate limit quotas
- Log rotation via lumberjack (5MB max, 3 backups)
- SafeGo panic recovery on all daemon goroutines (with stack traces)
- State corruption auto-recovery (renames to .corrupted, resets to empty, logs to audit)
- Phone validation accepts `+` prefix, `@lid` JIDs (WhatsApp LID migration), and `@g.us` group JIDs
- `chat unread` command — list chats with unread messages
- `chat read` command — mark a chat as read
- `chat search` command — full-text search across all messages (FTS5)
- `contact list` command — list WhatsApp contacts
- `contact search` command — search contacts by name or phone
- E2E test battery (`tests/e2e-test.sh`) — 46 automated tests
- Architecture map documentation (`docs/architecture-map.md`)
- `gowa.tools.json` v0.5.0 — complete agent discovery manifest with all commands
- LID error detection with actionable recovery hint
- `SaveState()` now calls fsync before rename (crash safety)
- Connection status tracking (atomic): connected, reconnecting, banned, logged_out, keepalive_failing
- `daemon status` shows circuit breaker state and connection status

### Changed
- whatsmeow updated to v0.0.0-20260322 (latest)
- Validation errors now return exit code 2 (was 1)
- `--dry-run` initializes config so `risk_accepted` is respected
- `recoverPanic` in server now captures `debug.Stack()` stack traces
- README rewritten with complete command reference and safety documentation

### Removed
- `CheckRateLimit()` — superseded by atomic `CheckAndRecordSend()`
- `RecordSend()` — deprecated, replaced by `CheckAndRecordSend()`
- `UpdateLastMessage()` — covered by `UpsertChat()`
- `BindFlag()` — unused config method
- `message.search` RPC — duplicate of `chat.search`
- `prd.json`, `prompt.md`, `.antigravity/` — internal dev artifacts

### Fixed
- `ValidatePhone` was stripping JID suffix letters (`@s.whatsapp.net` → `@..`)
- `Server.Shutdown()` now drains in-flight RPC handlers (WaitGroup + 5s timeout)
- `ConnectFailure` events now record to circuit breaker
- Git history rewritten to use GitHub noreply email (privacy)

## [0.4.0] - 2026-03-21

### Added
- Embedded WhatsApp engine (whatsmeow) — no more Docker/REST dependency
- `gowa pair` command — QR code or phone number pairing
- `gowa daemon start|stop|status|logs` — background daemon management
- `gowa logout` command — clean WhatsApp unlink + session cleanup
- Local SQLite message store (`messages.db`)
- Circuit breaker for WhatsApp connection
- Token-based authentication for daemon Unix socket
- Structured JSON logging for daemon

### Changed
- Architecture: single binary with embedded WhatsApp (was REST API wrapper)
- `chat list` and `chat messages` now use daemon RPC (was REST API)
- `device status` now uses daemon RPC (was REST API)
- Error type moved from `internal/client` to `internal/clierr`
- Go minimum version: 1.25 (was 1.24)

### Removed
- REST API dependency (Docker, GOWA server no longer needed)
- `gowa auth login|status|logout` commands
- `gowa api` raw API escape hatch
- `gowa device list` and `gowa device login` (replaced by `gowa pair`)
- HTTP client (`internal/client/`)
- Basic auth handler (`internal/auth/`)
- REST services (`internal/service/{send,device,chat}.go`)
- Config keys: `api_url`, `username`, `password`

## [0.3.0] - 2026-03-19

### Added
- `--dry-run` flag for all send commands (preview without sending)
- `--to-file` flag for batch sending (one phone per line, 2s delay)
- `--timeout` global flag for configurable HTTP timeout (default 30s)
- `GOWA_RISK_ACCEPTED` environment variable support
- `GOWA_TIMEOUT` environment variable support
- Structured JSON error output on stderr when `--json` is active
- `FilterFields()` API for output field filtering
- `gowa.tools.json` machine-readable skill manifest for AI agent discovery
- Missing source files: main.go, auth module, formatter, JSON output, device/chat services

### Changed
- Renamed `--url` to `--api-url` in `auth login` (old flag deprecated but still works)
- "No results found" message now prints to stderr instead of stdout
- JSON formatter outputs `[]` for empty results instead of `null`
- Module path migrated from `github.com/synkra/gowa-cli` to `github.com/murilloimparavel/gowa-cli`

## [0.2.0] - 2026-03-19

### Added
- Rate limiter with persistent state (3/min, 30/hr, 200/day)
- `--accept-risk` gate for send operations
- Input validation: phone (E.164/JID), file path, file extension, RFC3339 dates
- Audit log at `~/.config/gowa/audit.log` (JSON Lines, 1MB rotation)
- Shell completions: `gowa completion bash|zsh|fish|powershell`
- Stdin pipe support: `echo "msg" | gowa send text --to NUMBER`
- Exit code 6 for rate limits (local + HTTP 429)
- Unit tests for client, output, and safety modules (76.5% coverage)

### Fixed
- Defer leak in HTTP client retry loop (connection leak)
- Duplicate flag definitions in send command
- `json.Unmarshal` errors silently ignored in auth and device commands

### Changed
- Unified output via Formatter in all commands (consistent --json/--quiet)
- POST `/send/*` operations no longer retry (prevents duplicate messages)

## [0.1.0] - 2026-03-18

### Added
- `gowa auth login|status|logout` — authentication management
- `gowa device list|use|login` — WhatsApp device management
- `gowa send text|image|file` — message sending
- `gowa chat messages` — chat history with date filters
- `gowa api` — raw API escape hatch
- `gowa version` — version information
- Configuration via `~/.config/gowa/config.yaml`
- HTTP client with retry and exponential backoff
- Output formatters: JSON, table, quiet
- Colored terminal output with `--no-color` option

[Unreleased]: https://github.com/murilloimparavel/gowa-cli/compare/v0.6.0...HEAD
[0.6.0]: https://github.com/murilloimparavel/gowa-cli/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/murilloimparavel/gowa-cli/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/murilloimparavel/gowa-cli/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/murilloimparavel/gowa-cli/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/murilloimparavel/gowa-cli/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/murilloimparavel/gowa-cli/releases/tag/v0.1.0
