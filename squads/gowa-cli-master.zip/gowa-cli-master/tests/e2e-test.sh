#!/bin/bash
# =================================================================
# GOWA CLI — End-to-End Test Battery v0.5.0
# =================================================================
# Prerequisitos:
#   1. Build: go build -o gowa .
#   2. Pair:  ./gowa pair  (escanear QR ou usar --phone)
#   3. Rodar: bash tests/e2e-test.sh [NUMERO_DESTINO]
#
# O NUMERO_DESTINO é o WhatsApp para enviar msgs de teste.
# Se não informado, testes de envio são pulados.
# =================================================================

set -euo pipefail

GOWA="./gowa"
DEST="${1:-}"
PASS=0
FAIL=0
SKIP=0
RESULTS=()

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

test_pass() {
  PASS=$((PASS + 1))
  RESULTS+=("${GREEN}PASS${NC} $1")
  echo -e "  ${GREEN}✓${NC} $1"
}

test_fail() {
  FAIL=$((FAIL + 1))
  RESULTS+=("${RED}FAIL${NC} $1 — $2")
  echo -e "  ${RED}✗${NC} $1 — $2"
}

test_skip() {
  SKIP=$((SKIP + 1))
  RESULTS+=("${YELLOW}SKIP${NC} $1 — $2")
  echo -e "  ${YELLOW}○${NC} $1 — $2"
}

run_test() {
  local name="$1"
  local cmd="$2"
  local expect_exit="${3:-0}"

  local output
  local exit_code=0
  output=$(eval "$cmd" 2>&1) || exit_code=$?

  if [[ "$exit_code" -eq "$expect_exit" ]]; then
    test_pass "$name"
  else
    test_fail "$name" "exit=$exit_code (expected $expect_exit): $(echo "$output" | head -3)"
  fi

  echo "$output" > /dev/null  # suppress
}

run_test_json() {
  local name="$1"
  local cmd="$2"

  local output
  local exit_code=0
  output=$(eval "$cmd" 2>&1) || exit_code=$?

  if [[ "$exit_code" -ne 0 ]]; then
    test_fail "$name" "exit=$exit_code"
    return
  fi

  # Verify valid JSON
  if echo "$output" | jq empty 2>/dev/null; then
    test_pass "$name"
  else
    test_fail "$name" "output is not valid JSON"
  fi
}

run_test_contains() {
  local name="$1"
  local cmd="$2"
  local needle="$3"

  local output
  local exit_code=0
  output=$(eval "$cmd" 2>&1) || exit_code=$?

  if echo "$output" | grep -q "$needle"; then
    test_pass "$name"
  else
    test_fail "$name" "output missing '$needle'"
  fi
}

# ─────────────────────────────────────────────
# Pre-flight
# ─────────────────────────────────────────────

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════${NC}"
echo -e "${CYAN}  GOWA CLI — E2E Test Battery v0.5.0${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════${NC}"
echo ""

if [[ ! -x "$GOWA" ]]; then
  echo -e "${RED}ERROR: $GOWA not found or not executable${NC}"
  echo "  Run: go build -o gowa ."
  exit 1
fi

if [[ -n "$DEST" ]]; then
  echo -e "  Destination: ${CYAN}$DEST${NC}"
else
  echo -e "  Destination: ${YELLOW}(not set — send tests will be skipped)${NC}"
  echo "  Usage: bash tests/e2e-test.sh 5511999999999"
fi
echo ""

# ─────────────────────────────────────────────
# 1. BASIC CLI
# ─────────────────────────────────────────────

echo -e "${CYAN}[1/8] Basic CLI${NC}"

run_test "version" "$GOWA version"
run_test "version --json" "$GOWA version --json"
run_test "version --quiet" "$GOWA version --quiet"
run_test "completion bash" "$GOWA completion bash > /dev/null"
run_test "help" "$GOWA --help"
run_test "unknown command exits 1" "$GOWA nonexistent" 1

echo ""

# ─────────────────────────────────────────────
# 2. DAEMON MANAGEMENT
# ─────────────────────────────────────────────

echo -e "${CYAN}[2/8] Daemon Management${NC}"

# Check if session exists
if [[ ! -f "$HOME/.config/gowa/session.db" ]]; then
  echo -e "  ${RED}No session.db found!${NC}"
  echo "  Run: $GOWA pair"
  echo "  Then re-run this test."
  exit 1
fi
test_pass "session.db exists"

# Start daemon (if not running)
DAEMON_RUNNING=false
if $GOWA daemon status > /dev/null 2>&1; then
  DAEMON_RUNNING=true
  test_pass "daemon already running"
else
  echo -e "  Starting daemon..."
  $GOWA daemon start 2>/dev/null || true
  sleep 3
  if $GOWA daemon status > /dev/null 2>&1; then
    DAEMON_RUNNING=true
    test_pass "daemon start"
  else
    test_fail "daemon start" "daemon failed to start after 3s"
  fi
fi

if $DAEMON_RUNNING; then
  run_test "daemon status" "$GOWA daemon status"
  run_test_json "daemon status --json" "$GOWA daemon status --json"
  run_test_contains "daemon status shows connected" "$GOWA daemon status --json" "whatsapp_connected"
  run_test "daemon logs" "$GOWA daemon logs"
fi

echo ""

# ─────────────────────────────────────────────
# 3. DEVICE
# ─────────────────────────────────────────────

echo -e "${CYAN}[3/8] Device${NC}"

if $DAEMON_RUNNING; then
  run_test "device status" "$GOWA device status"
  run_test_json "device status --json" "$GOWA device status --json"
  run_test_contains "device is connected" "$GOWA device status --json" "connected"
else
  test_skip "device status" "daemon not running"
fi

echo ""

# ─────────────────────────────────────────────
# 4. CONTACTS
# ─────────────────────────────────────────────

echo -e "${CYAN}[4/8] Contacts${NC}"

if $DAEMON_RUNNING; then
  run_test "contact list" "$GOWA contact list"
  run_test_json "contact list --json" "$GOWA contact list --json"
  run_test "contact list --limit 5" "$GOWA contact list --limit 5"
  run_test "contact search 'a'" "$GOWA contact search a"
  run_test_json "contact search --json" "$GOWA contact search a --json"
else
  test_skip "contacts" "daemon not running"
fi

echo ""

# ─────────────────────────────────────────────
# 5. CHATS
# ─────────────────────────────────────────────

echo -e "${CYAN}[5/8] Chats${NC}"

if $DAEMON_RUNNING; then
  run_test "chat list" "$GOWA chat list"
  run_test_json "chat list --json" "$GOWA chat list --json"
  run_test "chat list --limit 3" "$GOWA chat list --limit 3"
  run_test "chat unread" "$GOWA chat unread"
  run_test_json "chat unread --json" "$GOWA chat unread --json"
  run_test "chat search 'oi'" "$GOWA chat search oi"
  run_test_json "chat search --json" "$GOWA chat search oi --json"

  # Get first chat JID for message tests (retry once after 2s if empty)
  FIRST_CHAT=$(${GOWA} chat list --json --limit 1 2>/dev/null | jq -r '.[0].jid // empty' 2>/dev/null || echo "")
  if [[ -z "$FIRST_CHAT" ]]; then
    echo -e "  ${YELLOW}Retrying chat list in 2s...${NC}"
    sleep 2
    FIRST_CHAT=$(${GOWA} chat list --json --limit 1 2>/dev/null | jq -r '.[0].jid // empty' 2>/dev/null || echo "")
    if [[ -z "$FIRST_CHAT" ]]; then
      echo -e "  ${YELLOW}WARNING: Could not extract first chat JID after retry${NC}"
    fi
  fi
  if [[ -n "$FIRST_CHAT" ]]; then
    run_test "chat messages (first chat)" "$GOWA chat messages '$FIRST_CHAT' --limit 5"
    run_test_json "chat messages --json" "$GOWA chat messages '$FIRST_CHAT' --limit 5 --json"
    run_test "chat read" "$GOWA chat read '$FIRST_CHAT'"
  else
    test_skip "chat messages" "no chats found"
  fi
else
  test_skip "chats" "daemon not running"
fi

echo ""

# ─────────────────────────────────────────────
# 6. SEND (requires DEST)
# ─────────────────────────────────────────────

echo -e "${CYAN}[6/8] Send${NC}"

if [[ -z "$DEST" ]]; then
  test_skip "send text" "no destination number provided"
  test_skip "send --dry-run" "no destination number provided"
  test_skip "send via stdin" "no destination number provided"
elif ! $DAEMON_RUNNING; then
  test_skip "send" "daemon not running"
else
  # Dry run first (no actual send)
  run_test "send text --dry-run" "$GOWA send text --to $DEST --dry-run --accept-risk 'E2E dry run test'"
  run_test_json "send text --dry-run --json" "$GOWA send text --to $DEST --dry-run --accept-risk --json 'E2E dry run test'"

  # Actual send
  TIMESTAMP=$(date +%H:%M:%S)
  run_test "send text (real)" "$GOWA send text --to $DEST --accept-risk 'Teste E2E gowa-cli v0.5.0 — $TIMESTAMP'"
  run_test_json "send text --json (real)" "$GOWA send text --to $DEST --accept-risk --json 'Teste JSON — $TIMESTAMP'"

  # Send via stdin
  run_test "send text via stdin" "echo 'Teste stdin — $TIMESTAMP' | $GOWA send text --to $DEST --accept-risk"

  # Validation tests (should fail with exit 2)
  run_test "send rejects short phone" "$GOWA send text --to 123 --accept-risk --dry-run 'test'" 2
  # Note: --accept-risk test only works before risk_accepted is persisted to config.
  # After first acceptance, config has risk_accepted=true so the gate always passes.
  # We test the flag parsing instead: verify --dry-run works without --accept-risk
  run_test "dry-run works without --accept-risk (config persisted)" "$GOWA send text --to $DEST --dry-run 'test'" 0

  echo ""
  echo -e "  ${YELLOW}⏳ Waiting 60s for rate limiter cooldown...${NC}"
  sleep 60
fi

echo ""

# ─────────────────────────────────────────────
# 7. SAFETY
# ─────────────────────────────────────────────

echo -e "${CYAN}[7/8] Safety & Rate Limiter${NC}"

if $DAEMON_RUNNING; then
  # Rate status (if daemon exposes it)
  run_test_json "daemon status has rate info" "$GOWA daemon status --json"

  # Validate phone format
  run_test "rejects invalid phone (too short)" "$GOWA send text --to 123 --accept-risk --dry-run 'x'" 2
  run_test "rejects empty message" "$GOWA send text --to $DEST --dry-run --accept-risk ''" 2  # empty string is invalid

  # Check state file exists after sends
  if [[ -f "$HOME/.config/gowa/state.json" ]]; then
    test_pass "state.json exists (rate limiter active)"
  else
    test_skip "state.json" "no sends executed yet"
  fi

  # Check audit log
  if [[ -f "$HOME/.config/gowa/audit.log" ]]; then
    test_pass "audit.log exists"
    AUDIT_LINES=$(wc -l < "$HOME/.config/gowa/audit.log")
    echo -e "    (${AUDIT_LINES} entries)"
  else
    test_skip "audit.log" "no sends executed yet"
  fi
else
  test_skip "safety" "daemon not running"
fi

echo ""

# ─────────────────────────────────────────────
# 8. OUTPUT MODES
# ─────────────────────────────────────────────

echo -e "${CYAN}[8/8] Output Modes${NC}"

if $DAEMON_RUNNING; then
  # Table (default)
  run_test "table output (contact list)" "$GOWA contact list --limit 2"

  # JSON
  run_test_json "json output (contact list)" "$GOWA contact list --limit 2 --json"

  # Quiet
  run_test "quiet output (version)" "$GOWA version --quiet"

  # Verify JSON errors go to stderr
  OUTPUT=$($GOWA chat messages "invalid@jid" --json 2>/dev/null) || true
  STDERR_OUTPUT=$($GOWA chat messages "invalid@jid" --json 2>&1 >/dev/null) || true
  if echo "$STDERR_OUTPUT" | jq empty 2>/dev/null; then
    test_pass "JSON errors on stderr"
  else
    test_skip "JSON errors on stderr" "no structured error returned"
  fi
else
  test_skip "output modes" "daemon not running"
fi

echo ""

# ─────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────

TOTAL=$((PASS + FAIL + SKIP))

echo -e "${CYAN}═══════════════════════════════════════════════${NC}"
echo -e "${CYAN}  RESULTS${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════${NC}"
echo ""

for r in "${RESULTS[@]}"; do
  echo -e "  $r"
done

echo ""
echo -e "${CYAN}───────────────────────────────────────────────${NC}"
echo -e "  ${GREEN}PASS: $PASS${NC}  ${RED}FAIL: $FAIL${NC}  ${YELLOW}SKIP: $SKIP${NC}  TOTAL: $TOTAL"
echo -e "${CYAN}───────────────────────────────────────────────${NC}"

if [[ $FAIL -gt 0 ]]; then
  echo ""
  echo -e "  ${RED}⚠ Some tests failed!${NC}"
  exit 1
else
  echo ""
  echo -e "  ${GREEN}All tests passed!${NC}"
  exit 0
fi
