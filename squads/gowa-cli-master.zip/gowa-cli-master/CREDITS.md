# CREDITS / CREDITOS / CREDITOS

---

## English

### Project

**GOWA CLI** — A command-line interface for the GOWA WhatsApp REST API.

- **Created by:** Murillo Imparavel ([@murilloimparavel](https://github.com/murilloimparavel))
- **AI-Assisted Development:** Built with [Claude Code](https://claude.ai) (Anthropic) — AI pair programming for architecture, implementation, testing, and documentation
- **Development Framework:** Orchestrated with [AIOS-Core](https://github.com/murilloimparavel/aios-core) — AI-Orchestrated System for agent-driven development workflows

### Core Dependencies

| Package | Description | License | Link |
|---------|-------------|---------|------|
| [github.com/spf13/cobra](https://github.com/spf13/cobra) | CLI framework | Apache 2.0 | [repo](https://github.com/spf13/cobra) |
| [github.com/spf13/viper](https://github.com/spf13/viper) | Configuration management | MIT | [repo](https://github.com/spf13/viper) |
| [github.com/fatih/color](https://github.com/fatih/color) | Terminal colors | MIT | [repo](https://github.com/fatih/color) |
| [github.com/mattn/go-isatty](https://github.com/mattn/go-isatty) | Terminal detection | MIT | [repo](https://github.com/mattn/go-isatty) |
| [github.com/gofrs/flock](https://github.com/gofrs/flock) | File locking | BSD-3-Clause | [repo](https://github.com/gofrs/flock) |

### Powered By

- **[GOWA (go-whatsapp-web-multidevice)](https://github.com/aldinokemal/go-whatsapp-web-multidevice)** — WhatsApp REST API server by **Aldino Kemal** ([@aldinokemal](https://github.com/aldinokemal)) — MIT License
- **[whatsmeow](https://github.com/tulir/whatsmeow)** — Go WhatsApp Web multidevice library by **tulir** ([@tulir](https://github.com/tulir)) — MPL-2.0 License
- **[Go](https://go.dev)** programming language

### Documentation

- Written with assistance from Claude Code Agent Teams
- Trilingual support: English, Portuguese (BR), Spanish

### Special Thanks

- **Aldino Kemal** — for creating and maintaining the GOWA REST API that makes this CLI possible
- **tulir** — for whatsmeow, the Go library powering GOWA's WhatsApp connectivity
- **[BMad](https://github.com/bmadcode/BMAD-METHOD)** — for the BMAD Method, the agent orchestration methodology that inspired AIOS-Core's architecture
- The Go community
- The Cobra/Viper ecosystem maintainers

---

## Portugues (BR)

### Projeto

**GOWA CLI** — Interface de linha de comando para a API REST GOWA do WhatsApp.

- **Criado por:** Murillo Imparavel ([@murilloimparavel](https://github.com/murilloimparavel))
- **Desenvolvimento Assistido por IA:** Construido com [Claude Code](https://claude.ai) (Anthropic) — programacao em par com IA para arquitetura, implementacao, testes e documentacao
- **Framework de Desenvolvimento:** Orquestrado com [AIOS-Core](https://github.com/murilloimparavel/aios-core) — Sistema Orquestrado por IA para workflows de desenvolvimento orientados por agentes

### Dependencias Principais

| Pacote | Descricao | Licenca | Link |
|--------|-----------|---------|------|
| [github.com/spf13/cobra](https://github.com/spf13/cobra) | Framework CLI | Apache 2.0 | [repo](https://github.com/spf13/cobra) |
| [github.com/spf13/viper](https://github.com/spf13/viper) | Gerenciamento de configuracao | MIT | [repo](https://github.com/spf13/viper) |
| [github.com/fatih/color](https://github.com/fatih/color) | Cores no terminal | MIT | [repo](https://github.com/fatih/color) |
| [github.com/mattn/go-isatty](https://github.com/mattn/go-isatty) | Deteccao de terminal | MIT | [repo](https://github.com/mattn/go-isatty) |
| [github.com/gofrs/flock](https://github.com/gofrs/flock) | Bloqueio de arquivos | BSD-3-Clause | [repo](https://github.com/gofrs/flock) |

### Alimentado Por

- **[GOWA (go-whatsapp-web-multidevice)](https://github.com/aldinokemal/go-whatsapp-web-multidevice)** — Servidor REST API do WhatsApp por **Aldino Kemal** ([@aldinokemal](https://github.com/aldinokemal)) — Licenca MIT
- **[whatsmeow](https://github.com/tulir/whatsmeow)** — Biblioteca Go para WhatsApp Web multidevice por **tulir** ([@tulir](https://github.com/tulir)) — Licenca MPL-2.0
- Linguagem de programacao **[Go](https://go.dev)**

### Documentacao

- Escrita com assistencia do Claude Code Agent Teams
- Suporte trilingue: Ingles, Portugues (BR), Espanhol

### Agradecimentos Especiais

- **Aldino Kemal** — por criar e manter a GOWA REST API que torna esta CLI possivel
- **tulir** — pelo whatsmeow, a biblioteca Go que alimenta a conectividade WhatsApp do GOWA
- **[BMad](https://github.com/bmadcode/BMAD-METHOD)** — pelo BMAD Method, a metodologia de orquestracao de agentes que inspirou a arquitetura do AIOS-Core
- A comunidade Go
- Os mantenedores do ecossistema Cobra/Viper

---

## Espanol

### Proyecto

**GOWA CLI** — Interfaz de linea de comandos para la API REST GOWA de WhatsApp.

- **Creado por:** Murillo Imparavel ([@murilloimparavel](https://github.com/murilloimparavel))
- **Desarrollo Asistido por IA:** Construido con [Claude Code](https://claude.ai) (Anthropic) — programacion en pareja con IA para arquitectura, implementacion, pruebas y documentacion
- **Framework de Desarrollo:** Orquestado con [AIOS-Core](https://github.com/murilloimparavel/aios-core) — Sistema Orquestado por IA para workflows de desarrollo orientados por agentes

### Dependencias Principales

| Paquete | Descripcion | Licencia | Enlace |
|---------|-------------|----------|--------|
| [github.com/spf13/cobra](https://github.com/spf13/cobra) | Framework CLI | Apache 2.0 | [repo](https://github.com/spf13/cobra) |
| [github.com/spf13/viper](https://github.com/spf13/viper) | Gestion de configuracion | MIT | [repo](https://github.com/spf13/viper) |
| [github.com/fatih/color](https://github.com/fatih/color) | Colores en terminal | MIT | [repo](https://github.com/fatih/color) |
| [github.com/mattn/go-isatty](https://github.com/mattn/go-isatty) | Deteccion de terminal | MIT | [repo](https://github.com/mattn/go-isatty) |
| [github.com/gofrs/flock](https://github.com/gofrs/flock) | Bloqueo de archivos | BSD-3-Clause | [repo](https://github.com/gofrs/flock) |

### Impulsado Por

- **[GOWA (go-whatsapp-web-multidevice)](https://github.com/aldinokemal/go-whatsapp-web-multidevice)** — Servidor REST API de WhatsApp por **Aldino Kemal** ([@aldinokemal](https://github.com/aldinokemal)) — Licencia MIT
- **[whatsmeow](https://github.com/tulir/whatsmeow)** — Biblioteca Go para WhatsApp Web multidevice por **tulir** ([@tulir](https://github.com/tulir)) — Licencia MPL-2.0
- Lenguaje de programacion **[Go](https://go.dev)**

### Documentacion

- Escrita con asistencia de Claude Code Agent Teams
- Soporte trilingue: Ingles, Portugues (BR), Espanol

### Agradecimientos Especiales

- **Aldino Kemal** — por crear y mantener la GOWA REST API que hace posible esta CLI
- **tulir** — por whatsmeow, la biblioteca Go que alimenta la conectividad WhatsApp de GOWA
- **[BMad](https://github.com/bmadcode/BMAD-METHOD)** — por el BMAD Method, la metodologia de orquestacion de agentes que inspiro la arquitectura de AIOS-Core
- La comunidad Go
- Los mantenedores del ecosistema Cobra/Viper
