# Security Policy | Politica de Seguranca | Politica de Seguridad

[English](#english) | [Portugues](#portugues) | [Espanol](#espanol)

---

## English

### Supported Versions

| Version | Supported |
|---------|-----------|
| 0.3.x   | Yes       |
| 0.2.x   | Yes       |
| < 0.2   | No        |

### Reporting a Vulnerability

**Do NOT open a public GitHub issue for security vulnerabilities.**

Please report security issues via email: **114107747+murilloimparavel@users.noreply.github.com**

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

### Response Timeline

- **Acknowledgment:** within 48 hours
- **Initial assessment:** within 7 days
- **Fix release:** within 30 days for critical issues

### What Qualifies as a Security Issue

- Credential exposure (config file permissions, log leakage)
- Rate limiter bypass
- Audit log tampering
- Command injection via input fields
- State file manipulation leading to safety bypass

### What Is NOT a Security Issue

- WhatsApp account bans (expected risk, documented)
- GOWA server vulnerabilities (report to GOWA project)
- Feature requests

### Responsible Disclosure

We follow responsible disclosure. We ask that you:
1. Report privately first
2. Allow reasonable time for a fix
3. Do not exploit the vulnerability beyond proof-of-concept

---

## Portugues

### Versoes Suportadas

| Versao | Suportada |
|--------|-----------|
| 0.3.x  | Sim       |
| 0.2.x  | Sim       |
| < 0.2  | Nao       |

### Reportando uma Vulnerabilidade

**NAO abra uma issue publica no GitHub para vulnerabilidades de seguranca.**

Reporte por email: **114107747+murilloimparavel@users.noreply.github.com**

Inclua:
- Descricao da vulnerabilidade
- Passos para reproduzir
- Impacto potencial
- Sugestao de correcao (se houver)

### Tempo de Resposta

- **Confirmacao:** em ate 48 horas
- **Avaliacao inicial:** em ate 7 dias
- **Correcao:** em ate 30 dias para issues criticas

### O Que Qualifica como Issue de Seguranca

- Exposicao de credenciais (permissoes de config, vazamento em logs)
- Bypass do rate limiter
- Adulteracao do audit log
- Injecao de comando via campos de input
- Manipulacao do state file para bypass de seguranca

### O Que NAO E Issue de Seguranca

- Banimento de conta WhatsApp (risco esperado, documentado)
- Vulnerabilidades do servidor GOWA (reporte ao projeto GOWA)
- Feature requests

---

## Espanol

### Versiones Soportadas

| Version | Soportada |
|---------|-----------|
| 0.3.x   | Si        |
| 0.2.x   | Si        |
| < 0.2   | No        |

### Reportar una Vulnerabilidad

**NO abra un issue publico en GitHub para vulnerabilidades de seguridad.**

Reporte por email: **114107747+murilloimparavel@users.noreply.github.com**

Incluya:
- Descripcion de la vulnerabilidad
- Pasos para reproducir
- Impacto potencial
- Sugerencia de correccion (si tiene)

### Tiempo de Respuesta

- **Confirmacion:** dentro de 48 horas
- **Evaluacion inicial:** dentro de 7 dias
- **Correccion:** dentro de 30 dias para issues criticas

### Que Califica como Issue de Seguridad

- Exposicion de credenciales (permisos de config, fuga en logs)
- Bypass del rate limiter
- Adulteracion del audit log
- Inyeccion de comando via campos de input
- Manipulacion del state file para bypass de seguridad

### Que NO Es Issue de Seguridad

- Baneo de cuenta WhatsApp (riesgo esperado, documentado)
- Vulnerabilidades del servidor GOWA (reporte al proyecto GOWA)
- Feature requests
