# GOWA CLI Tools Manifest

## What is `gowa.tools.json`?

A machine-readable skill manifest for the GOWA CLI (`gowa`). It describes every command, flag, exit code, output field, and safety constraint so that AI agents can discover and use the CLI without running `--help`.

## Location

```
projetos/gowa-cli/gowa.tools.json
```

## How to use the manifest

### 1. Discover available commands

Parse `commands[]` to find all available commands. Each entry includes:
- `name` — the full command (e.g. `"send text"`, `"auth login"`)
- `flags[]` — all flags with types, defaults, and whether required
- `args[]` — positional arguments (when present)
- `requires_auth` — whether the command needs authentication first
- `idempotent` — whether the command is safe to retry

### 2. Construct commands safely

Before building a command invocation:
1. Check `requires_auth` — if true, ensure `auth login` has been run
2. Check `flags[]` for any `required: true` flags
3. For send commands, ensure `--accept-risk` is included or `risk_accepted` is in config
4. Check `safety.rate_limits` to avoid exceeding thresholds

### 3. Parse output

- Use `--json` global flag for machine-readable output
- Reference `output_fields[]` to know which JSON keys to expect
- On error with `--json`, parse stderr for `{"error": true, "type": "...", "code": N, "message": "...", "recovery": "..."}`

### 4. Handle exit codes

Reference `exit_codes` at both the global level and per-command level:
- `0` — success
- `1` — general error
- `2` — bad input / usage error (check flags and arguments)
- `3` — auth error (run `gowa auth login`)
- `4` — not found (verify resource ID)
- `5` — server error (check if GOWA server is running)
- `6` — rate limited (wait and retry)

### 5. Respect safety constraints

The `safety` section defines:
- **Rate limits:** 3/min, 30/hr, 200/day — the CLI enforces these internally but agents should also track to avoid hitting them
- **Risk acceptance:** Send operations require explicit acknowledgment
- **Audit log:** All send operations are logged to `~/.config/gowa/audit.log`
- **Input validation:** Phone numbers must be E.164 (10-15 digits), dates must be RFC3339

## Example: Agent workflow

```bash
# 1. Authenticate
gowa auth login --url http://localhost:3000 --username admin --password secret --json

# 2. Select device
gowa device list --json
gowa device use 628xxx@s.whatsapp.net

# 3. Send message (with risk acceptance)
gowa send text --to 5511999999999 "Hello" --accept-risk --json

# 4. Check result
# Parse stdout JSON for {"message_id": "...", "status": "..."}
# On failure, parse stderr JSON and check exit code
```

## Keeping the manifest up to date

When adding or modifying commands in `cmd/*.go`:
1. Add/update the corresponding entry in `gowa.tools.json`
2. Ensure all flags, exit codes, output fields, and side effects are accurate
3. The manifest must match the actual source code — never invent features
