# Skill: GOWA CLI Usage

This skill teaches AI agents how to USE the gowa CLI to send WhatsApp messages and manage devices. This is for consumers of the CLI, not developers.

## Prerequisites

1. `gowa` binary in PATH
2. Paired with WhatsApp (one-time): `gowa pair` (interactive, scans QR code)
3. Daemon running: `gowa daemon start`
4. Risk accepted (first send only): add `--accept-risk` flag or set `risk_accepted: true` in config

No external server or Docker required. The CLI embeds WhatsApp connectivity directly via a background daemon.

## Setup Workflow (First Time)

```bash
# 1. Pair with WhatsApp (one-time, interactive — shows QR code in terminal)
gowa pair

# 2. Start the background daemon (maintains WhatsApp connection)
gowa daemon start

# 3. Verify everything is working
gowa daemon status
gowa device status

# Ready to send!
gowa send text --to 5511999999999 "Hello" --accept-risk
```

## Command Reference

### Pairing and Session

```bash
# Pair with WhatsApp (scan QR code — one-time setup)
gowa pair

# Logout (unlink WhatsApp session)
gowa logout

# Logout and purge all local data (config, state, audit, messages)
gowa logout --purge
```

### Daemon Management

```bash
# Start daemon (background, keeps WhatsApp connected)
gowa daemon start

# Start in foreground (for debugging)
gowa daemon start --foreground

# Stop daemon
gowa daemon stop

# Check daemon status
gowa daemon status
gowa daemon status --json

# View daemon logs
gowa daemon logs
gowa daemon logs --lines 100 --follow=false
```

### Device Management

```bash
# Check device connection status (requires daemon)
gowa device status
gowa device status --json

# Set default device JID (for multi-device scenarios)
gowa device use 628xxx@s.whatsapp.net
```

### Sending Messages

All send commands require `--accept-risk` on first use and a running daemon.

```bash
# Send text message
gowa send text --to 5511999999999 "Hello from CLI"

# Send with reply
gowa send text --to 5511999999999 "Reply to this" --reply MSG_ID

# Pipe message from stdin
echo "Hello from pipe" | gowa send text --to 5511999999999

# Send image
gowa send image --to 5511999999999 --file photo.jpg
gowa send image --to 5511999999999 --file photo.jpg --caption "Check this out"

# Send file/document
gowa send file --to 5511999999999 --file report.pdf
```

### Dry Run (Preview Without Sending)

```bash
# Preview what would be sent without actually sending
gowa send text --to 5511999999999 "Hello" --dry-run
gowa send image --to 5511999999999 --file photo.jpg --dry-run

# Combine with --json to inspect the request payload
gowa send text --to 5511999999999 "Hello" --dry-run --json
```

### Batch Sending with --to-file

```bash
# Send same message to all phones listed in a file (one per line, 2s delay)
gowa send text --to-file contacts.txt "Hello from batch"

# Combine with --dry-run to validate the file first
gowa send text --to-file contacts.txt "Hello" --dry-run

# contacts.txt format (one phone per line, E.164):
# 5511999999991
# 5511999999992
# 5511999999993
```

### Timeout for Slow Connections

```bash
# Increase timeout
gowa send text --to 5511999999999 "Hello" --timeout 60s

# Or via environment variable
export GOWA_TIMEOUT=60s
gowa send text --to 5511999999999 "Hello"
```

### Chat History

```bash
# List recent chats (requires daemon)
gowa chat list
gowa chat list --limit 20 --search "john"

# Get messages from a chat
gowa chat messages 5511999999999
gowa chat messages 5511999999999 --limit 50
gowa chat messages 5511999999999 --since 2024-01-15T00:00:00Z --until 2024-01-16T00:00:00Z
gowa chat messages GROUP_JID --search "keyword"
```

### Version and Completion

```bash
gowa version
gowa version --json

# Shell completions
source <(gowa completion bash)
gowa completion zsh > "${fpath[1]}/_gowa"
gowa completion fish | source
```

## Output Modes

All commands support three output modes:

| Flag | Mode | Use Case |
|------|------|----------|
| (none) | table | Human-readable, colored tables |
| --json | JSON | Machine-parseable, full data |
| --quiet | quiet | Bare primary value (ID, status) for scripting |

### JSON Output Parsing with jq

```bash
# Get message ID after sending
MSG_ID=$(gowa send text --to 5511999999999 "Hello" --json | jq -r '.message_id')

# Check daemon status
gowa daemon status --json | jq -r '.connected'

# Get unread chat count
gowa chat list --json | jq '[.[] | select(.unread_count > 0)] | length'
```

### Quiet Mode for Scripting

```bash
# Get just the message ID
MSG_ID=$(gowa send text --to 5511999999999 "Hello" --quiet)

# Get device status as bare value
gowa device status --quiet
```

## Exit Codes

Always check exit codes in scripts:

| Code | Meaning | Action |
|------|---------|--------|
| 0 | Success | Continue |
| 1 | General error / daemon not running | Check stderr; ensure `gowa daemon start` |
| 2 | Bad input / usage error | Fix flags or arguments |
| 5 | Connection / WhatsApp error | Check `gowa daemon status` |
| 6 | Rate limited | Wait and retry (see below) |
| 7 | Session expired | Run `gowa pair` again |

### JSON Error Parsing from stderr

When `--json` is active, errors are emitted as structured JSON on stderr:

```bash
# Capture structured error from stderr
ERROR=$(gowa send text --to "bad-phone" "Hello" --json 2>&1 1>/dev/null)
echo "$ERROR" | jq '.type'       # e.g. "usage_error"
echo "$ERROR" | jq '.recovery'   # e.g. "Use E.164 format: 5511999999999"

# In scripts, capture both stdout and stderr separately
RESULT=$(gowa send text --to "$PHONE" "$MSG" --json 2>/tmp/gowa-err.json)
if [ $? -ne 0 ]; then
  ERROR_TYPE=$(jq -r '.type' /tmp/gowa-err.json)
  RECOVERY=$(jq -r '.recovery' /tmp/gowa-err.json)
  echo "Error ($ERROR_TYPE): $RECOVERY"
fi
```

### Error Handling in Scripts

```bash
gowa send text --to "$PHONE" "$MESSAGE"
EXIT_CODE=$?

case $EXIT_CODE in
  0) echo "Sent successfully" ;;
  1) echo "Daemon not running" && gowa daemon start && gowa send text --to "$PHONE" "$MESSAGE" ;;
  5) echo "Connection error, check daemon" && gowa daemon status ;;
  6) echo "Rate limited, waiting..." && sleep 60 && gowa send text --to "$PHONE" "$MESSAGE" ;;
  7) echo "Session expired, need to re-pair" && gowa pair ;;
  *) echo "Failed with exit code $EXIT_CODE" ;;
esac
```

## Rate Limit Handling

GOWA CLI enforces local rate limits to protect WhatsApp accounts from bans:
- **3 messages per minute**
- **30 messages per hour**
- **200 messages per day**

### Rate-Limit-Aware Batch Sending

```bash
#!/bin/bash
# Send to a list of contacts with rate limit awareness
CONTACTS=("5511999999991" "5511999999992" "5511999999993")
MESSAGE="Hello from batch"

for PHONE in "${CONTACTS[@]}"; do
  gowa send text --to "$PHONE" "$MESSAGE"
  EXIT_CODE=$?

  if [ $EXIT_CODE -eq 6 ]; then
    echo "Rate limited. Waiting 60 seconds..."
    sleep 60
    gowa send text --to "$PHONE" "$MESSAGE"  # retry
  elif [ $EXIT_CODE -ne 0 ]; then
    echo "Failed to send to $PHONE (exit $EXIT_CODE)"
  fi

  # Respect rate limits: wait between sends
  sleep 21  # 3/min = 1 every 20s, add 1s buffer
done
```

### Batch Sending with --to-file (Recommended)

```bash
# Simpler alternative using built-in --to-file (handles delay automatically)
gowa send text --to-file contacts.txt "Hello from batch" --json > results.jsonl 2> errors.jsonl
```

## Pipe Patterns

```bash
# Generate message and pipe
date | gowa send text --to 5511999999999

# Multi-line message
cat <<'EOF' | gowa send text --to 5511999999999
Hello,
This is a multi-line message
sent from the CLI.
EOF

# Command output as message
df -h | gowa send text --to 5511999999999

# Forward a notification
echo "Build #${BUILD_ID} completed" | gowa send text --to 5511999999999
```

## Integration Examples

### CI/CD Notification

```bash
# In GitHub Actions / Jenkins / etc.
# Ensure daemon is running on the CI host, or use a persistent daemon host
export GOWA_RISK_ACCEPTED=true
gowa send text --to "$NOTIFY_PHONE" \
  "Deploy completed: $APP_NAME v$VERSION to $ENVIRONMENT"
```

### Cron Job Alert

```bash
# crontab entry (ensure daemon is running)
0 9 * * * /usr/local/bin/gowa send text --to 5511999999999 "Good morning! Daily report ready."
```

### Monitoring Alert

```bash
if ! curl -sf http://myapp.com/health > /dev/null; then
  gowa send text --to "$ONCALL_PHONE" \
    "ALERT: myapp.com health check failed at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
fi
```

### Chat Export

```bash
# Export chat to JSON file
gowa chat messages 5511999999999 --limit 1000 --json > chat-export.json

# Search across chats
gowa chat list --json | jq -r '.[].jid' | while read jid; do
  echo "=== $jid ==="
  gowa chat messages "$jid" --limit 5 --search "keyword" --json
done
```

## Global Flags (available on all commands)

| Flag | Description |
|------|-------------|
| --json | Output in JSON format |
| --quiet | Minimal output (bare values) |
| --device | Override default device JID |
| --no-color | Disable colored output |
| --accept-risk | Acknowledge unofficial API risks |
| --timeout | Request timeout (default 30s) |

## Environment Variables

Config values can be set via environment with `GOWA_` prefix:

```bash
export GOWA_DEVICE_ID=628xxx@s.whatsapp.net
export GOWA_RISK_ACCEPTED=true    # Skip risk prompt (for CI/CD)
export GOWA_TIMEOUT=60s           # Custom timeout
export GOWA_OUTPUT=json           # Default output format
```
