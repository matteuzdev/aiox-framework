# GOWA CLI — Claude Code Instructions

## Project Overview

GOWA CLI (`gowa`) is a Go command-line interface for WhatsApp with an embedded WhatsApp connection (whatsmeow). It provides agent-friendly, scriptable CLI commands with structured output (table, JSON, quiet modes). The CLI uses a background daemon to maintain the WhatsApp WebSocket connection.

- **Language:** Go 1.24+
- **CLI framework:** cobra + viper
- **Module:** `github.com/murilloimparavel/gowa-cli`
- **Config:** `~/.config/gowa/config.yaml` (YAML, viper-managed)
- **State:** `~/.config/gowa/state.json` (rate limit tracking)
- **Audit:** `~/.config/gowa/audit.log` (JSONL, send operation log)
- **Session:** `~/.config/gowa/session.db` (SQLite, whatsmeow session)
- **Messages:** `~/.config/gowa/messages.db` (SQLite, message store)

## Architecture

```
cmd/                    # Cobra command definitions (one file per command group)
  root.go               # Root command, RunContext, global flags (--json, --quiet, --device, --timeout)
  pair.go               # pair (QR code or phone number pairing)
  daemon.go             # daemon start | stop | status | logs
  send.go               # send text | image | file (requires --accept-risk; supports --dry-run, --to-file)
  device.go             # device status | use
  chat.go               # chat list | messages (via daemon RPC)
  logout.go             # logout [--purge] (unlink WhatsApp + cleanup)
  version.go            # version
  completion.go         # completion bash|zsh|fish|powershell
  group.go              # group list | info | create | leave | invite-link | join

internal/
  clierr/               # Shared error types
    errors.go           # CLIError type (Type, Code, Message, Recovery)
  config/
    config.go           # Viper-based config (device_id, output, risk_accepted, timeout)
  daemon/               # Background daemon (keeps WhatsApp connected)
    daemon.go           # Daemon lifecycle (Start, Stop, RunForeground)
    server.go           # JSON-RPC server over Unix socket
    client.go           # RPC client for commands to talk to daemon
    lock.go             # Paths, PID file, file locking, IsRunning, CleanStale
  whatsapp/             # whatsmeow wrapper (clean Go interface)
    client.go           # WaClient (Connect, SendText, SendImage, SendFile, Logout, etc.)
    errors.go           # wrapError maps whatsmeow errors to CLIError
    jid.go              # parseJID (phone number or JID string to types.JID)
    safe.go             # safeGo goroutine helper
  msgstore/             # SQLite message store for history
  safety/               # Safety layer (CRITICAL — protects WhatsApp accounts)
    validate.go         # ValidatePhone, ValidateFilePath, ValidateFileExtension, ValidateRFC3339
    ratelimit.go        # CheckRateLimit, CheckAndRecordSend
    audit.go            # AuditEntry, LogSendOperation, LogSendOperationTo
    state.go            # State persistence (JSON file with file locking via gofrs/flock)
  output/               # Output formatting (table, JSON, quiet)
    table.go            # TableFormatter — human-readable tabular output
    quiet.go            # QuietFormatter — bare values for scripting
    formatter.go        # Formatter interface, JSONFormatter, New() factory, AutoDetect()
    json.go             # FilterFields() for output field filtering
  service/              # Business logic layer
    messenger.go        # Messenger interface, DaemonMessenger, SendResult
```

## Development Commands

```bash
# Build
go build -o gowa .

# Run directly
go run . send text --to 5511999999999 "Hello"

# Test all packages
go test ./...

# Test specific package
go test ./internal/safety/...
go test ./internal/output/...

# Vet
go vet ./...

# Build with version info (release)
go build -ldflags "-X cmd.cliVersion=1.0.0 -X cmd.cliCommit=$(git rev-parse --short HEAD) -X cmd.cliDate=$(date -u +%Y-%m-%dT%H:%M:%SZ)" -o gowa .
```

## Code Conventions

### Error Handling — CLIError is mandatory
All user-facing errors MUST use `clierr.CLIError` with:
- `Type`: error category (usage_error, auth_error, daemon_error, whatsapp_error, etc.)
- `Code`: exit code (see Exit Codes below)
- `Message`: human-readable message
- `Recovery`: actionable hint for the user

When `--json` is active, CLIError is serialized as structured JSON to stderr (not stdout), so agents can parse errors programmatically.

```go
return &clierr.CLIError{
    Type:     "usage_error",
    Code:     2,
    Message:  "Bad request: invalid phone number",
    Recovery: "Use E.164 format: 5511999999999",
}
```

### Output — Always use Formatter
Never write directly to stdout in commands. Always use `runCtx.Formatter`:
- `Format(data, columns)` for lists/tables
- `FormatSingle(data)` for single objects
- `FilterFields(data, fields)` for selecting specific output fields (e.g., `--fields id,name`)

### Input Validation — Always use safety package
All user input MUST be validated before use:
- Phone numbers: `safety.ValidatePhone(phone)`
- File paths: `safety.ValidateFilePath(path)`
- File extensions: `safety.ValidateFileExtension(path, allowed)`
- Date strings: `safety.ValidateRFC3339(value, flagName)`

### Daemon RPC Pattern
Commands that need WhatsApp data use the daemon RPC client:
```go
resp, err := runCtx.DaemonClient.Call("chat.list", map[string]interface{}{
    "limit": 25,
})
```

### Cobra Command Structure
- One file per command group in `cmd/`
- Parent `PersistentPreRunE` must be called explicitly (Cobra does not chain them)
- Global flags defined in `root.go init()`
- Subcommand flags defined in their own `init()`
- Commands that bypass daemon: pair, daemon (start/stop/status/logs), version, logout

## Safety Rules — NON-NEGOTIABLE

These rules protect users from WhatsApp account bans. Never bypass them.

1. **Rate Limiter:** Never bypass or weaken rate limits (3/min, 30/hr, 200/day). Use `safety.CheckAndRecordSend()` for atomic check+record.
2. **Input Validation:** Always validate phone numbers, file paths, and dates before processing.
3. **Audit Log:** All send operations MUST be logged via `safety.LogSendOperation()`. The service layer handles this.
4. **Risk Acknowledgment:** Send operations require `--accept-risk` flag or `risk_accepted: true` in config. In CI/CD, set `GOWA_RISK_ACCEPTED=true`.
5. **Fail-Safe Recording:** Rate limit state is recorded BEFORE the send (fail-safe principle).
6. **File Locking:** State and audit files use `gofrs/flock` for concurrent access safety.
7. **Dry Run:** The `--dry-run` flag skips the actual send but still validates all inputs. It does NOT record to rate limiter or audit log.

## Exit Codes

| Code | Meaning | CLIError Type |
|------|---------|---------------|
| 0 | Success | — |
| 1 | General error / parse error / daemon not running | general, parse_error, daemon_error |
| 2 | Usage error / bad input | usage_error, conflict |
| 3 | Not found / group does not exist | not_found |
| 4 | Permission error / not admin | permission_error |
| 5 | Server error / connection error / WhatsApp error | server_error, whatsapp_error |
| 6 | Rate limited | rate_limit |
| 7 | Session expired (need re-pair) | auth_error |

## Testing Patterns

- Use `t.TempDir()` for temporary state/config files
- Use `bytes.Buffer` as writer for formatter tests
- Set `NO_COLOR=1` in table formatter tests for deterministic output
- Test both success and error paths for all commands

## Config and Environment Variables

Config file: `~/.config/gowa/config.yaml`

| Key | Env Var | Default | Description |
|-----|---------|---------|-------------|
| device_id | GOWA_DEVICE_ID | — | Default device JID |
| output | GOWA_OUTPUT | table | Default output format |
| risk_accepted | GOWA_RISK_ACCEPTED | false | Skip risk warning for send |
| timeout | GOWA_TIMEOUT | 30s | Request timeout |

## Common Tasks

### Adding a new command
1. Create `cmd/<group>.go` with cobra command definition
2. Add flags in `init()`
3. Call parent `PersistentPreRunE` if the parent has one
4. Use `runCtx.DaemonClient.Call()` for daemon RPC operations
5. Use `safety.Validate*` for all user input
6. Use `runCtx.Formatter` for all output
7. Return `*clierr.CLIError` for all error cases
8. Add tests

### Adding input validation
1. Add validator function to `internal/safety/validate.go`
2. Return descriptive error with expected format example
3. Call from command before any processing
