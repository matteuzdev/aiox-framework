# Contributing to GOWA CLI

> **PT-BR:** Guia de contribuicao disponivel abaixo em portugues.
> **ES:** Guia de contribucion disponible abajo en espanol.

---

## English

### Welcome

GOWA CLI is an open, inclusive project. We welcome contributions from everyone, regardless of experience level, background, or location. Whether you are fixing a typo, reporting a bug, suggesting a feature, or writing code, your contribution matters.

### How to Contribute

There are many ways to contribute:

- **Report bugs** -- Open an issue using the bug report template
- **Suggest features** -- Open an issue using the feature request template
- **Fix bugs** -- Pick an issue labeled `good first issue` or `bug`
- **Write code** -- Implement new features or improve existing ones
- **Improve docs** -- Fix typos, clarify instructions, add examples
- **Translate** -- Help make GOWA CLI accessible in more languages
- **Review PRs** -- Provide feedback on open pull requests

### Development Setup

**Prerequisites:**
- Go 1.24 or later
- Git
- A WhatsApp Business API endpoint (for integration testing)

**Steps:**

```bash
# 1. Fork the repository on GitHub

# 2. Clone your fork
git clone https://github.com/YOUR_USERNAME/gowa-cli.git
cd gowa-cli

# 3. Build
go build -o gowa .

# 4. Run tests
go test ./...

# 5. Verify code quality
go fmt ./...
go vet ./...
```

### Code Style

- Run `go fmt` on all code before committing
- Run `go vet` to catch common issues
- Follow existing patterns in the codebase
- Keep functions focused and well-named
- Add comments for non-obvious logic
- Error messages should be actionable and clear

### Commit Conventions

We use conventional commits:

| Prefix   | Use for                        |
|----------|--------------------------------|
| `feat:`  | New features                   |
| `fix:`   | Bug fixes                      |
| `docs:`  | Documentation changes          |
| `test:`  | Adding or updating tests       |
| `chore:` | Maintenance, dependencies, CI  |

Examples:
```
feat: add group message support
fix: handle empty phone number in send command
docs: add examples for config command
test: add coverage for rate limiter edge cases
chore: update Go dependencies
```

### Pull Request Process

1. **Fork** the repository
2. **Create a branch** from `master`: `git checkout -b feat/my-feature`
3. **Make your changes** with clear, atomic commits
4. **Run tests**: `go test ./...`
5. **Run lint**: `go fmt ./... && go vet ./...`
6. **Push** to your fork: `git push origin feat/my-feature`
7. **Open a PR** against `master` using the PR template
8. **Wait for review** -- maintainers will review and provide feedback

### Testing Requirements

- All new code must include tests
- Run the full test suite: `go test ./...`
- Check coverage: `go test -coverprofile=coverage.out ./... && go tool cover -func=coverage.out`
- Tests must pass before a PR will be merged
- Aim for meaningful coverage, not just line count

### Safety-First Rule

GOWA CLI enforces safety mechanisms to protect users and API endpoints:

- **Never bypass the rate limiter.** The rate limiter exists to protect both the user and the API. Do not add flags, environment variables, or code paths that skip rate limiting.
- **Always validate input.** Every user-facing input (phone numbers, file paths, dates) must be validated before use.
- **Respect the `--accept-risk` gate.** Dangerous operations require explicit user acknowledgment.
- **Audit logging is not optional.** Operations that send messages must be logged.

PRs that weaken safety mechanisms will not be merged.

### Issue Templates

When opening an issue, please use the provided templates:
- **Bug Report** -- For something that is broken or behaving unexpectedly
- **Feature Request** -- For new functionality or improvements

### Code of Conduct

This project follows the [Contributor Covenant Code of Conduct](CODE_OF_CONDUCT.md). By participating, you agree to uphold this code. Report unacceptable behavior to the maintainers.

---

## Portugues (PT-BR)

### Bem-vindo

GOWA CLI e um projeto aberto e inclusivo. Aceitamos contribuicoes de todos, independente do nivel de experiencia, origem ou localizacao. Seja corrigindo um erro de digitacao, reportando um bug, sugerindo uma funcionalidade ou escrevendo codigo, sua contribuicao importa.

### Como Contribuir

- **Reportar bugs** -- Abra uma issue usando o template de bug report
- **Sugerir funcionalidades** -- Abra uma issue usando o template de feature request
- **Corrigir bugs** -- Escolha uma issue com label `good first issue` ou `bug`
- **Escrever codigo** -- Implemente novas funcionalidades ou melhore as existentes
- **Melhorar documentacao** -- Corrija erros, melhore instrucoes, adicione exemplos
- **Traduzir** -- Ajude a tornar o GOWA CLI acessivel em mais idiomas
- **Revisar PRs** -- Forneca feedback em pull requests abertos

### Configuracao do Ambiente

**Pre-requisitos:**
- Go 1.24 ou superior
- Git

```bash
# 1. Faca um fork do repositorio no GitHub
# 2. Clone seu fork
git clone https://github.com/SEU_USUARIO/gowa-cli.git
cd gowa-cli

# 3. Build
go build -o gowa .

# 4. Rodar testes
go test ./...

# 5. Verificar qualidade
go fmt ./...
go vet ./...
```

### Convencoes de Commit

Usamos conventional commits: `feat:`, `fix:`, `docs:`, `test:`, `chore:`

### Regra de Seguranca

- **Nunca ignore o rate limiter.** Ele existe para proteger o usuario e a API.
- **Sempre valide inputs.** Telefones, caminhos de arquivo e datas devem ser validados.
- **Respeite o gate `--accept-risk`.** Operacoes perigosas exigem confirmacao explicita.

PRs que enfraquecem mecanismos de seguranca nao serao aceitos.

### Codigo de Conduta

Este projeto segue o [Contributor Covenant](CODE_OF_CONDUCT.md). Ao participar, voce concorda em respeitar este codigo.

---

## Espanol (ES)

### Bienvenido

GOWA CLI es un proyecto abierto e inclusivo. Aceptamos contribuciones de todos, sin importar el nivel de experiencia, origen o ubicacion. Ya sea corrigiendo un error tipografico, reportando un bug, sugiriendo una funcionalidad o escribiendo codigo, tu contribucion importa.

### Como Contribuir

- **Reportar bugs** -- Abre un issue usando el template de bug report
- **Sugerir funcionalidades** -- Abre un issue usando el template de feature request
- **Corregir bugs** -- Elige un issue con label `good first issue` o `bug`
- **Escribir codigo** -- Implementa nuevas funcionalidades o mejora las existentes
- **Mejorar documentacion** -- Corrige errores, mejora instrucciones, agrega ejemplos
- **Traducir** -- Ayuda a hacer GOWA CLI accesible en mas idiomas
- **Revisar PRs** -- Proporciona feedback en pull requests abiertos

### Configuracion del Entorno

**Prerrequisitos:**
- Go 1.24 o superior
- Git

```bash
# 1. Haz un fork del repositorio en GitHub
# 2. Clona tu fork
git clone https://github.com/TU_USUARIO/gowa-cli.git
cd gowa-cli

# 3. Build
go build -o gowa .

# 4. Ejecutar tests
go test ./...

# 5. Verificar calidad
go fmt ./...
go vet ./...
```

### Convenciones de Commit

Usamos conventional commits: `feat:`, `fix:`, `docs:`, `test:`, `chore:`

### Regla de Seguridad

- **Nunca ignores el rate limiter.** Existe para proteger al usuario y la API.
- **Siempre valida inputs.** Telefonos, rutas de archivo y fechas deben ser validados.
- **Respeta el gate `--accept-risk`.** Operaciones peligrosas requieren confirmacion explicita.

PRs que debiliten mecanismos de seguridad no seran aceptados.

### Codigo de Conducta

Este proyecto sigue el [Contributor Covenant](CODE_OF_CONDUCT.md). Al participar, aceptas respetar este codigo.
