# CLI vs MCP: Which Interface Should AI Agents Use?

> A technical comparison of Command-Line Interfaces and the Model Context Protocol for agentic workflows, with GOWA CLI as a case study.

---

## Table of Contents

- [English](#english)
- [Portugues (PT-BR)](#portugues-pt-br)
- [Espanol (ES)](#espanol-es)

---

# English

## 1. Introduction

As AI agents become the primary consumers of developer tools, a fundamental design question emerges: **how should an agent interact with external services?**

Two dominant patterns have emerged:

1. **CLI tools** -- the agent spawns a subprocess, passes arguments, reads stdout/stderr, and interprets exit codes.
2. **MCP servers** -- the agent connects to a Model Context Protocol server over JSON-RPC 2.0, discovering and invoking tools through a structured protocol.

Both approaches work. But they optimize for different things, and choosing the wrong one for your use case can mean unnecessary complexity, fragile integrations, or vendor lock-in.

This article breaks down the tradeoffs with concrete examples, using GOWA CLI (a WhatsApp CLI for AI agents) as a case study.

## 2. What is MCP?

The **Model Context Protocol (MCP)** is an open standard created by Anthropic for connecting AI applications to external systems. Think of it as "USB-C for AI" -- a universal plug that lets any AI host (Claude, ChatGPT, VS Code Copilot, Cursor) connect to any MCP server (databases, APIs, file systems).

### Architecture

MCP follows a client-server model with three participants:

- **MCP Host**: The AI application (e.g., Claude Desktop, VS Code) that orchestrates connections.
- **MCP Client**: A component inside the host that maintains a dedicated connection to one MCP server.
- **MCP Server**: A program that exposes tools, resources, and prompts to clients.

### Protocol Details

- Built on **JSON-RPC 2.0** for request/response communication.
- Supports two transports: **stdio** (local processes) and **Streamable HTTP** (remote servers with SSE).
- Starts with a **capability negotiation** handshake where client and server declare supported features.
- Servers expose three primitives: **Tools** (executable functions), **Resources** (data sources), and **Prompts** (interaction templates).
- Supports **real-time notifications** for dynamic updates (e.g., tool list changes).

### Example Flow

```
1. Client sends initialize request (protocol version, capabilities)
2. Server responds with its capabilities (tools, resources)
3. Client sends tools/list to discover available tools
4. Client sends tools/call with arguments to execute a tool
5. Server returns structured content (text, images, etc.)
```

MCP is powerful. It enables rich, bidirectional, stateful interactions. But that power comes with complexity.

## 3. What is an Agent-Friendly CLI?

An agent-friendly CLI is a command-line tool designed not just for humans typing in a terminal, but for **AI agents executing commands programmatically**. The key characteristics are:

- **Structured output modes**: `--json` for machine-readable output, `--quiet` for bare values.
- **Semantic exit codes**: Different exit codes for different failure types (auth error vs. rate limit vs. not found).
- **Stdin support**: Accept input via pipes, not just flags and arguments.
- **Predictable flag patterns**: Consistent `--flag value` syntax across all commands.
- **Self-documenting errors**: Error messages that include recovery hints.
- **No interactive prompts in non-TTY mode**: Detect when running as a subprocess and behave accordingly.

The pattern is battle-tested. Tools like `gh` (GitHub CLI), `kubectl`, `docker`, `terraform`, and `aws` have been agent-friendly for years -- long before the term "AI agent" became mainstream.

## 4. CLI Advantages for Agentic Code

### 4.1 Universal Compatibility

A CLI works with **every agent framework in existence**: Claude Code, OpenAI Codex, Google Gemini, Cursor, Windsurf, Cline, Aider, custom agents, shell scripts, cron jobs, CI/CD pipelines.

The interface is simple: spawn a process, pass arguments, read output.

```python
# Works in ANY language, ANY framework
result = subprocess.run(["gowa", "send", "text", "--to", "5511999999999", "--json", "Hello"], capture_output=True)
data = json.loads(result.stdout)
```

MCP requires the host to implement an MCP client, support JSON-RPC 2.0, handle capability negotiation, and maintain a persistent connection. Not every agent framework supports MCP, and those that do may have different levels of support.

### 4.2 No SDK Dependency

CLI tools need exactly one thing: the ability to spawn a subprocess. Every programming language has this built in.

MCP requires an SDK. While SDKs exist for TypeScript and Python, other languages may have incomplete or community-maintained implementations. Your agent code becomes coupled to the SDK version and its bugs.

### 4.3 Structured Exit Codes = Machine-Readable Error Handling

Exit codes are the oldest, most reliable error signaling mechanism in computing. An agent can branch on exit codes without parsing error messages:

```bash
gowa send text --to 5511999999999 "Hello" --json
case $? in
  0) echo "sent" ;;
  2) echo "bad input -- fix arguments" ;;
  3) echo "auth expired -- re-login" ;;
  5) echo "server down -- retry later" ;;
  6) echo "rate limited -- back off" ;;
esac
```

MCP errors come as JSON-RPC error objects. They are structured, but the agent must parse the response body to understand what happened. Exit codes are immediate and zero-overhead.

### 4.4 --json Flag = Structured Output Without Parsing Natural Language

The `--json` flag is the single most important feature for agent consumption. Instead of parsing human-friendly tables or prose, the agent gets a predictable JSON object:

```bash
# Human-friendly (default)
$ gowa device list
ID              NAME        STATUS
abc123@s.wa     My Phone    connected

# Machine-friendly (--json)
$ gowa device list --json
[{"id":"abc123@s.wa","name":"My Phone","status":"connected"}]
```

### 4.5 --quiet Flag = Minimal Output for Piping

Sometimes an agent only needs a single value, not a full JSON response. The `--quiet` flag extracts the primary field:

```bash
# Get just the message ID after sending
MSG_ID=$(gowa send text --to 5511999999999 "Hello" --quiet)
echo "Sent: $MSG_ID"
```

This is essential for composable pipelines where one command's output feeds another.

### 4.6 Stdin Support = Composable Pipelines

CLI tools that accept stdin enable powerful composition:

```bash
# Pipe a generated report into WhatsApp
python generate_report.py | gowa send text --to 5511999999999

# Send contents of a file
cat meeting_notes.txt | gowa send text --to 5511999999999
```

MCP tools accept arguments in the JSON-RPC call. There is no native concept of piping one MCP tool's output into another -- the host must orchestrate this manually.

### 4.7 Works Offline (No Server for the CLI Layer)

A CLI binary is self-contained. It runs on the machine, reads local config files, and calls APIs directly. There is no MCP server process to start, configure, or keep alive.

MCP requires a running server process. For local servers (stdio transport), this is lightweight. For remote servers (HTTP transport), you depend on network availability and server uptime.

### 4.8 Battle-Tested Pattern

The CLI-as-API pattern has decades of precedent:

| Tool | Agent-Friendly Features |
|------|------------------------|
| `gh` (GitHub) | `--json` output, `--jq` filtering, exit codes for API errors |
| `kubectl` | `-o json`, `-o jsonpath`, structured error messages |
| `docker` | `--format` with Go templates, JSON output, exit codes |
| `terraform` | `-json` plan output, machine-readable state files |
| `aws` | `--output json`, `--query` with JMESPath, exit codes |
| `jq` | Pure stdin/stdout pipeline tool, the glue of CLI composition |

Agents don't need to learn new paradigms. CLIs are the lingua franca of automation.

### 4.9 Security: Sandbox Isolation

A CLI runs in the user's sandbox. The agent framework controls what commands can be executed, which directories are accessible, and what network calls are allowed.

MCP servers, by contrast, run as separate processes with their own permissions. A local MCP server has access to the filesystem, network, and environment variables of the host machine. The security boundary is the server process, not the agent sandbox.

### 4.10 Debuggable: Reproduce Exactly

When an agent's CLI command fails, a developer can copy-paste the exact command and run it manually:

```bash
# Agent ran this and got exit code 3
gowa send text --to 5511999999999 "Hello" --json

# Developer runs the same command to debug
$ gowa send text --to 5511999999999 "Hello" --json
Authentication failed: token expired
  Hint: Run 'gowa auth login' to configure credentials
```

MCP interactions are harder to reproduce. You need to reconstruct the JSON-RPC request, connect to the server, and replay the call.

### 4.11 Versionable: No Server Drift

CLI versions are pinnable. An agent can depend on `gowa@1.2.3` and know exactly what behavior to expect. There is no server-side drift.

MCP servers can change their tool schemas, add or remove tools, or alter behavior between deployments. The `tools/list_changed` notification mechanism exists precisely because server-side drift is expected.

## 5. When MCP Makes More Sense

CLI is not universally superior. MCP has genuine advantages in specific scenarios:

| Scenario | Why MCP Wins |
|----------|-------------|
| **Real-time streaming** | MCP supports Server-Sent Events for streaming responses. CLIs must use polling or log tailing. |
| **Bidirectional communication** | MCP servers can request input from the user (elicitation) or ask the LLM for completions (sampling). CLIs are fire-and-forget. |
| **Complex state management** | MCP maintains a persistent connection with capability negotiation. Useful for database sessions, multi-step transactions, or workflows that require server-side state. |
| **Dynamic tool discovery** | MCP servers can add/remove tools at runtime and notify clients. CLI tools have a fixed command tree per version. |
| **Rich content types** | MCP responses can include images, embedded resources, and multi-part content. CLI output is text (or base64-encoded data). |
| **Multi-tenant remote services** | Remote MCP servers (Streamable HTTP) can serve many clients simultaneously with proper auth. CLIs are single-user by nature. |
| **Browser/IDE integration** | MCP servers integrate natively with Claude Desktop, VS Code, Cursor. No subprocess management needed. |

**The rule of thumb**: If your tool needs a persistent connection, streams data in real time, or requires the server to initiate communication, MCP is the better fit.

## 6. GOWA CLI as Case Study

GOWA CLI is a WhatsApp messaging tool built from the ground up to be consumed by AI agents. Here is how it implements each agent-friendly pattern:

### 6.1 --json for Structured Output

Every command supports `--json` as a global flag. The output is always a valid JSON object or array:

```bash
$ gowa send text --to 5511999999999 "Hello" --json
{"message_id":"3EB0A6F1234567890","status":"sent","timestamp":"2026-03-19T10:30:00Z"}

$ gowa device list --json
[{"id":"5511999999999@s.whatsapp.net","name":"Agent Phone","status":"connected"}]
```

The implementation uses a `Formatter` interface with `JSONFormatter`, `TableFormatter`, and `QuietFormatter` implementations. The `AutoDetect` function selects the format based on flags:

```go
format := output.AutoDetect(jsonFlag, quietFlag) // --json takes precedence
formatter := output.New(format, os.Stdout)
```

### 6.2 --quiet for Bare Values

The `--quiet` flag extracts the primary field from the response. The `QuietFormatter` has a priority list of fields to extract: `message_id`, `id`, `status`, `authenticated`, `cli_version`:

```bash
$ gowa send text --to 5511999999999 "Hello" --quiet
3EB0A6F1234567890

$ gowa auth status --quiet
true
```

This makes it trivial for agents to capture a single value without JSON parsing.

### 6.3 Semantic Exit Codes

GOWA CLI uses a `CLIError` type that maps HTTP status codes and error conditions to specific exit codes:

| Exit Code | Meaning | HTTP Status | Agent Action |
|-----------|---------|-------------|-------------|
| 0 | Success | 2xx | Continue |
| 1 | General error | Other | Log and report |
| 2 | Usage/input error | 400, 409 | Fix arguments |
| 3 | Authentication error | 401, 403 | Re-authenticate |
| 4 | Not found | 404 | Verify resource ID |
| 5 | Server error | 5xx | Retry with backoff |
| 6 | Rate limited | 429 | Wait and retry |

Every error includes a `Recovery` hint that tells the agent (or human) exactly what to do next:

```go
&CLIError{
    Type:     "rate_limit",
    Code:     6,
    Message:  "Rate limited by server",
    Recovery: "Wait a moment and try again",
}
```

### 6.4 Stdin Pipe for Message Content

The `send text` command accepts message content via stdin when no positional argument is provided. It detects non-TTY mode automatically:

```bash
# Agent can pipe dynamically generated content
echo "Your order #1234 is confirmed" | gowa send text --to 5511999999999

# Or use heredoc for multi-line
gowa send text --to 5511999999999 <<'EOF'
Meeting summary:
- Discussed Q2 roadmap
- Action items assigned
EOF
```

The implementation uses `go-isatty` to detect whether stdin is a terminal or a pipe, and reads up to 64KB via `io.LimitReader` to prevent unbounded memory usage.

### 6.5 Safety Layer Protects Against Agent Mistakes

AI agents make mistakes. They hallucinate phone numbers, pass invalid file paths, and forget required flags. GOWA CLI has a dedicated `safety` package that validates inputs before any API call:

- **Phone validation**: Regex check for E.164 format (10-15 digits), rejects obviously wrong numbers.
- **File path validation**: Checks file exists and is not a directory.
- **File extension validation**: Only allows expected extensions per command (e.g., `.jpg`, `.png` for image sends).
- **Timestamp validation**: Ensures RFC3339 format for date parameters.
- **Rate limiting**: Client-side rate limiter prevents agents from hammering the API.
- **Audit logging**: Every send operation is logged for traceability.
- **Risk acknowledgment**: The `--accept-risk` flag prevents accidental use of the unofficial API without explicit consent.

This safety layer is what differentiates an agent-friendly CLI from a raw API wrapper. The CLI protects the agent from itself.

## 7. Decision Matrix

| Criterion | CLI | MCP | Winner |
|-----------|-----|-----|--------|
| Works with any agent framework | Yes | Requires MCP client | CLI |
| Setup complexity | Install binary | Configure server + client | CLI |
| Structured output | `--json` flag | Native JSON-RPC | Tie |
| Error handling | Exit codes (instant) | JSON-RPC errors (parsed) | CLI |
| Composability (pipes) | Native | Not supported | CLI |
| Real-time streaming | Not native | SSE support | MCP |
| Bidirectional comms | Not possible | Sampling, elicitation | MCP |
| Dynamic tool discovery | Fixed per version | Runtime discovery | MCP |
| Offline capability | Full | Local stdio only | CLI |
| Debugging | Copy-paste command | Reconstruct JSON-RPC | CLI |
| Version pinning | Exact binary version | Server may drift | CLI |
| Security sandbox | Runs in agent sandbox | Separate process | CLI |
| Rich content (images) | Base64 or file paths | Native content types | MCP |
| IDE integration | Via subprocess | Native | MCP |
| Multi-step transactions | Stateless | Stateful connection | MCP |
| Learning curve for agents | Zero (subprocess) | Moderate (protocol) | CLI |

**Score: CLI 10 -- MCP 5 -- Tie 1**

## 8. Conclusion

Both CLI and MCP are legitimate interfaces for AI agents. The choice depends on your use case:

**Default to CLI when:**
- Your tool performs discrete operations (send message, list resources, create item).
- You want maximum compatibility across agent frameworks.
- Debuggability and reproducibility matter.
- You want agents to compose tools via pipes.
- You need to version-pin behavior precisely.

**Choose MCP when:**
- You need real-time streaming or server-push notifications.
- The interaction requires bidirectional communication.
- Your tool benefits from dynamic discovery (tools change at runtime).
- You are building specifically for MCP-native hosts (Claude Desktop, VS Code).

For most agent tasks -- especially CRUD operations, messaging, deployment, and data queries -- **CLI is the pragmatic default**. It is simpler, more portable, more debuggable, and relies on patterns that have been proven over decades.

MCP shines at the edges: real-time dashboards, interactive workflows, and rich IDE integrations. Use it when you need what it uniquely provides, not as a default.

GOWA CLI demonstrates that a well-designed CLI with `--json`, `--quiet`, semantic exit codes, stdin support, and a safety layer can be consumed by any AI agent with zero configuration, zero SDKs, and zero ongoing server management.

The best interface is the one your agent can use reliably, today, with the least friction. More often than not, that is a CLI.

---

# Portugues (PT-BR)

## 1. Introducao

A medida que agentes de IA se tornam os principais consumidores de ferramentas de desenvolvimento, uma pergunta fundamental de design surge: **como um agente deve interagir com servicos externos?**

Dois padroes dominantes emergiram:

1. **Ferramentas CLI** -- o agente executa um subprocesso, passa argumentos, le stdout/stderr e interpreta codigos de saida.
2. **Servidores MCP** -- o agente conecta-se a um servidor Model Context Protocol via JSON-RPC 2.0, descobrindo e invocando ferramentas atraves de um protocolo estruturado.

Ambas as abordagens funcionam. Mas otimizam para coisas diferentes, e escolher a errada pode significar complexidade desnecessaria, integracoes frageis ou vendor lock-in.

Este artigo analisa os tradeoffs com exemplos concretos, usando o GOWA CLI (um CLI de WhatsApp para agentes de IA) como estudo de caso.

## 2. O que e MCP?

O **Model Context Protocol (MCP)** e um padrao aberto criado pela Anthropic para conectar aplicacoes de IA a sistemas externos. Pense nele como "USB-C para IA" -- um conector universal que permite que qualquer host de IA (Claude, ChatGPT, VS Code Copilot, Cursor) se conecte a qualquer servidor MCP (bancos de dados, APIs, sistemas de arquivos).

### Arquitetura

O MCP segue um modelo cliente-servidor com tres participantes:

- **MCP Host**: A aplicacao de IA (ex: Claude Desktop, VS Code) que orquestra conexoes.
- **MCP Client**: Um componente dentro do host que mantem uma conexao dedicada com um servidor MCP.
- **MCP Server**: Um programa que expoe ferramentas, recursos e prompts para clientes.

### Detalhes do Protocolo

- Construido sobre **JSON-RPC 2.0** para comunicacao request/response.
- Suporta dois transportes: **stdio** (processos locais) e **Streamable HTTP** (servidores remotos com SSE).
- Inicia com um **handshake de negociacao de capacidades** onde cliente e servidor declaram funcionalidades suportadas.
- Servidores expoem tres primitivas: **Tools** (funcoes executaveis), **Resources** (fontes de dados) e **Prompts** (templates de interacao).
- Suporta **notificacoes em tempo real** para atualizacoes dinamicas (ex: mudancas na lista de ferramentas).

### Fluxo de Exemplo

```
1. Cliente envia request de inicializacao (versao do protocolo, capacidades)
2. Servidor responde com suas capacidades (tools, resources)
3. Cliente envia tools/list para descobrir ferramentas disponiveis
4. Cliente envia tools/call com argumentos para executar uma ferramenta
5. Servidor retorna conteudo estruturado (texto, imagens, etc.)
```

O MCP e poderoso. Permite interacoes ricas, bidirecionais e stateful. Mas esse poder vem com complexidade.

## 3. O que e um CLI Agent-Friendly?

Um CLI agent-friendly e uma ferramenta de linha de comando projetada nao apenas para humanos digitando no terminal, mas para **agentes de IA executando comandos programaticamente**. As caracteristicas principais sao:

- **Modos de saida estruturada**: `--json` para saida legivel por maquina, `--quiet` para valores puros.
- **Codigos de saida semanticos**: Codigos de saida diferentes para tipos diferentes de falha (erro de auth vs. rate limit vs. nao encontrado).
- **Suporte a stdin**: Aceitar entrada via pipes, nao apenas flags e argumentos.
- **Padroes de flag previsiveis**: Sintaxe consistente `--flag valor` em todos os comandos.
- **Erros auto-documentados**: Mensagens de erro que incluem dicas de recuperacao.
- **Sem prompts interativos em modo nao-TTY**: Detectar quando esta rodando como subprocesso e se comportar adequadamente.

O padrao e testado em batalha. Ferramentas como `gh` (GitHub CLI), `kubectl`, `docker`, `terraform` e `aws` sao agent-friendly ha anos -- muito antes do termo "agente de IA" se tornar mainstream.

## 4. Vantagens do CLI para Codigo Agentico

### 4.1 Compatibilidade Universal

Um CLI funciona com **todo framework de agente existente**: Claude Code, OpenAI Codex, Google Gemini, Cursor, Windsurf, Cline, Aider, agentes customizados, shell scripts, cron jobs, pipelines de CI/CD.

A interface e simples: execute um processo, passe argumentos, leia a saida.

```python
# Funciona em QUALQUER linguagem, QUALQUER framework
result = subprocess.run(["gowa", "send", "text", "--to", "5511999999999", "--json", "Hello"], capture_output=True)
data = json.loads(result.stdout)
```

O MCP requer que o host implemente um cliente MCP, suporte JSON-RPC 2.0, faca negociacao de capacidades e mantenha uma conexao persistente. Nem todo framework de agente suporta MCP, e os que suportam podem ter niveis diferentes de implementacao.

### 4.2 Sem Dependencia de SDK

Ferramentas CLI precisam de exatamente uma coisa: a capacidade de executar um subprocesso. Toda linguagem de programacao tem isso nativamente.

O MCP requer um SDK. Embora existam SDKs para TypeScript e Python, outras linguagens podem ter implementacoes incompletas ou mantidas pela comunidade. Seu codigo de agente fica acoplado a versao do SDK e seus bugs.

### 4.3 Codigos de Saida Estruturados = Tratamento de Erro Legivel por Maquina

Codigos de saida sao o mecanismo de sinalizacao de erro mais antigo e confiavel da computacao. Um agente pode fazer branching por codigos de saida sem fazer parsing de mensagens:

```bash
gowa send text --to 5511999999999 "Hello" --json
case $? in
  0) echo "enviado" ;;
  2) echo "input invalido -- corrigir argumentos" ;;
  3) echo "auth expirado -- re-login" ;;
  5) echo "servidor fora -- retry depois" ;;
  6) echo "rate limited -- esperar" ;;
esac
```

Erros MCP vem como objetos de erro JSON-RPC. Sao estruturados, mas o agente precisa parsear o corpo da resposta para entender o que aconteceu. Codigos de saida sao imediatos e sem overhead.

### 4.4 --json = Saida Estruturada Sem Parsear Linguagem Natural

A flag `--json` e a funcionalidade mais importante para consumo por agentes. Em vez de parsear tabelas humanas ou texto, o agente recebe um objeto JSON previsivel:

```bash
# Amigavel para humanos (padrao)
$ gowa device list
ID              NAME        STATUS
abc123@s.wa     My Phone    connected

# Amigavel para maquinas (--json)
$ gowa device list --json
[{"id":"abc123@s.wa","name":"My Phone","status":"connected"}]
```

### 4.5 --quiet = Saida Minima para Piping

As vezes um agente precisa apenas de um unico valor, nao de uma resposta JSON completa. A flag `--quiet` extrai o campo primario:

```bash
# Pegar apenas o ID da mensagem apos envio
MSG_ID=$(gowa send text --to 5511999999999 "Hello" --quiet)
echo "Enviado: $MSG_ID"
```

Isso e essencial para pipelines composiveis onde a saida de um comando alimenta outro.

### 4.6 Suporte a Stdin = Pipelines Composiveis

Ferramentas CLI que aceitam stdin habilitam composicao poderosa:

```bash
# Pipe de um relatorio gerado para WhatsApp
python gerar_relatorio.py | gowa send text --to 5511999999999

# Enviar conteudo de um arquivo
cat notas_reuniao.txt | gowa send text --to 5511999999999
```

Ferramentas MCP aceitam argumentos na chamada JSON-RPC. Nao existe conceito nativo de piping da saida de uma ferramenta MCP para outra -- o host precisa orquestrar isso manualmente.

### 4.7 Funciona Offline (Sem Servidor para a Camada CLI)

Um binario CLI e auto-contido. Roda na maquina, le arquivos de configuracao locais e chama APIs diretamente. Nao ha processo de servidor MCP para iniciar, configurar ou manter vivo.

O MCP requer um processo de servidor rodando. Para servidores locais (transporte stdio), isso e leve. Para servidores remotos (transporte HTTP), voce depende de disponibilidade de rede e uptime do servidor.

### 4.8 Padrao Testado em Batalha

O padrao CLI-como-API tem decadas de precedencia:

| Ferramenta | Funcionalidades Agent-Friendly |
|------------|-------------------------------|
| `gh` (GitHub) | Saida `--json`, filtragem `--jq`, codigos de saida para erros de API |
| `kubectl` | `-o json`, `-o jsonpath`, mensagens de erro estruturadas |
| `docker` | `--format` com Go templates, saida JSON, codigos de saida |
| `terraform` | Saida `-json` do plan, arquivos de state legiveis por maquina |
| `aws` | `--output json`, `--query` com JMESPath, codigos de saida |
| `jq` | Ferramenta pura de pipeline stdin/stdout, a cola da composicao CLI |

Agentes nao precisam aprender novos paradigmas. CLIs sao a lingua franca da automacao.

### 4.9 Seguranca: Isolamento de Sandbox

Um CLI roda no sandbox do usuario. O framework do agente controla quais comandos podem ser executados, quais diretorios sao acessiveis e quais chamadas de rede sao permitidas.

Servidores MCP, em contraste, rodam como processos separados com suas proprias permissoes. Um servidor MCP local tem acesso ao sistema de arquivos, rede e variaveis de ambiente da maquina host. A fronteira de seguranca e o processo do servidor, nao o sandbox do agente.

### 4.10 Debugavel: Reproduzir Exatamente

Quando o comando CLI de um agente falha, o desenvolvedor pode copiar e colar o comando exato e executar manualmente:

```bash
# Agente rodou isso e recebeu exit code 3
gowa send text --to 5511999999999 "Hello" --json

# Desenvolvedor roda o mesmo comando para debugar
$ gowa send text --to 5511999999999 "Hello" --json
Authentication failed: token expired
  Hint: Run 'gowa auth login' to configure credentials
```

Interacoes MCP sao mais dificeis de reproduzir. Voce precisa reconstruir o request JSON-RPC, conectar ao servidor e replayer a chamada.

### 4.11 Versionavel: Sem Drift de Servidor

Versoes de CLI sao pinaveis. Um agente pode depender de `gowa@1.2.3` e saber exatamente qual comportamento esperar. Nao ha drift server-side.

Servidores MCP podem mudar seus schemas de ferramentas, adicionar ou remover tools, ou alterar comportamento entre deploys. O mecanismo de notificacao `tools/list_changed` existe precisamente porque drift server-side e esperado.

## 5. Quando MCP Faz Mais Sentido

CLI nao e universalmente superior. MCP tem vantagens genuinas em cenarios especificos:

| Cenario | Por que MCP Ganha |
|---------|-------------------|
| **Streaming em tempo real** | MCP suporta Server-Sent Events para respostas em streaming. CLIs precisam usar polling ou tail de logs. |
| **Comunicacao bidirecional** | Servidores MCP podem solicitar input do usuario (elicitation) ou pedir completions ao LLM (sampling). CLIs sao fire-and-forget. |
| **Gerenciamento de estado complexo** | MCP mantem uma conexao persistente com negociacao de capacidades. Util para sessoes de banco de dados, transacoes multi-step ou workflows que requerem estado server-side. |
| **Descoberta dinamica de ferramentas** | Servidores MCP podem adicionar/remover ferramentas em runtime e notificar clientes. CLIs tem uma arvore de comandos fixa por versao. |
| **Tipos de conteudo ricos** | Respostas MCP podem incluir imagens, recursos embutidos e conteudo multi-part. Saida CLI e texto (ou dados base64). |
| **Servicos remotos multi-tenant** | Servidores MCP remotos (Streamable HTTP) podem servir muitos clientes simultaneamente com auth adequado. CLIs sao single-user por natureza. |
| **Integracao com browser/IDE** | Servidores MCP integram nativamente com Claude Desktop, VS Code, Cursor. Sem gerenciamento de subprocesso necessario. |

**A regra geral**: Se sua ferramenta precisa de uma conexao persistente, faz streaming de dados em tempo real, ou requer que o servidor inicie comunicacao, MCP e a melhor opcao.

## 6. GOWA CLI como Estudo de Caso

O GOWA CLI e uma ferramenta de mensagens WhatsApp construida desde o inicio para ser consumida por agentes de IA. Veja como implementa cada padrao agent-friendly:

### 6.1 --json para Saida Estruturada

Todo comando suporta `--json` como flag global. A saida e sempre um objeto ou array JSON valido:

```bash
$ gowa send text --to 5511999999999 "Hello" --json
{"message_id":"3EB0A6F1234567890","status":"sent","timestamp":"2026-03-19T10:30:00Z"}

$ gowa device list --json
[{"id":"5511999999999@s.whatsapp.net","name":"Agent Phone","status":"connected"}]
```

A implementacao usa uma interface `Formatter` com implementacoes `JSONFormatter`, `TableFormatter` e `QuietFormatter`. A funcao `AutoDetect` seleciona o formato baseado nas flags:

```go
format := output.AutoDetect(jsonFlag, quietFlag) // --json tem precedencia
formatter := output.New(format, os.Stdout)
```

### 6.2 --quiet para Valores Puros

A flag `--quiet` extrai o campo primario da resposta. O `QuietFormatter` tem uma lista de prioridade de campos para extrair: `message_id`, `id`, `status`, `authenticated`, `cli_version`:

```bash
$ gowa send text --to 5511999999999 "Hello" --quiet
3EB0A6F1234567890

$ gowa auth status --quiet
true
```

Isso torna trivial para agentes capturarem um unico valor sem parsing de JSON.

### 6.3 Codigos de Saida Semanticos

O GOWA CLI usa um tipo `CLIError` que mapeia codigos de status HTTP e condicoes de erro para codigos de saida especificos:

| Codigo de Saida | Significado | Status HTTP | Acao do Agente |
|----------------|-------------|-------------|----------------|
| 0 | Sucesso | 2xx | Continuar |
| 1 | Erro geral | Outro | Logar e reportar |
| 2 | Erro de uso/input | 400, 409 | Corrigir argumentos |
| 3 | Erro de autenticacao | 401, 403 | Re-autenticar |
| 4 | Nao encontrado | 404 | Verificar ID do recurso |
| 5 | Erro de servidor | 5xx | Retry com backoff |
| 6 | Rate limited | 429 | Esperar e retry |

Todo erro inclui uma dica de `Recovery` que diz ao agente (ou humano) exatamente o que fazer:

```go
&CLIError{
    Type:     "rate_limit",
    Code:     6,
    Message:  "Rate limited by server",
    Recovery: "Wait a moment and try again",
}
```

### 6.4 Pipe stdin para Conteudo de Mensagem

O comando `send text` aceita conteudo da mensagem via stdin quando nenhum argumento posicional e fornecido. Detecta modo nao-TTY automaticamente:

```bash
# Agente pode fazer pipe de conteudo gerado dinamicamente
echo "Seu pedido #1234 foi confirmado" | gowa send text --to 5511999999999

# Ou usar heredoc para multi-line
gowa send text --to 5511999999999 <<'EOF'
Resumo da reuniao:
- Discutimos o roadmap do Q2
- Action items atribuidos
EOF
```

A implementacao usa `go-isatty` para detectar se stdin e um terminal ou um pipe, e le ate 64KB via `io.LimitReader` para prevenir uso de memoria ilimitado.

### 6.5 Camada de Seguranca Protege Contra Erros de Agente

Agentes de IA cometem erros. Alucinam numeros de telefone, passam caminhos de arquivo invalidos e esquecem flags obrigatorias. O GOWA CLI tem um pacote `safety` dedicado que valida inputs antes de qualquer chamada de API:

- **Validacao de telefone**: Verificacao regex para formato E.164 (10-15 digitos), rejeita numeros obviamente errados.
- **Validacao de caminho de arquivo**: Verifica se o arquivo existe e nao e um diretorio.
- **Validacao de extensao de arquivo**: Permite apenas extensoes esperadas por comando (ex: `.jpg`, `.png` para envio de imagem).
- **Validacao de timestamp**: Garante formato RFC3339 para parametros de data.
- **Rate limiting**: Rate limiter client-side previne agentes de bombardearem a API.
- **Log de auditoria**: Toda operacao de envio e logada para rastreabilidade.
- **Reconhecimento de risco**: A flag `--accept-risk` previne uso acidental da API nao-oficial sem consentimento explicito.

Essa camada de seguranca e o que diferencia um CLI agent-friendly de um wrapper de API cru. O CLI protege o agente de si mesmo.

## 7. Matriz de Decisao

| Criterio | CLI | MCP | Vencedor |
|----------|-----|-----|----------|
| Funciona com qualquer framework de agente | Sim | Requer cliente MCP | CLI |
| Complexidade de setup | Instalar binario | Configurar servidor + cliente | CLI |
| Saida estruturada | Flag `--json` | JSON-RPC nativo | Empate |
| Tratamento de erros | Codigos de saida (instantaneo) | Erros JSON-RPC (parseados) | CLI |
| Composabilidade (pipes) | Nativo | Nao suportado | CLI |
| Streaming em tempo real | Nao nativo | Suporte SSE | MCP |
| Comunicacao bidirecional | Nao possivel | Sampling, elicitation | MCP |
| Descoberta dinamica de ferramentas | Fixo por versao | Descoberta em runtime | MCP |
| Capacidade offline | Total | Apenas stdio local | CLI |
| Debugging | Copiar e colar comando | Reconstruir JSON-RPC | CLI |
| Fixacao de versao | Versao exata do binario | Servidor pode divergir | CLI |
| Sandbox de seguranca | Roda no sandbox do agente | Processo separado | CLI |
| Conteudo rico (imagens) | Base64 ou caminhos de arquivo | Tipos de conteudo nativos | MCP |
| Integracao com IDE | Via subprocesso | Nativo | MCP |
| Transacoes multi-step | Stateless | Conexao stateful | MCP |
| Curva de aprendizado para agentes | Zero (subprocesso) | Moderada (protocolo) | CLI |

**Placar: CLI 10 -- MCP 5 -- Empate 1**

## 8. Conclusao

Tanto CLI quanto MCP sao interfaces legitimas para agentes de IA. A escolha depende do seu caso de uso:

**Use CLI como padrao quando:**
- Sua ferramenta realiza operacoes discretas (enviar mensagem, listar recursos, criar item).
- Voce quer maxima compatibilidade entre frameworks de agente.
- Debugabilidade e reprodutibilidade importam.
- Voce quer que agentes componham ferramentas via pipes.
- Voce precisa fixar o comportamento por versao com precisao.

**Escolha MCP quando:**
- Voce precisa de streaming em tempo real ou notificacoes server-push.
- A interacao requer comunicacao bidirecional.
- Sua ferramenta se beneficia de descoberta dinamica (ferramentas mudam em runtime).
- Voce esta construindo especificamente para hosts MCP-nativos (Claude Desktop, VS Code).

Para a maioria das tarefas de agente -- especialmente operacoes CRUD, mensagens, deploy e consultas de dados -- **CLI e o padrao pragmatico**. E mais simples, mais portavel, mais debugavel, e depende de padroes provados ao longo de decadas.

MCP brilha nas bordas: dashboards em tempo real, workflows interativos e integracoes ricas com IDE. Use-o quando precisar do que ele oferece de unico, nao como padrao.

O GOWA CLI demonstra que um CLI bem projetado com `--json`, `--quiet`, codigos de saida semanticos, suporte a stdin e uma camada de seguranca pode ser consumido por qualquer agente de IA com zero configuracao, zero SDKs e zero gerenciamento de servidor.

A melhor interface e aquela que seu agente pode usar de forma confiavel, hoje, com o minimo de friccao. Na maioria das vezes, isso e um CLI.

---

# Espanol (ES)

## 1. Introduccion

A medida que los agentes de IA se convierten en los principales consumidores de herramientas de desarrollo, surge una pregunta fundamental de diseno: **como debe un agente interactuar con servicios externos?**

Dos patrones dominantes han emergido:

1. **Herramientas CLI** -- el agente ejecuta un subproceso, pasa argumentos, lee stdout/stderr e interpreta codigos de salida.
2. **Servidores MCP** -- el agente se conecta a un servidor Model Context Protocol via JSON-RPC 2.0, descubriendo e invocando herramientas a traves de un protocolo estructurado.

Ambos enfoques funcionan. Pero optimizan para cosas diferentes, y elegir el incorrecto puede significar complejidad innecesaria, integraciones fragiles o vendor lock-in.

Este articulo analiza los tradeoffs con ejemplos concretos, usando GOWA CLI (un CLI de WhatsApp para agentes de IA) como caso de estudio.

## 2. Que es MCP?

El **Model Context Protocol (MCP)** es un estandar abierto creado por Anthropic para conectar aplicaciones de IA a sistemas externos. Piensa en el como "USB-C para IA" -- un conector universal que permite que cualquier host de IA (Claude, ChatGPT, VS Code Copilot, Cursor) se conecte a cualquier servidor MCP (bases de datos, APIs, sistemas de archivos).

### Arquitectura

MCP sigue un modelo cliente-servidor con tres participantes:

- **MCP Host**: La aplicacion de IA (ej: Claude Desktop, VS Code) que orquesta conexiones.
- **MCP Client**: Un componente dentro del host que mantiene una conexion dedicada con un servidor MCP.
- **MCP Server**: Un programa que expone herramientas, recursos y prompts a los clientes.

### Detalles del Protocolo

- Construido sobre **JSON-RPC 2.0** para comunicacion request/response.
- Soporta dos transportes: **stdio** (procesos locales) y **Streamable HTTP** (servidores remotos con SSE).
- Inicia con un **handshake de negociacion de capacidades** donde cliente y servidor declaran funcionalidades soportadas.
- Los servidores exponen tres primitivas: **Tools** (funciones ejecutables), **Resources** (fuentes de datos) y **Prompts** (plantillas de interaccion).
- Soporta **notificaciones en tiempo real** para actualizaciones dinamicas (ej: cambios en la lista de herramientas).

### Flujo de Ejemplo

```
1. Cliente envia request de inicializacion (version del protocolo, capacidades)
2. Servidor responde con sus capacidades (tools, resources)
3. Cliente envia tools/list para descubrir herramientas disponibles
4. Cliente envia tools/call con argumentos para ejecutar una herramienta
5. Servidor retorna contenido estructurado (texto, imagenes, etc.)
```

MCP es poderoso. Permite interacciones ricas, bidireccionales y con estado. Pero ese poder viene con complejidad.

## 3. Que es un CLI Agent-Friendly?

Un CLI agent-friendly es una herramienta de linea de comandos disenada no solo para humanos escribiendo en una terminal, sino para **agentes de IA ejecutando comandos programaticamente**. Las caracteristicas principales son:

- **Modos de salida estructurada**: `--json` para salida legible por maquinas, `--quiet` para valores puros.
- **Codigos de salida semanticos**: Codigos de salida diferentes para tipos diferentes de fallo (error de auth vs. rate limit vs. no encontrado).
- **Soporte stdin**: Aceptar entrada via pipes, no solo flags y argumentos.
- **Patrones de flag predecibles**: Sintaxis consistente `--flag valor` en todos los comandos.
- **Errores auto-documentados**: Mensajes de error que incluyen pistas de recuperacion.
- **Sin prompts interactivos en modo no-TTY**: Detectar cuando se ejecuta como subproceso y comportarse adecuadamente.

El patron esta probado en batalla. Herramientas como `gh` (GitHub CLI), `kubectl`, `docker`, `terraform` y `aws` han sido agent-friendly durante anos -- mucho antes de que el termino "agente de IA" se volviera mainstream.

## 4. Ventajas del CLI para Codigo Agentico

### 4.1 Compatibilidad Universal

Un CLI funciona con **todos los frameworks de agentes existentes**: Claude Code, OpenAI Codex, Google Gemini, Cursor, Windsurf, Cline, Aider, agentes personalizados, shell scripts, cron jobs, pipelines de CI/CD.

La interfaz es simple: ejecutar un proceso, pasar argumentos, leer la salida.

```python
# Funciona en CUALQUIER lenguaje, CUALQUIER framework
result = subprocess.run(["gowa", "send", "text", "--to", "5511999999999", "--json", "Hello"], capture_output=True)
data = json.loads(result.stdout)
```

MCP requiere que el host implemente un cliente MCP, soporte JSON-RPC 2.0, haga negociacion de capacidades y mantenga una conexion persistente. No todos los frameworks de agentes soportan MCP, y los que lo hacen pueden tener diferentes niveles de implementacion.

### 4.2 Sin Dependencia de SDK

Las herramientas CLI necesitan exactamente una cosa: la capacidad de ejecutar un subproceso. Todos los lenguajes de programacion lo tienen de forma nativa.

MCP requiere un SDK. Aunque existen SDKs para TypeScript y Python, otros lenguajes pueden tener implementaciones incompletas o mantenidas por la comunidad. Tu codigo de agente queda acoplado a la version del SDK y sus bugs.

### 4.3 Codigos de Salida Estructurados = Manejo de Errores Legible por Maquinas

Los codigos de salida son el mecanismo de senalizacion de errores mas antiguo y confiable de la computacion. Un agente puede hacer branching por codigos de salida sin parsear mensajes:

```bash
gowa send text --to 5511999999999 "Hello" --json
case $? in
  0) echo "enviado" ;;
  2) echo "input invalido -- corregir argumentos" ;;
  3) echo "auth expirado -- re-login" ;;
  5) echo "servidor caido -- retry despues" ;;
  6) echo "rate limited -- esperar" ;;
esac
```

Los errores MCP vienen como objetos de error JSON-RPC. Son estructurados, pero el agente necesita parsear el cuerpo de la respuesta para entender que paso. Los codigos de salida son inmediatos y sin overhead.

### 4.4 --json = Salida Estructurada Sin Parsear Lenguaje Natural

La flag `--json` es la funcionalidad mas importante para consumo por agentes. En vez de parsear tablas para humanos o texto, el agente recibe un objeto JSON predecible:

```bash
# Amigable para humanos (predeterminado)
$ gowa device list
ID              NAME        STATUS
abc123@s.wa     My Phone    connected

# Amigable para maquinas (--json)
$ gowa device list --json
[{"id":"abc123@s.wa","name":"My Phone","status":"connected"}]
```

### 4.5 --quiet = Salida Minima para Piping

A veces un agente solo necesita un unico valor, no una respuesta JSON completa. La flag `--quiet` extrae el campo primario:

```bash
# Obtener solo el ID del mensaje despues de enviar
MSG_ID=$(gowa send text --to 5511999999999 "Hello" --quiet)
echo "Enviado: $MSG_ID"
```

Esto es esencial para pipelines componibles donde la salida de un comando alimenta a otro.

### 4.6 Soporte Stdin = Pipelines Componibles

Las herramientas CLI que aceptan stdin habilitan composicion poderosa:

```bash
# Pipe de un reporte generado a WhatsApp
python generar_reporte.py | gowa send text --to 5511999999999

# Enviar contenido de un archivo
cat notas_reunion.txt | gowa send text --to 5511999999999
```

Las herramientas MCP aceptan argumentos en la llamada JSON-RPC. No existe concepto nativo de piping de la salida de una herramienta MCP a otra -- el host necesita orquestar esto manualmente.

### 4.7 Funciona Offline (Sin Servidor para la Capa CLI)

Un binario CLI es autocontenido. Se ejecuta en la maquina, lee archivos de configuracion locales y llama APIs directamente. No hay proceso de servidor MCP para iniciar, configurar o mantener vivo.

MCP requiere un proceso de servidor ejecutandose. Para servidores locales (transporte stdio), esto es ligero. Para servidores remotos (transporte HTTP), dependes de disponibilidad de red y uptime del servidor.

### 4.8 Patron Probado en Batalla

El patron CLI-como-API tiene decadas de precedencia:

| Herramienta | Funcionalidades Agent-Friendly |
|-------------|-------------------------------|
| `gh` (GitHub) | Salida `--json`, filtrado `--jq`, codigos de salida para errores de API |
| `kubectl` | `-o json`, `-o jsonpath`, mensajes de error estructurados |
| `docker` | `--format` con Go templates, salida JSON, codigos de salida |
| `terraform` | Salida `-json` del plan, archivos de state legibles por maquinas |
| `aws` | `--output json`, `--query` con JMESPath, codigos de salida |
| `jq` | Herramienta pura de pipeline stdin/stdout, el pegamento de la composicion CLI |

Los agentes no necesitan aprender nuevos paradigmas. Los CLIs son la lingua franca de la automatizacion.

### 4.9 Seguridad: Aislamiento de Sandbox

Un CLI se ejecuta en el sandbox del usuario. El framework del agente controla que comandos pueden ejecutarse, que directorios son accesibles y que llamadas de red estan permitidas.

Los servidores MCP, en contraste, se ejecutan como procesos separados con sus propios permisos. Un servidor MCP local tiene acceso al sistema de archivos, red y variables de entorno de la maquina host. La frontera de seguridad es el proceso del servidor, no el sandbox del agente.

### 4.10 Debuggeable: Reproducir Exactamente

Cuando el comando CLI de un agente falla, el desarrollador puede copiar y pegar el comando exacto y ejecutarlo manualmente:

```bash
# El agente ejecuto esto y recibio exit code 3
gowa send text --to 5511999999999 "Hello" --json

# El desarrollador ejecuta el mismo comando para debuggear
$ gowa send text --to 5511999999999 "Hello" --json
Authentication failed: token expired
  Hint: Run 'gowa auth login' to configure credentials
```

Las interacciones MCP son mas dificiles de reproducir. Necesitas reconstruir el request JSON-RPC, conectarte al servidor y repetir la llamada.

### 4.11 Versionable: Sin Drift de Servidor

Las versiones de CLI son fijables. Un agente puede depender de `gowa@1.2.3` y saber exactamente que comportamiento esperar. No hay drift del lado del servidor.

Los servidores MCP pueden cambiar sus schemas de herramientas, agregar o remover tools, o alterar comportamiento entre deploys. El mecanismo de notificacion `tools/list_changed` existe precisamente porque el drift del lado del servidor es esperado.

## 5. Cuando MCP Tiene Mas Sentido

CLI no es universalmente superior. MCP tiene ventajas genuinas en escenarios especificos:

| Escenario | Por que MCP Gana |
|-----------|-----------------|
| **Streaming en tiempo real** | MCP soporta Server-Sent Events para respuestas en streaming. Los CLIs necesitan usar polling o tail de logs. |
| **Comunicacion bidireccional** | Los servidores MCP pueden solicitar input del usuario (elicitation) o pedir completions al LLM (sampling). Los CLIs son fire-and-forget. |
| **Gestion de estado complejo** | MCP mantiene una conexion persistente con negociacion de capacidades. Util para sesiones de base de datos, transacciones multi-step o workflows que requieren estado del lado del servidor. |
| **Descubrimiento dinamico de herramientas** | Los servidores MCP pueden agregar/remover herramientas en runtime y notificar a los clientes. Los CLIs tienen un arbol de comandos fijo por version. |
| **Tipos de contenido ricos** | Las respuestas MCP pueden incluir imagenes, recursos incrustados y contenido multi-part. La salida CLI es texto (o datos base64). |
| **Servicios remotos multi-tenant** | Los servidores MCP remotos (Streamable HTTP) pueden servir muchos clientes simultaneamente con auth adecuado. Los CLIs son single-user por naturaleza. |
| **Integracion con browser/IDE** | Los servidores MCP integran nativamente con Claude Desktop, VS Code, Cursor. Sin gestion de subprocesos necesaria. |

**La regla general**: Si tu herramienta necesita una conexion persistente, hace streaming de datos en tiempo real, o requiere que el servidor inicie comunicacion, MCP es la mejor opcion.

## 6. GOWA CLI como Caso de Estudio

GOWA CLI es una herramienta de mensajeria WhatsApp construida desde cero para ser consumida por agentes de IA. Asi es como implementa cada patron agent-friendly:

### 6.1 --json para Salida Estructurada

Todos los comandos soportan `--json` como flag global. La salida siempre es un objeto o array JSON valido:

```bash
$ gowa send text --to 5511999999999 "Hello" --json
{"message_id":"3EB0A6F1234567890","status":"sent","timestamp":"2026-03-19T10:30:00Z"}

$ gowa device list --json
[{"id":"5511999999999@s.whatsapp.net","name":"Agent Phone","status":"connected"}]
```

La implementacion usa una interfaz `Formatter` con implementaciones `JSONFormatter`, `TableFormatter` y `QuietFormatter`. La funcion `AutoDetect` selecciona el formato basado en las flags:

```go
format := output.AutoDetect(jsonFlag, quietFlag) // --json tiene precedencia
formatter := output.New(format, os.Stdout)
```

### 6.2 --quiet para Valores Puros

La flag `--quiet` extrae el campo primario de la respuesta. El `QuietFormatter` tiene una lista de prioridad de campos para extraer: `message_id`, `id`, `status`, `authenticated`, `cli_version`:

```bash
$ gowa send text --to 5511999999999 "Hello" --quiet
3EB0A6F1234567890

$ gowa auth status --quiet
true
```

Esto hace trivial para los agentes capturar un unico valor sin parsing de JSON.

### 6.3 Codigos de Salida Semanticos

GOWA CLI usa un tipo `CLIError` que mapea codigos de estado HTTP y condiciones de error a codigos de salida especificos:

| Codigo de Salida | Significado | Estado HTTP | Accion del Agente |
|-----------------|-------------|-------------|-------------------|
| 0 | Exito | 2xx | Continuar |
| 1 | Error general | Otro | Loguear y reportar |
| 2 | Error de uso/input | 400, 409 | Corregir argumentos |
| 3 | Error de autenticacion | 401, 403 | Re-autenticar |
| 4 | No encontrado | 404 | Verificar ID del recurso |
| 5 | Error de servidor | 5xx | Retry con backoff |
| 6 | Rate limited | 429 | Esperar y retry |

Cada error incluye una pista de `Recovery` que le dice al agente (o humano) exactamente que hacer:

```go
&CLIError{
    Type:     "rate_limit",
    Code:     6,
    Message:  "Rate limited by server",
    Recovery: "Wait a moment and try again",
}
```

### 6.4 Pipe stdin para Contenido de Mensaje

El comando `send text` acepta contenido del mensaje via stdin cuando no se proporciona argumento posicional. Detecta modo no-TTY automaticamente:

```bash
# El agente puede hacer pipe de contenido generado dinamicamente
echo "Tu pedido #1234 fue confirmado" | gowa send text --to 5511999999999

# O usar heredoc para multi-linea
gowa send text --to 5511999999999 <<'EOF'
Resumen de la reunion:
- Discutimos el roadmap del Q2
- Action items asignados
EOF
```

La implementacion usa `go-isatty` para detectar si stdin es una terminal o un pipe, y lee hasta 64KB via `io.LimitReader` para prevenir uso de memoria ilimitado.

### 6.5 Capa de Seguridad Protege Contra Errores de Agentes

Los agentes de IA cometen errores. Alucinan numeros de telefono, pasan rutas de archivos invalidas y olvidan flags obligatorias. GOWA CLI tiene un paquete `safety` dedicado que valida inputs antes de cualquier llamada de API:

- **Validacion de telefono**: Verificacion regex para formato E.164 (10-15 digitos), rechaza numeros obviamente incorrectos.
- **Validacion de ruta de archivo**: Verifica que el archivo existe y no es un directorio.
- **Validacion de extension de archivo**: Solo permite extensiones esperadas por comando (ej: `.jpg`, `.png` para envio de imagenes).
- **Validacion de timestamp**: Asegura formato RFC3339 para parametros de fecha.
- **Rate limiting**: Rate limiter del lado del cliente previene que los agentes bombardeen la API.
- **Log de auditoria**: Cada operacion de envio se registra para trazabilidad.
- **Reconocimiento de riesgo**: La flag `--accept-risk` previene uso accidental de la API no oficial sin consentimiento explicito.

Esta capa de seguridad es lo que diferencia un CLI agent-friendly de un wrapper de API crudo. El CLI protege al agente de si mismo.

## 7. Matriz de Decision

| Criterio | CLI | MCP | Ganador |
|----------|-----|-----|---------|
| Funciona con cualquier framework de agentes | Si | Requiere cliente MCP | CLI |
| Complejidad de setup | Instalar binario | Configurar servidor + cliente | CLI |
| Salida estructurada | Flag `--json` | JSON-RPC nativo | Empate |
| Manejo de errores | Codigos de salida (instantaneo) | Errores JSON-RPC (parseados) | CLI |
| Composabilidad (pipes) | Nativo | No soportado | CLI |
| Streaming en tiempo real | No nativo | Soporte SSE | MCP |
| Comunicacion bidireccional | No posible | Sampling, elicitation | MCP |
| Descubrimiento dinamico de herramientas | Fijo por version | Descubrimiento en runtime | MCP |
| Capacidad offline | Total | Solo stdio local | CLI |
| Debugging | Copiar y pegar comando | Reconstruir JSON-RPC | CLI |
| Fijacion de version | Version exacta del binario | Servidor puede divergir | CLI |
| Sandbox de seguridad | Ejecuta en sandbox del agente | Proceso separado | CLI |
| Contenido rico (imagenes) | Base64 o rutas de archivo | Tipos de contenido nativos | MCP |
| Integracion con IDE | Via subproceso | Nativo | MCP |
| Transacciones multi-step | Stateless | Conexion stateful | MCP |
| Curva de aprendizaje para agentes | Cero (subproceso) | Moderada (protocolo) | CLI |

**Puntuacion: CLI 10 -- MCP 5 -- Empate 1**

## 8. Conclusion

Tanto CLI como MCP son interfaces legitimas para agentes de IA. La eleccion depende de tu caso de uso:

**Usa CLI como predeterminado cuando:**
- Tu herramienta realiza operaciones discretas (enviar mensaje, listar recursos, crear item).
- Quieres maxima compatibilidad entre frameworks de agentes.
- La debuggeabilidad y reproducibilidad importan.
- Quieres que los agentes compongan herramientas via pipes.
- Necesitas fijar el comportamiento por version con precision.

**Elige MCP cuando:**
- Necesitas streaming en tiempo real o notificaciones server-push.
- La interaccion requiere comunicacion bidireccional.
- Tu herramienta se beneficia de descubrimiento dinamico (herramientas cambian en runtime).
- Estas construyendo especificamente para hosts MCP-nativos (Claude Desktop, VS Code).

Para la mayoria de las tareas de agentes -- especialmente operaciones CRUD, mensajeria, deploy y consultas de datos -- **CLI es el predeterminado pragmatico**. Es mas simple, mas portable, mas debuggeable, y depende de patrones probados durante decadas.

MCP brilla en los bordes: dashboards en tiempo real, workflows interactivos e integraciones ricas con IDE. Usalo cuando necesites lo que ofrece de unico, no como predeterminado.

GOWA CLI demuestra que un CLI bien disenado con `--json`, `--quiet`, codigos de salida semanticos, soporte stdin y una capa de seguridad puede ser consumido por cualquier agente de IA con cero configuracion, cero SDKs y cero gestion de servidores.

La mejor interfaz es la que tu agente puede usar de forma confiable, hoy, con la minima friccion. La mayoria de las veces, eso es un CLI.
