# GOWA CLI API Reference

**[English](#english)** | **[Portugues](#portugues)** | **[Espanol](#espanol)**

---

# English

## Table of Contents

- [Global Flags](#global-flags)
- [Exit Codes](#exit-codes)
- [Environment Variables](#environment-variables)
- [Output Formats](#output-formats)
- [Commands](#commands)
  - [gowa (root)](#gowa-root)
  - [gowa auth login](#gowa-auth-login)
  - [gowa auth status](#gowa-auth-status)
  - [gowa auth logout](#gowa-auth-logout)
  - [gowa device list](#gowa-device-list)
  - [gowa device status](#gowa-device-status)
  - [gowa device use](#gowa-device-use)
  - [gowa device login](#gowa-device-login)
  - [gowa send text](#gowa-send-text)
  - [gowa send image](#gowa-send-image)
  - [gowa send file](#gowa-send-file)
  - [gowa chat list](#gowa-chat-list)
  - [gowa chat messages](#gowa-chat-messages)
  - [gowa group list](#gowa-group-list)
  - [gowa group info](#gowa-group-info)
  - [gowa group create](#gowa-group-create)
  - [gowa group leave](#gowa-group-leave)
  - [gowa group invite-link](#gowa-group-invite-link)
  - [gowa group join](#gowa-group-join)
  - [gowa api](#gowa-api)
  - [gowa completion](#gowa-completion)
  - [gowa version](#gowa-version)

---

## Global Flags

These flags are available on **every** command.

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--json` | bool | `false` | Output in JSON format |
| `--quiet` | bool | `false` | Minimal output (bare values only) |
| `--device` | string | `""` | Device JID override (overrides config default) |
| `--api-url` | string | `""` | GOWA server URL override (overrides config default) |
| `--no-color` | bool | `false` | Disable colored output |
| `--accept-risk` | bool | `false` | Accept risks of using unofficial WhatsApp API |
| `--timeout` | string | `"30s"` | HTTP request timeout (e.g., `10s`, `1m`, `2m30s`) |

> **Note:** The `--dry-run` flag is available on all `send` subcommands (text, image, file). See individual command docs.

---

## Exit Codes

| Code | Name | Description |
|------|------|-------------|
| `0` | Success | Command completed successfully |
| `1` | General Error | Unexpected error, parse error, or unknown failure |
| `2` | Usage Error | Bad request (HTTP 400), conflict (HTTP 409), or missing `--accept-risk` |
| `3` | Auth Error | Authentication failed (HTTP 401/403) |
| `4` | Not Found | Resource not found (HTTP 404) |
| `5` | Server Error | GOWA server unreachable or returned 5xx |
| `6` | Rate Limit | Server returned HTTP 429 (too many requests) |

---

## Environment Variables

All environment variables use the `GOWA_` prefix and map to config keys.

| Variable | Config Key | Default | Description |
|----------|-----------|---------|-------------|
| `GOWA_API_URL` | `api_url` | `http://localhost:3000` | GOWA server URL |
| `GOWA_USERNAME` | `username` | `""` | Basic auth username |
| `GOWA_PASSWORD` | `password` | `""` | Basic auth password |
| `GOWA_DEVICE_ID` | `device_id` | `""` | Default device JID |
| `GOWA_OUTPUT` | `output` | `table` | Default output format |
| `GOWA_RISK_ACCEPTED` | `risk_accepted` | `false` | Skip risk warning for send operations |
| `GOWA_TIMEOUT` | `timeout` | `30s` | HTTP request timeout (Go duration string) |

Configuration file location: `~/.config/gowa/config.yaml` (permissions: `0600`)

---

## Output Formats

The CLI supports three output modes. The format is auto-detected from flags.

### Table (default)

```
$ gowa device list
ID                            STATUS    PHONE          NAME
628xxx@s.whatsapp.net         connected 628123456789   My Phone
629xxx@s.whatsapp.net         disconnected 629987654321 Work Phone
```

### JSON (`--json`)

```json
$ gowa device list --json
[
  {
    "id": "628xxx@s.whatsapp.net",
    "status": "connected",
    "phone": "628123456789",
    "name": "My Phone"
  }
]
```

### Quiet (`--quiet`)

```
$ gowa version --quiet
1.2.0
```

---

## Commands

### gowa (root)

WhatsApp CLI powered by GOWA REST API. Provides agent-friendly commands for sending messages, managing devices, groups, and more.

**Synopsis:**
```
gowa [command] [flags]
```

**Available subcommands:** `auth`, `device`, `send`, `chat`, `api`, `completion`, `version`

**Examples:**
```bash
# Quick start
gowa auth login --api-url http://localhost:3000 --username admin --password secret
gowa device list
gowa send text --to 5511999999999 "Hello from CLI"
```

---

### gowa auth login

Authenticate with a GOWA server. Stores credentials in the config file. Supports interactive mode when run in a TTY without flags.

**Synopsis:**
```
gowa auth login [flags]
```

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--api-url` | string | `""` | GOWA server URL |
| `--url` | string | `""` | *(Deprecated: use `--api-url`)* Alias for `--api-url` |
| `--username` | string | `""` | Basic auth username |
| `--password` | string | `""` | Basic auth password |

**Examples:**
```bash
# Non-interactive (scripts, CI/CD, agents)
gowa auth login --api-url http://localhost:3000 --username admin --password secret

# Interactive mode (prompts for each field)
gowa auth login

# Override only the URL, prompt for credentials
gowa auth login --api-url http://192.168.1.100:3000
```

**Exit codes:** `0` (success), `1` (parse error), `3` (auth failed), `5` (server unreachable)

**Notes:**
- In interactive mode (TTY), missing flags trigger prompts with defaults from existing config.
- In non-interactive mode (pipe/CI), `--username` and `--password` are required.
- Login validates credentials by calling `GET /devices` before saving.
- Config is saved to `~/.config/gowa/config.yaml` with `0600` permissions.

---

### gowa auth status

Show current authentication status, connection health, and device count.

**Synopsis:**
```
gowa auth status
```

**Flags:** Global flags only.

**Examples:**
```bash
gowa auth status
gowa auth status --json
```

**Output fields:** `api_url`, `authenticated`, `username`, `connected`, `device_count`, `default_device`, `config_path`

**Exit codes:** `0` (success), `5` (server unreachable)

**Notes:**
- Tests the live connection by calling `GET /devices`.
- `authenticated` reflects whether credentials exist in config; `connected` reflects whether the server responded successfully.

---

### gowa auth logout

Remove stored credentials from the config file. Does not invalidate server-side sessions.

**Synopsis:**
```
gowa auth logout
```

**Flags:** Global flags only.

**Examples:**
```bash
gowa auth logout
gowa auth logout --json
```

**Exit codes:** `0` (success), `1` (config save error)

**Notes:**
- Only clears `username` and `password` from config. Other settings (`api_url`, `device_id`) are preserved.

---

### gowa device list

List all registered WhatsApp devices on the server.

**Synopsis:**
```
gowa device list
```

**Flags:** Global flags only.

**Output columns:** `ID`, `STATUS`, `PHONE`, `NAME`

**Examples:**
```bash
gowa device list
gowa device list --json
gowa device list --quiet
```

**Exit codes:** `0` (success), `3` (auth error), `5` (server error)

---

### gowa device status

Check the connection status of a specific device.

**Synopsis:**
```
gowa device status [device-id]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `device-id` | No | Device JID. Falls back to default device from config. |

**Flags:** Global flags only.

**Examples:**
```bash
gowa device status
gowa device status 628xxx@s.whatsapp.net
gowa device status 628xxx@s.whatsapp.net --json
```

**Exit codes:** `0` (success), `1` (no device specified), `4` (device not found), `5` (server error)

**Notes:**
- If no argument is provided, uses the default device set with `gowa device use`.
- Fails with an error if no device is specified and no default is configured.

---

### gowa device use

Set a default device for all subsequent commands. Persists the selection to config.

**Synopsis:**
```
gowa device use <device-id>
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `device-id` | **Yes** | Device JID to set as default |

**Flags:** Global flags only.

**Examples:**
```bash
# Find your device ID first
gowa device list

# Set default device
gowa device use 628xxx@s.whatsapp.net
```

**Exit codes:** `0` (success), `1` (config save error), `2` (missing argument)

**Notes:**
- Does not validate that the device exists on the server. Use `gowa device list` first.

---

### gowa device login

Login a device via QR code. Initiates the WhatsApp Web pairing process.

**Synopsis:**
```
gowa device login <device-id>
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `device-id` | **Yes** | Device ID to log in |

**Flags:** Global flags only.

**Examples:**
```bash
gowa device login 628xxx
gowa device login 628xxx --json
```

**Exit codes:** `0` (success), `1` (parse error), `4` (device not found), `5` (server error)

**Notes:**
- Returns QR code data or pairing information from the server.
- The actual pairing must be completed by scanning the QR code on the physical device.

---

### gowa send text

Send a text message to a phone number or JID. Supports piped input from stdin.

**Synopsis:**
```
gowa send text [message] [flags]
```

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--to` | string | `""` | **Required (or `--to-file`).** Recipient phone number (E.164) or JID |
| `--to-file` | string | `""` | File with one phone number per line for batch sending |
| `--reply` | string | `""` | Message ID to reply to |
| `--dry-run` | bool | `false` | Validate inputs and preview the request without sending |

**Examples:**
```bash
# Simple text message
gowa send text --to 5511999999999 "Hello World" --accept-risk

# Reply to a specific message
gowa send text --to 5511999999999 "This is a reply" --reply MSG_ID --accept-risk

# Pipe message from stdin (agent-friendly)
echo "Automated notification" | gowa send text --to 5511999999999 --accept-risk

# Dry-run — validate without sending
gowa send text --to 5511999999999 "Hello" --dry-run --accept-risk

# Batch send to multiple recipients from a file
gowa send text --to-file recipients.txt "Hello everyone" --accept-risk

# Batch dry-run preview
gowa send text --to-file recipients.txt "Hello" --dry-run --accept-risk
```

**Exit codes:** `0` (success), `2` (missing `--accept-risk`, invalid input), `3` (auth error), `5` (server error), `6` (rate limited)

**Notes:**
- **Risk acknowledgment required.** First use requires `--accept-risk` flag or `risk_accepted: true` in config.
- Phone validation: 10-15 digits, optionally with `@s.whatsapp.net` suffix.
- Stdin reading is capped at 64 KB.
- If run in a TTY without arguments or stdin, returns an error.
- `--to` and `--to-file` are mutually exclusive. The recipients file supports comments (`#`) and blank lines.
- Batch sends include a 2-second delay between recipients. Stops immediately on rate limit (HTTP 429).

---

### gowa send image

Send an image file with an optional caption.

**Synopsis:**
```
gowa send image [flags]
```

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--to` | string | `""` | **Required (or `--to-file`).** Recipient phone number or JID |
| `--to-file` | string | `""` | File with one phone number per line for batch sending |
| `--file` | string | `""` | **Required.** Path to image file |
| `--caption` | string | `""` | Image caption text |
| `--dry-run` | bool | `false` | Validate inputs and preview the request without sending |

**Examples:**
```bash
gowa send image --to 5511999999999 --file photo.jpg --accept-risk
gowa send image --to 5511999999999 --file photo.jpg --caption "Look at this!" --accept-risk
gowa send image --to 5511999999999 --file /tmp/screenshot.png --json --accept-risk

# Dry-run — validate file and recipient without sending
gowa send image --to 5511999999999 --file photo.jpg --dry-run --accept-risk

# Batch send image to multiple recipients
gowa send image --to-file recipients.txt --file photo.jpg --accept-risk
```

**Exit codes:** `0` (success), `2` (missing flags, invalid file, unsupported extension, missing `--accept-risk`), `3` (auth error), `5` (server error), `6` (rate limited)

**Notes:**
- **Allowed image extensions:** `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`
- File must exist and be a regular file (not a directory).
- Risk acknowledgment required (same as `send text`).
- `--to` and `--to-file` are mutually exclusive.

---

### gowa send file

Send a document or file attachment.

**Synopsis:**
```
gowa send file [flags]
```

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--to` | string | `""` | **Required (or `--to-file`).** Recipient phone number or JID |
| `--to-file` | string | `""` | File with one phone number per line for batch sending |
| `--file` | string | `""` | **Required.** Path to file |
| `--dry-run` | bool | `false` | Validate inputs and preview the request without sending |

**Examples:**
```bash
gowa send file --to 5511999999999 --file report.pdf --accept-risk
gowa send file --to 5511999999999 --file data.xlsx --json --accept-risk

# Dry-run — validate file and recipient without sending
gowa send file --to 5511999999999 --file report.pdf --dry-run --accept-risk

# Batch send file to multiple recipients
gowa send file --to-file recipients.txt --file report.pdf --accept-risk
```

**Exit codes:** `0` (success), `2` (missing flags, file not found, missing `--accept-risk`), `3` (auth error), `5` (server error), `6` (rate limited)

**Notes:**
- No extension restriction (unlike `send image`). Any file type is accepted.
- File must exist and be a regular file.
- Risk acknowledgment required.
- `--to` and `--to-file` are mutually exclusive.

---

### gowa chat list

List conversations with optional search filter.

**Synopsis:**
```
gowa chat list [flags]
```

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--limit` | int | `25` | Maximum number of chats to return |
| `--search` | string | `""` | Search filter (matches chat name) |

**Output columns:** `JID`, `NAME`, `LAST MESSAGE`, `UNREAD`

**Examples:**
```bash
gowa chat list
gowa chat list --limit 20 --search "john"
gowa chat list --json
```

**Exit codes:** `0` (success), `3` (auth error), `5` (server error)

---

### gowa chat messages

Retrieve message history from a specific chat.

**Synopsis:**
```
gowa chat messages <jid> [flags]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `jid` | **Yes** | Chat JID (phone number or group JID) |

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--limit` | int | `50` | Maximum number of messages |
| `--since` | string | `""` | Start date filter (RFC3339 format) |
| `--until` | string | `""` | End date filter (RFC3339 format) |
| `--search` | string | `""` | Search in message text |

**Output columns:** `ID`, `FROM`, `TYPE`, `TEXT`, `STATUS`

**Examples:**
```bash
gowa chat messages 5511999999999
gowa chat messages 5511999999999 --limit 50 --since 2024-01-15T00:00:00Z
gowa chat messages GROUP_JID --json --search "meeting"
```

**Exit codes:** `0` (success), `2` (invalid date format), `3` (auth error), `4` (chat not found), `5` (server error)

**Notes:**
- Date values must be in RFC3339 format (e.g., `2024-01-15T10:30:00Z`).
- Invalid date formats produce a descriptive error with the expected format.

---

### gowa group list

List all WhatsApp groups the user is a member of.

**Synopsis:**
```
gowa group list [flags]
```

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--name` | string | `""` | Filter groups by name (case-insensitive substring match) |
| `--limit` | int | `50` | Maximum number of groups to display (table/quiet only; `--json` returns all) |

**Output columns:** `JID`, `NAME`, `MEMBERS`

**Examples:**
```bash
gowa group list
gowa group list --name "dev" --json
gowa group list --limit 10
```

**Exit codes:** `0` (success), `1` (daemon error), `5` (connection error), `7` (session expired)

**RPC method:** `group.list` — Params: `{}` — Response: `[{jid, name, participant_count}, ...]`

---

### gowa group info

Show detailed information about a WhatsApp group, including metadata, settings, and optionally members.

**Synopsis:**
```
gowa group info <jid> [flags]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `jid` | **Yes** | Group JID (e.g. `120363012345678901@g.us`) |

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--members` | bool | `false` | Show group members instead of group details |
| `--role` | string | `""` | Filter members by role: `admin`, `member`, `superadmin` (requires `--members`) |

**Output (default):** Single object with `jid`, `name`, `description`, `created_at`, `creator_jid`, `participant_count`, `is_locked`, `is_announce`, `is_ephemeral`

**Output (--members):** Table with columns `JID`, `NAME`, `ROLE`

**Examples:**
```bash
gowa group info 120363012345678901@g.us
gowa group info 120363012345678901@g.us --members
gowa group info 120363012345678901@g.us --members --role admin --json
```

**Exit codes:** `0` (success), `2` (invalid JID), `3` (group not found), `5` (connection error), `7` (session expired)

**RPC method:** `group.info` — Params: `{jid}` — Response: `{jid, name, description, created_at, creator_jid, participant_count, is_locked, is_announce, is_ephemeral, participants: [{jid, display_name, role}]}`

---

### gowa group create

Create a new WhatsApp group with optional initial members.

**Synopsis:**
```
gowa group create <name> [flags]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `name` | **Yes** | Group name (1-25 characters) |

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--members` | string | `""` | Comma-separated phone numbers for initial group members |
| `--accept-risk` | bool | `false` | Acknowledge WhatsApp ban risk (required) |
| `--dry-run` | bool | `false` | Preview without creating the group |

**Examples:**
```bash
gowa group create "Project Team" --accept-risk
gowa group create "Dev Chat" --members 5511999999999,5511888888888 --accept-risk
gowa group create "Test Group" --dry-run --accept-risk
```

**Exit codes:** `0` (success), `2` (invalid name or phone), `5` (connection error), `6` (rate limited), `7` (session expired)

**RPC method:** `group.create` — Params: `{name, participants: [phone, ...]}` — Response: `{jid, name, participant_count, ...}`

**Notes:**
- Subject to group-specific rate limits: 5/hour, 20/day.
- Group names must be 1-25 characters.
- Phone numbers are validated in E.164 format.

---

### gowa group leave

Leave a WhatsApp group. This action is irreversible.

**Synopsis:**
```
gowa group leave <jid> [flags]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `jid` | **Yes** | Group JID (e.g. `120363012345678901@g.us`) |

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--accept-risk` | bool | `false` | Acknowledge WhatsApp ban risk (required) |
| `--dry-run` | bool | `false` | Preview without leaving the group |

**Examples:**
```bash
gowa group leave 120363012345678901@g.us --accept-risk
gowa group leave 120363012345678901@g.us --dry-run --accept-risk
```

**Exit codes:** `0` (success), `2` (invalid JID), `3` (group not found), `5` (connection error), `7` (session expired)

**RPC method:** `group.leave` — Params: `{jid}` — Response: `{status: "left"}`

---

### gowa group invite-link

Get or reset the invite link for a WhatsApp group.

**Synopsis:**
```
gowa group invite-link <jid> [flags]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `jid` | **Yes** | Group JID (e.g. `120363012345678901@g.us`) |

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--reset` | bool | `false` | Generate a new invite link (admin only, requires `--accept-risk`) |
| `--accept-risk` | bool | `false` | Acknowledge WhatsApp ban risk (required for `--reset`) |

**Examples:**
```bash
gowa group invite-link 120363012345678901@g.us
gowa group invite-link 120363012345678901@g.us --reset --accept-risk
gowa group invite-link 120363012345678901@g.us --quiet
```

**Exit codes:** `0` (success), `2` (invalid JID), `4` (permission error / not admin), `5` (connection error), `7` (session expired)

**RPC method:** `group.inviteLink` — Params: `{jid, reset}` — Response: `{link}`

---

### gowa group join

Join a WhatsApp group via invite link or invite code.

**Synopsis:**
```
gowa group join <link-or-code> [flags]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `link-or-code` | **Yes** | WhatsApp invite URL (`https://chat.whatsapp.com/...`) or invite code |

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--accept-risk` | bool | `false` | Acknowledge WhatsApp ban risk (required) |
| `--dry-run` | bool | `false` | Preview without joining the group |

**Examples:**
```bash
gowa group join https://chat.whatsapp.com/AbCdEfGhIjKl --accept-risk
gowa group join AbCdEfGhIjKl --accept-risk
gowa group join https://chat.whatsapp.com/AbCdEfGhIjKl --dry-run --accept-risk
```

**Exit codes:** `0` (success), `2` (invalid link or code), `3` (group not found), `5` (connection error), `6` (rate limited), `7` (session expired)

**RPC method:** `group.join` — Params: `{code}` — Response: `{jid, name}`

**Notes:**
- Subject to group-specific rate limits: 5/hour, 20/day.
- Accepts full URL (`https://chat.whatsapp.com/...`) or bare invite code.
- The invite code is automatically extracted from the URL.

---

### Sending to Groups

There is no separate `group send` command. To send messages to a group, use the existing `gowa send text` command with a group JID (`@g.us`):

```bash
gowa send text --to 120363012345678901@g.us "Hello group!" --accept-risk
gowa send image --to 120363012345678901@g.us --file photo.jpg --accept-risk
```

Group JIDs can be obtained from `gowa group list --json`.

---

### gowa api

Direct API access escape hatch. Make raw HTTP calls to any GOWA server endpoint.

**Synopsis:**
```
gowa api <method> <path> [flags]
```

**Arguments:**

| Argument | Required | Description |
|----------|----------|-------------|
| `method` | **Yes** | HTTP method (`GET`, `POST`, `PUT`, `DELETE`, etc.) |
| `path` | **Yes** | API endpoint path (e.g., `/devices`) |

**Flags:**

| Flag | Type | Default | Description |
|------|------|---------|-------------|
| `--field` | string[] | `nil` | Request body field as `key=value` (repeatable) |
| `--query` | string[] | `nil` | Query parameter as `key=value` (repeatable) |
| `--input` | string | `""` | Read request body from file (use `-` for stdin) |

**Examples:**
```bash
# GET request
gowa api GET /devices

# GET with query parameters
gowa api GET /chats --query limit=10 --query search=john

# POST with inline fields
gowa api POST /send/message --field phone=5511999 --field message="Hello" --accept-risk

# POST with JSON body from file
gowa api POST /send/message --input body.json --accept-risk

# Pipe JSON body from stdin
cat body.json | gowa api POST /send/message --input - --accept-risk

# DELETE request
gowa api DELETE /devices/123
```

**Exit codes:** All exit codes may apply depending on the endpoint called.

**Notes:**
- The path automatically gets a leading `/` if missing.
- `POST /send/*` endpoints require `--accept-risk` (same risk gate as `send` commands).
- `--field` values are combined into a JSON object. `--input` reads raw JSON.
- `--field` and `--input` are mutually exclusive in practice (last one wins).
- Response is always printed as indented JSON, regardless of `--json` flag.

---

### gowa completion

Generate shell completion scripts for bash, zsh, fish, or powershell.

**Synopsis:**
```
gowa completion [bash|zsh|fish|powershell]
```

**Arguments:**

| Argument | Required | Valid Values | Description |
|----------|----------|-------------|-------------|
| `shell` | **Yes** | `bash`, `zsh`, `fish`, `powershell` | Target shell |

**Examples:**
```bash
# Bash — source directly
source <(gowa completion bash)

# Bash — persist
gowa completion bash > /etc/bash_completion.d/gowa

# Zsh
gowa completion zsh > "${fpath[1]}/_gowa"

# Fish
gowa completion fish | source
gowa completion fish > ~/.config/fish/completions/gowa.fish

# PowerShell
gowa completion powershell | Out-String | Invoke-Expression
```

**Exit codes:** `0` (success), `2` (invalid argument)

**Notes:**
- Only the four listed shells are accepted. Other values produce an error.

---

### gowa version

Display CLI version, commit hash, and build date.

**Synopsis:**
```
gowa version [flags]
```

**Flags:** `--json`, `--quiet` (from global flags).

**Output fields:** `cli_version`, `commit`, `build_date`

**Examples:**
```bash
# Table format
gowa version

# JSON format
gowa version --json

# Quiet — just the version string
gowa version --quiet
```

**Exit codes:** `0` (always succeeds)

---

---

# Portugues

## Sumario

- [Flags Globais](#flags-globais)
- [Codigos de Saida](#codigos-de-saida)
- [Variaveis de Ambiente](#variaveis-de-ambiente)
- [Formatos de Saida](#formatos-de-saida)
- [Comandos](#comandos-1)
  - [gowa (raiz)](#gowa-raiz)
  - [gowa auth login](#gowa-auth-login-1)
  - [gowa auth status](#gowa-auth-status-1)
  - [gowa auth logout](#gowa-auth-logout-1)
  - [gowa device list](#gowa-device-list-1)
  - [gowa device status](#gowa-device-status-1)
  - [gowa device use](#gowa-device-use-1)
  - [gowa device login](#gowa-device-login-1)
  - [gowa send text](#gowa-send-text-1)
  - [gowa send image](#gowa-send-image-1)
  - [gowa send file](#gowa-send-file-1)
  - [gowa chat list](#gowa-chat-list-1)
  - [gowa chat messages](#gowa-chat-messages-1)
  - [gowa api](#gowa-api-1)
  - [gowa completion](#gowa-completion-1)
  - [gowa version](#gowa-version-1)

---

## Flags Globais

Estas flags estao disponiveis em **todos** os comandos.

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--json` | bool | `false` | Saida em formato JSON |
| `--quiet` | bool | `false` | Saida minima (apenas valores) |
| `--device` | string | `""` | Sobrescreve o JID do dispositivo (ignora config padrao) |
| `--api-url` | string | `""` | Sobrescreve a URL do servidor GOWA (ignora config padrao) |
| `--no-color` | bool | `false` | Desabilita saida colorida |
| `--accept-risk` | bool | `false` | Aceita os riscos de usar a API nao-oficial do WhatsApp |
| `--timeout` | string | `"30s"` | Timeout de requisicao HTTP (ex: `10s`, `1m`, `2m30s`) |

> **Nota:** A flag `--dry-run` esta disponivel em todos os subcomandos `send` (text, image, file). Veja a documentacao de cada comando.

---

## Codigos de Saida

| Codigo | Nome | Descricao |
|--------|------|-----------|
| `0` | Sucesso | Comando concluido com sucesso |
| `1` | Erro Geral | Erro inesperado, erro de parse ou falha desconhecida |
| `2` | Erro de Uso | Requisicao invalida (HTTP 400), conflito (HTTP 409) ou `--accept-risk` ausente |
| `3` | Erro de Auth | Autenticacao falhou (HTTP 401/403) |
| `4` | Nao Encontrado | Recurso nao encontrado (HTTP 404) |
| `5` | Erro de Servidor | Servidor GOWA inacessivel ou retornou 5xx |
| `6` | Rate Limit | Servidor retornou HTTP 429 (muitas requisicoes) |

---

## Variaveis de Ambiente

Todas as variaveis usam o prefixo `GOWA_` e mapeiam para chaves de configuracao.

| Variavel | Chave Config | Padrao | Descricao |
|----------|-------------|--------|-----------|
| `GOWA_API_URL` | `api_url` | `http://localhost:3000` | URL do servidor GOWA |
| `GOWA_USERNAME` | `username` | `""` | Usuario para autenticacao basica |
| `GOWA_PASSWORD` | `password` | `""` | Senha para autenticacao basica |
| `GOWA_DEVICE_ID` | `device_id` | `""` | JID do dispositivo padrao |
| `GOWA_OUTPUT` | `output` | `table` | Formato de saida padrao |
| `GOWA_RISK_ACCEPTED` | `risk_accepted` | `false` | Pular aviso de risco para operacoes de envio |
| `GOWA_TIMEOUT` | `timeout` | `30s` | Timeout de requisicao HTTP (string de duracao Go) |

Localizacao do arquivo de configuracao: `~/.config/gowa/config.yaml` (permissoes: `0600`)

---

## Formatos de Saida

A CLI suporta tres modos de saida. O formato e auto-detectado a partir das flags.

### Tabela (padrao)

```
$ gowa device list
ID                            STATUS    PHONE          NAME
628xxx@s.whatsapp.net         connected 628123456789   My Phone
629xxx@s.whatsapp.net         disconnected 629987654321 Work Phone
```

### JSON (`--json`)

```json
$ gowa device list --json
[
  {
    "id": "628xxx@s.whatsapp.net",
    "status": "connected",
    "phone": "628123456789",
    "name": "My Phone"
  }
]
```

### Quiet (`--quiet`)

```
$ gowa version --quiet
1.2.0
```

---

## Comandos

### gowa (raiz)

CLI para WhatsApp alimentada pela API REST GOWA. Fornece comandos amigaveis para agentes para envio de mensagens, gerenciamento de dispositivos, grupos e mais.

**Sinopse:**
```
gowa [comando] [flags]
```

**Subcomandos disponiveis:** `auth`, `device`, `send`, `chat`, `api`, `completion`, `version`

**Exemplos:**
```bash
# Inicio rapido
gowa auth login --api-url http://localhost:3000 --username admin --password secret
gowa device list
gowa send text --to 5511999999999 "Ola do CLI"
```

---

### gowa auth login

Autentica com um servidor GOWA. Armazena credenciais no arquivo de configuracao. Suporta modo interativo quando executado em TTY sem flags.

**Sinopse:**
```
gowa auth login [flags]
```

**Flags:**

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--api-url` | string | `""` | URL do servidor GOWA |
| `--url` | string | `""` | *(Descontinuada: use `--api-url`)* Alias para `--api-url` |
| `--username` | string | `""` | Usuario para autenticacao basica |
| `--password` | string | `""` | Senha para autenticacao basica |

**Exemplos:**
```bash
# Nao-interativo (scripts, CI/CD, agentes)
gowa auth login --api-url http://localhost:3000 --username admin --password secret

# Modo interativo (solicita cada campo)
gowa auth login

# Sobrescrever apenas a URL, solicitar credenciais
gowa auth login --api-url http://192.168.1.100:3000
```

**Codigos de saida:** `0` (sucesso), `1` (erro de parse), `3` (auth falhou), `5` (servidor inacessivel)

**Notas:**
- No modo interativo (TTY), flags ausentes acionam prompts com valores padrao da configuracao existente.
- No modo nao-interativo (pipe/CI), `--username` e `--password` sao obrigatorios.
- O login valida credenciais chamando `GET /devices` antes de salvar.
- A configuracao e salva em `~/.config/gowa/config.yaml` com permissoes `0600`.

---

### gowa auth status

Mostra o status atual de autenticacao, saude da conexao e contagem de dispositivos.

**Sinopse:**
```
gowa auth status
```

**Flags:** Apenas flags globais.

**Exemplos:**
```bash
gowa auth status
gowa auth status --json
```

**Campos de saida:** `api_url`, `authenticated`, `username`, `connected`, `device_count`, `default_device`, `config_path`

**Codigos de saida:** `0` (sucesso), `5` (servidor inacessivel)

**Notas:**
- Testa a conexao ao vivo chamando `GET /devices`.
- `authenticated` indica se existem credenciais na config; `connected` indica se o servidor respondeu com sucesso.

---

### gowa auth logout

Remove credenciais armazenadas do arquivo de configuracao. Nao invalida sessoes no servidor.

**Sinopse:**
```
gowa auth logout
```

**Flags:** Apenas flags globais.

**Exemplos:**
```bash
gowa auth logout
gowa auth logout --json
```

**Codigos de saida:** `0` (sucesso), `1` (erro ao salvar config)

**Notas:**
- Limpa apenas `username` e `password` da config. Outras configuracoes (`api_url`, `device_id`) sao preservadas.

---

### gowa device list

Lista todos os dispositivos WhatsApp registrados no servidor.

**Sinopse:**
```
gowa device list
```

**Flags:** Apenas flags globais.

**Colunas de saida:** `ID`, `STATUS`, `PHONE`, `NAME`

**Exemplos:**
```bash
gowa device list
gowa device list --json
gowa device list --quiet
```

**Codigos de saida:** `0` (sucesso), `3` (erro de auth), `5` (erro do servidor)

---

### gowa device status

Verifica o status de conexao de um dispositivo especifico.

**Sinopse:**
```
gowa device status [device-id]
```

**Argumentos:**

| Argumento | Obrigatorio | Descricao |
|-----------|-------------|-----------|
| `device-id` | Nao | JID do dispositivo. Usa o dispositivo padrao da config se omitido. |

**Flags:** Apenas flags globais.

**Exemplos:**
```bash
gowa device status
gowa device status 628xxx@s.whatsapp.net
gowa device status 628xxx@s.whatsapp.net --json
```

**Codigos de saida:** `0` (sucesso), `1` (nenhum dispositivo especificado), `4` (dispositivo nao encontrado), `5` (erro do servidor)

**Notas:**
- Se nenhum argumento for fornecido, usa o dispositivo padrao definido com `gowa device use`.
- Falha com erro se nenhum dispositivo for especificado e nenhum padrao estiver configurado.

---

### gowa device use

Define um dispositivo padrao para todos os comandos subsequentes. Persiste a selecao na configuracao.

**Sinopse:**
```
gowa device use <device-id>
```

**Argumentos:**

| Argumento | Obrigatorio | Descricao |
|-----------|-------------|-----------|
| `device-id` | **Sim** | JID do dispositivo a definir como padrao |

**Flags:** Apenas flags globais.

**Exemplos:**
```bash
# Encontre o ID do dispositivo primeiro
gowa device list

# Defina o dispositivo padrao
gowa device use 628xxx@s.whatsapp.net
```

**Codigos de saida:** `0` (sucesso), `1` (erro ao salvar config), `2` (argumento ausente)

**Notas:**
- Nao valida se o dispositivo existe no servidor. Use `gowa device list` primeiro.

---

### gowa device login

Faz login de um dispositivo via QR code. Inicia o processo de pareamento do WhatsApp Web.

**Sinopse:**
```
gowa device login <device-id>
```

**Argumentos:**

| Argumento | Obrigatorio | Descricao |
|-----------|-------------|-----------|
| `device-id` | **Sim** | ID do dispositivo para login |

**Flags:** Apenas flags globais.

**Exemplos:**
```bash
gowa device login 628xxx
gowa device login 628xxx --json
```

**Codigos de saida:** `0` (sucesso), `1` (erro de parse), `4` (dispositivo nao encontrado), `5` (erro do servidor)

**Notas:**
- Retorna dados do QR code ou informacoes de pareamento do servidor.
- O pareamento deve ser concluido escaneando o QR code no dispositivo fisico.

---

### gowa send text

Envia uma mensagem de texto para um numero de telefone ou JID. Suporta entrada via pipe do stdin.

**Sinopse:**
```
gowa send text [mensagem] [flags]
```

**Flags:**

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--to` | string | `""` | **Obrigatorio (ou `--to-file`).** Numero do destinatario (E.164) ou JID |
| `--to-file` | string | `""` | Arquivo com um numero de telefone por linha para envio em lote |
| `--reply` | string | `""` | ID da mensagem para responder |
| `--dry-run` | bool | `false` | Valida entradas e visualiza a requisicao sem enviar |

**Exemplos:**
```bash
# Mensagem de texto simples
gowa send text --to 5511999999999 "Ola Mundo" --accept-risk

# Responder a uma mensagem especifica
gowa send text --to 5511999999999 "Esta e uma resposta" --reply MSG_ID --accept-risk

# Pipe de mensagem via stdin (amigavel para agentes)
echo "Notificacao automatica" | gowa send text --to 5511999999999 --accept-risk

# Dry-run — validar sem enviar
gowa send text --to 5511999999999 "Ola" --dry-run --accept-risk

# Envio em lote para multiplos destinatarios de um arquivo
gowa send text --to-file destinatarios.txt "Ola a todos" --accept-risk

# Dry-run em lote
gowa send text --to-file destinatarios.txt "Ola" --dry-run --accept-risk
```

**Codigos de saida:** `0` (sucesso), `2` (`--accept-risk` ausente, entrada invalida), `3` (erro de auth), `5` (erro do servidor), `6` (rate limited)

**Notas:**
- **Aceitacao de risco obrigatoria.** O primeiro uso requer a flag `--accept-risk` ou `risk_accepted: true` na config.
- Validacao de telefone: 10-15 digitos, opcionalmente com sufixo `@s.whatsapp.net`.
- Leitura do stdin limitada a 64 KB.
- Se executado em TTY sem argumentos ou stdin, retorna um erro.
- `--to` e `--to-file` sao mutuamente exclusivos. O arquivo de destinatarios suporta comentarios (`#`) e linhas em branco.
- Envios em lote incluem atraso de 2 segundos entre destinatarios. Para imediatamente em caso de rate limit (HTTP 429).

---

### gowa send image

Envia um arquivo de imagem com legenda opcional.

**Sinopse:**
```
gowa send image [flags]
```

**Flags:**

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--to` | string | `""` | **Obrigatorio (ou `--to-file`).** Numero do destinatario ou JID |
| `--to-file` | string | `""` | Arquivo com um numero de telefone por linha para envio em lote |
| `--file` | string | `""` | **Obrigatorio.** Caminho do arquivo de imagem |
| `--caption` | string | `""` | Legenda da imagem |
| `--dry-run` | bool | `false` | Valida entradas e visualiza a requisicao sem enviar |

**Exemplos:**
```bash
gowa send image --to 5511999999999 --file foto.jpg --accept-risk
gowa send image --to 5511999999999 --file foto.jpg --caption "Olha isso!" --accept-risk
gowa send image --to 5511999999999 --file /tmp/screenshot.png --json --accept-risk

# Dry-run — validar arquivo e destinatario sem enviar
gowa send image --to 5511999999999 --file foto.jpg --dry-run --accept-risk

# Envio em lote de imagem para multiplos destinatarios
gowa send image --to-file destinatarios.txt --file foto.jpg --accept-risk
```

**Codigos de saida:** `0` (sucesso), `2` (flags ausentes, arquivo invalido, extensao nao suportada, `--accept-risk` ausente), `3` (erro de auth), `5` (erro do servidor), `6` (rate limited)

**Notas:**
- **Extensoes de imagem permitidas:** `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`
- O arquivo deve existir e ser um arquivo regular (nao um diretorio).
- Aceitacao de risco obrigatoria (mesmo que `send text`).
- `--to` e `--to-file` sao mutuamente exclusivos.

---

### gowa send file

Envia um documento ou arquivo anexo.

**Sinopse:**
```
gowa send file [flags]
```

**Flags:**

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--to` | string | `""` | **Obrigatorio (ou `--to-file`).** Numero do destinatario ou JID |
| `--to-file` | string | `""` | Arquivo com um numero de telefone por linha para envio em lote |
| `--file` | string | `""` | **Obrigatorio.** Caminho do arquivo |
| `--dry-run` | bool | `false` | Valida entradas e visualiza a requisicao sem enviar |

**Exemplos:**
```bash
gowa send file --to 5511999999999 --file relatorio.pdf --accept-risk
gowa send file --to 5511999999999 --file dados.xlsx --json --accept-risk

# Dry-run — validar arquivo e destinatario sem enviar
gowa send file --to 5511999999999 --file relatorio.pdf --dry-run --accept-risk

# Envio em lote de arquivo para multiplos destinatarios
gowa send file --to-file destinatarios.txt --file relatorio.pdf --accept-risk
```

**Codigos de saida:** `0` (sucesso), `2` (flags ausentes, arquivo nao encontrado, `--accept-risk` ausente), `3` (erro de auth), `5` (erro do servidor), `6` (rate limited)

**Notas:**
- Sem restricao de extensao (diferente de `send image`). Qualquer tipo de arquivo e aceito.
- O arquivo deve existir e ser um arquivo regular.
- Aceitacao de risco obrigatoria.
- `--to` e `--to-file` sao mutuamente exclusivos.

---

### gowa chat list

Lista conversas com filtro de busca opcional.

**Sinopse:**
```
gowa chat list [flags]
```

**Flags:**

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--limit` | int | `25` | Numero maximo de chats a retornar |
| `--search` | string | `""` | Filtro de busca (corresponde ao nome do chat) |

**Colunas de saida:** `JID`, `NAME`, `LAST MESSAGE`, `UNREAD`

**Exemplos:**
```bash
gowa chat list
gowa chat list --limit 20 --search "joao"
gowa chat list --json
```

**Codigos de saida:** `0` (sucesso), `3` (erro de auth), `5` (erro do servidor)

---

### gowa chat messages

Recupera o historico de mensagens de um chat especifico.

**Sinopse:**
```
gowa chat messages <jid> [flags]
```

**Argumentos:**

| Argumento | Obrigatorio | Descricao |
|-----------|-------------|-----------|
| `jid` | **Sim** | JID do chat (numero de telefone ou JID de grupo) |

**Flags:**

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--limit` | int | `50` | Numero maximo de mensagens |
| `--since` | string | `""` | Filtro de data inicial (formato RFC3339) |
| `--until` | string | `""` | Filtro de data final (formato RFC3339) |
| `--search` | string | `""` | Busca no texto da mensagem |

**Colunas de saida:** `ID`, `FROM`, `TYPE`, `TEXT`, `STATUS`

**Exemplos:**
```bash
gowa chat messages 5511999999999
gowa chat messages 5511999999999 --limit 50 --since 2024-01-15T00:00:00Z
gowa chat messages JID_GRUPO --json --search "reuniao"
```

**Codigos de saida:** `0` (sucesso), `2` (formato de data invalido), `3` (erro de auth), `4` (chat nao encontrado), `5` (erro do servidor)

**Notas:**
- Valores de data devem estar no formato RFC3339 (ex: `2024-01-15T10:30:00Z`).
- Formatos de data invalidos produzem um erro descritivo com o formato esperado.

---

### gowa api

Acesso direto a API (escape hatch). Faz chamadas HTTP brutas para qualquer endpoint do servidor GOWA.

**Sinopse:**
```
gowa api <metodo> <caminho> [flags]
```

**Argumentos:**

| Argumento | Obrigatorio | Descricao |
|-----------|-------------|-----------|
| `metodo` | **Sim** | Metodo HTTP (`GET`, `POST`, `PUT`, `DELETE`, etc.) |
| `caminho` | **Sim** | Caminho do endpoint da API (ex: `/devices`) |

**Flags:**

| Flag | Tipo | Padrao | Descricao |
|------|------|--------|-----------|
| `--field` | string[] | `nil` | Campo do corpo da requisicao como `chave=valor` (repetivel) |
| `--query` | string[] | `nil` | Parametro de query como `chave=valor` (repetivel) |
| `--input` | string | `""` | Le o corpo da requisicao de um arquivo (use `-` para stdin) |

**Exemplos:**
```bash
# Requisicao GET
gowa api GET /devices

# GET com parametros de query
gowa api GET /chats --query limit=10 --query search=joao

# POST com campos inline
gowa api POST /send/message --field phone=5511999 --field message="Ola" --accept-risk

# POST com corpo JSON de arquivo
gowa api POST /send/message --input body.json --accept-risk

# DELETE
gowa api DELETE /devices/123
```

**Codigos de saida:** Todos os codigos de saida podem se aplicar dependendo do endpoint chamado.

**Notas:**
- O caminho recebe automaticamente um `/` inicial se ausente.
- Endpoints `POST /send/*` requerem `--accept-risk` (mesma verificacao dos comandos `send`).
- Valores de `--field` sao combinados em um objeto JSON. `--input` le JSON bruto.
- A resposta e sempre impressa como JSON indentado, independente da flag `--json`.

---

### gowa completion

Gera scripts de completacao de shell para bash, zsh, fish ou powershell.

**Sinopse:**
```
gowa completion [bash|zsh|fish|powershell]
```

**Argumentos:**

| Argumento | Obrigatorio | Valores Validos | Descricao |
|-----------|-------------|----------------|-----------|
| `shell` | **Sim** | `bash`, `zsh`, `fish`, `powershell` | Shell alvo |

**Exemplos:**
```bash
# Bash — carregar diretamente
source <(gowa completion bash)

# Bash — persistir
gowa completion bash > /etc/bash_completion.d/gowa

# Zsh
gowa completion zsh > "${fpath[1]}/_gowa"

# Fish
gowa completion fish | source
gowa completion fish > ~/.config/fish/completions/gowa.fish

# PowerShell
gowa completion powershell | Out-String | Invoke-Expression
```

**Codigos de saida:** `0` (sucesso), `2` (argumento invalido)

---

### gowa version

Exibe a versao da CLI, hash do commit e data de build.

**Sinopse:**
```
gowa version [flags]
```

**Flags:** `--json`, `--quiet` (das flags globais).

**Campos de saida:** `cli_version`, `commit`, `build_date`

**Exemplos:**
```bash
# Formato tabela
gowa version

# Formato JSON
gowa version --json

# Quiet — apenas a string da versao
gowa version --quiet
```

**Codigos de saida:** `0` (sempre bem-sucedido)

---

---

# Espanol

## Indice

- [Flags Globales](#flags-globales)
- [Codigos de Salida](#codigos-de-salida)
- [Variables de Entorno](#variables-de-entorno)
- [Formatos de Salida](#formatos-de-salida)
- [Comandos](#comandos-2)
  - [gowa (raiz)](#gowa-raiz-1)
  - [gowa auth login](#gowa-auth-login-2)
  - [gowa auth status](#gowa-auth-status-2)
  - [gowa auth logout](#gowa-auth-logout-2)
  - [gowa device list](#gowa-device-list-2)
  - [gowa device status](#gowa-device-status-2)
  - [gowa device use](#gowa-device-use-2)
  - [gowa device login](#gowa-device-login-2)
  - [gowa send text](#gowa-send-text-2)
  - [gowa send image](#gowa-send-image-2)
  - [gowa send file](#gowa-send-file-2)
  - [gowa chat list](#gowa-chat-list-2)
  - [gowa chat messages](#gowa-chat-messages-2)
  - [gowa api](#gowa-api-2)
  - [gowa completion](#gowa-completion-2)
  - [gowa version](#gowa-version-2)

---

## Flags Globales

Estas flags estan disponibles en **todos** los comandos.

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--json` | bool | `false` | Salida en formato JSON |
| `--quiet` | bool | `false` | Salida minima (solo valores) |
| `--device` | string | `""` | Sobreescribe el JID del dispositivo (ignora config por defecto) |
| `--api-url` | string | `""` | Sobreescribe la URL del servidor GOWA (ignora config por defecto) |
| `--no-color` | bool | `false` | Deshabilita salida con color |
| `--accept-risk` | bool | `false` | Acepta los riesgos de usar la API no oficial de WhatsApp |
| `--timeout` | string | `"30s"` | Timeout de solicitud HTTP (ej: `10s`, `1m`, `2m30s`) |

> **Nota:** La flag `--dry-run` esta disponible en todos los subcomandos `send` (text, image, file). Vea la documentacion de cada comando.

---

## Codigos de Salida

| Codigo | Nombre | Descripcion |
|--------|--------|-------------|
| `0` | Exito | Comando completado exitosamente |
| `1` | Error General | Error inesperado, error de parseo o fallo desconocido |
| `2` | Error de Uso | Solicitud invalida (HTTP 400), conflicto (HTTP 409) o `--accept-risk` ausente |
| `3` | Error de Auth | Autenticacion fallida (HTTP 401/403) |
| `4` | No Encontrado | Recurso no encontrado (HTTP 404) |
| `5` | Error de Servidor | Servidor GOWA inalcanzable o retorno 5xx |
| `6` | Rate Limit | Servidor retorno HTTP 429 (demasiadas solicitudes) |

---

## Variables de Entorno

Todas las variables usan el prefijo `GOWA_` y se mapean a claves de configuracion.

| Variable | Clave Config | Por defecto | Descripcion |
|----------|-------------|-------------|-------------|
| `GOWA_API_URL` | `api_url` | `http://localhost:3000` | URL del servidor GOWA |
| `GOWA_USERNAME` | `username` | `""` | Usuario para autenticacion basica |
| `GOWA_PASSWORD` | `password` | `""` | Contrasena para autenticacion basica |
| `GOWA_DEVICE_ID` | `device_id` | `""` | JID del dispositivo por defecto |
| `GOWA_OUTPUT` | `output` | `table` | Formato de salida por defecto |
| `GOWA_RISK_ACCEPTED` | `risk_accepted` | `false` | Omitir aviso de riesgo para operaciones de envio |
| `GOWA_TIMEOUT` | `timeout` | `30s` | Timeout de solicitud HTTP (cadena de duracion Go) |

Ubicacion del archivo de configuracion: `~/.config/gowa/config.yaml` (permisos: `0600`)

---

## Formatos de Salida

La CLI soporta tres modos de salida. El formato se auto-detecta a partir de las flags.

### Tabla (por defecto)

```
$ gowa device list
ID                            STATUS    PHONE          NAME
628xxx@s.whatsapp.net         connected 628123456789   My Phone
629xxx@s.whatsapp.net         disconnected 629987654321 Work Phone
```

### JSON (`--json`)

```json
$ gowa device list --json
[
  {
    "id": "628xxx@s.whatsapp.net",
    "status": "connected",
    "phone": "628123456789",
    "name": "My Phone"
  }
]
```

### Quiet (`--quiet`)

```
$ gowa version --quiet
1.2.0
```

---

## Comandos

### gowa (raiz)

CLI para WhatsApp impulsada por la API REST GOWA. Proporciona comandos amigables para agentes para envio de mensajes, gestion de dispositivos, grupos y mas.

**Sinopsis:**
```
gowa [comando] [flags]
```

**Subcomandos disponibles:** `auth`, `device`, `send`, `chat`, `api`, `completion`, `version`

**Ejemplos:**
```bash
# Inicio rapido
gowa auth login --api-url http://localhost:3000 --username admin --password secret
gowa device list
gowa send text --to 5511999999999 "Hola desde CLI"
```

---

### gowa auth login

Autenticarse con un servidor GOWA. Almacena credenciales en el archivo de configuracion. Soporta modo interactivo cuando se ejecuta en TTY sin flags.

**Sinopsis:**
```
gowa auth login [flags]
```

**Flags:**

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--api-url` | string | `""` | URL del servidor GOWA |
| `--url` | string | `""` | *(Obsoleta: use `--api-url`)* Alias para `--api-url` |
| `--username` | string | `""` | Usuario para autenticacion basica |
| `--password` | string | `""` | Contrasena para autenticacion basica |

**Ejemplos:**
```bash
# No interactivo (scripts, CI/CD, agentes)
gowa auth login --api-url http://localhost:3000 --username admin --password secret

# Modo interactivo (solicita cada campo)
gowa auth login

# Sobreescribir solo la URL, solicitar credenciales
gowa auth login --api-url http://192.168.1.100:3000
```

**Codigos de salida:** `0` (exito), `1` (error de parseo), `3` (auth fallida), `5` (servidor inalcanzable)

**Notas:**
- En modo interactivo (TTY), las flags ausentes activan prompts con valores por defecto de la configuracion existente.
- En modo no interactivo (pipe/CI), `--username` y `--password` son obligatorios.
- El login valida credenciales llamando a `GET /devices` antes de guardar.
- La configuracion se guarda en `~/.config/gowa/config.yaml` con permisos `0600`.

---

### gowa auth status

Muestra el estado actual de autenticacion, salud de la conexion y conteo de dispositivos.

**Sinopsis:**
```
gowa auth status
```

**Flags:** Solo flags globales.

**Ejemplos:**
```bash
gowa auth status
gowa auth status --json
```

**Campos de salida:** `api_url`, `authenticated`, `username`, `connected`, `device_count`, `default_device`, `config_path`

**Codigos de salida:** `0` (exito), `5` (servidor inalcanzable)

**Notas:**
- Prueba la conexion en vivo llamando a `GET /devices`.
- `authenticated` indica si existen credenciales en la config; `connected` indica si el servidor respondio exitosamente.

---

### gowa auth logout

Elimina credenciales almacenadas del archivo de configuracion. No invalida sesiones en el servidor.

**Sinopsis:**
```
gowa auth logout
```

**Flags:** Solo flags globales.

**Ejemplos:**
```bash
gowa auth logout
gowa auth logout --json
```

**Codigos de salida:** `0` (exito), `1` (error al guardar config)

**Notas:**
- Solo limpia `username` y `password` de la config. Otras configuraciones (`api_url`, `device_id`) se preservan.

---

### gowa device list

Lista todos los dispositivos WhatsApp registrados en el servidor.

**Sinopsis:**
```
gowa device list
```

**Flags:** Solo flags globales.

**Columnas de salida:** `ID`, `STATUS`, `PHONE`, `NAME`

**Ejemplos:**
```bash
gowa device list
gowa device list --json
gowa device list --quiet
```

**Codigos de salida:** `0` (exito), `3` (error de auth), `5` (error del servidor)

---

### gowa device status

Verifica el estado de conexion de un dispositivo especifico.

**Sinopsis:**
```
gowa device status [device-id]
```

**Argumentos:**

| Argumento | Obligatorio | Descripcion |
|-----------|-------------|-------------|
| `device-id` | No | JID del dispositivo. Usa el dispositivo por defecto de la config si se omite. |

**Flags:** Solo flags globales.

**Ejemplos:**
```bash
gowa device status
gowa device status 628xxx@s.whatsapp.net
gowa device status 628xxx@s.whatsapp.net --json
```

**Codigos de salida:** `0` (exito), `1` (ningun dispositivo especificado), `4` (dispositivo no encontrado), `5` (error del servidor)

**Notas:**
- Si no se proporciona argumento, usa el dispositivo por defecto definido con `gowa device use`.
- Falla con error si no se especifica dispositivo y no hay uno por defecto configurado.

---

### gowa device use

Establece un dispositivo por defecto para todos los comandos subsiguientes. Persiste la seleccion en la configuracion.

**Sinopsis:**
```
gowa device use <device-id>
```

**Argumentos:**

| Argumento | Obligatorio | Descripcion |
|-----------|-------------|-------------|
| `device-id` | **Si** | JID del dispositivo a establecer como por defecto |

**Flags:** Solo flags globales.

**Ejemplos:**
```bash
# Encontrar el ID del dispositivo primero
gowa device list

# Establecer dispositivo por defecto
gowa device use 628xxx@s.whatsapp.net
```

**Codigos de salida:** `0` (exito), `1` (error al guardar config), `2` (argumento ausente)

**Notas:**
- No valida si el dispositivo existe en el servidor. Use `gowa device list` primero.

---

### gowa device login

Inicia sesion de un dispositivo via codigo QR. Inicia el proceso de emparejamiento de WhatsApp Web.

**Sinopsis:**
```
gowa device login <device-id>
```

**Argumentos:**

| Argumento | Obligatorio | Descripcion |
|-----------|-------------|-------------|
| `device-id` | **Si** | ID del dispositivo para iniciar sesion |

**Flags:** Solo flags globales.

**Ejemplos:**
```bash
gowa device login 628xxx
gowa device login 628xxx --json
```

**Codigos de salida:** `0` (exito), `1` (error de parseo), `4` (dispositivo no encontrado), `5` (error del servidor)

**Notas:**
- Retorna datos del codigo QR o informacion de emparejamiento del servidor.
- El emparejamiento debe completarse escaneando el codigo QR en el dispositivo fisico.

---

### gowa send text

Envia un mensaje de texto a un numero de telefono o JID. Soporta entrada por pipe desde stdin.

**Sinopsis:**
```
gowa send text [mensaje] [flags]
```

**Flags:**

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--to` | string | `""` | **Obligatorio (o `--to-file`).** Numero del destinatario (E.164) o JID |
| `--to-file` | string | `""` | Archivo con un numero de telefono por linea para envio por lotes |
| `--reply` | string | `""` | ID del mensaje a responder |
| `--dry-run` | bool | `false` | Valida entradas y visualiza la solicitud sin enviar |

**Ejemplos:**
```bash
# Mensaje de texto simple
gowa send text --to 5511999999999 "Hola Mundo" --accept-risk

# Responder a un mensaje especifico
gowa send text --to 5511999999999 "Esta es una respuesta" --reply MSG_ID --accept-risk

# Pipe de mensaje via stdin (amigable para agentes)
echo "Notificacion automatica" | gowa send text --to 5511999999999 --accept-risk

# Dry-run — validar sin enviar
gowa send text --to 5511999999999 "Hola" --dry-run --accept-risk

# Envio por lotes a multiples destinatarios desde un archivo
gowa send text --to-file destinatarios.txt "Hola a todos" --accept-risk

# Dry-run por lotes
gowa send text --to-file destinatarios.txt "Hola" --dry-run --accept-risk
```

**Codigos de salida:** `0` (exito), `2` (`--accept-risk` ausente, entrada invalida), `3` (error de auth), `5` (error del servidor), `6` (rate limited)

**Notas:**
- **Aceptacion de riesgo obligatoria.** El primer uso requiere la flag `--accept-risk` o `risk_accepted: true` en la config.
- Validacion de telefono: 10-15 digitos, opcionalmente con sufijo `@s.whatsapp.net`.
- Lectura de stdin limitada a 64 KB.
- Si se ejecuta en TTY sin argumentos ni stdin, retorna un error.
- `--to` y `--to-file` son mutuamente exclusivos. El archivo de destinatarios soporta comentarios (`#`) y lineas en blanco.
- Los envios por lotes incluyen un retraso de 2 segundos entre destinatarios. Se detiene inmediatamente en caso de rate limit (HTTP 429).

---

### gowa send image

Envia un archivo de imagen con leyenda opcional.

**Sinopsis:**
```
gowa send image [flags]
```

**Flags:**

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--to` | string | `""` | **Obligatorio (o `--to-file`).** Numero del destinatario o JID |
| `--to-file` | string | `""` | Archivo con un numero de telefono por linea para envio por lotes |
| `--file` | string | `""` | **Obligatorio.** Ruta al archivo de imagen |
| `--caption` | string | `""` | Leyenda de la imagen |
| `--dry-run` | bool | `false` | Valida entradas y visualiza la solicitud sin enviar |

**Ejemplos:**
```bash
gowa send image --to 5511999999999 --file foto.jpg --accept-risk
gowa send image --to 5511999999999 --file foto.jpg --caption "Mira esto!" --accept-risk
gowa send image --to 5511999999999 --file /tmp/screenshot.png --json --accept-risk

# Dry-run — validar archivo y destinatario sin enviar
gowa send image --to 5511999999999 --file foto.jpg --dry-run --accept-risk

# Envio por lotes de imagen a multiples destinatarios
gowa send image --to-file destinatarios.txt --file foto.jpg --accept-risk
```

**Codigos de salida:** `0` (exito), `2` (flags ausentes, archivo invalido, extension no soportada, `--accept-risk` ausente), `3` (error de auth), `5` (error del servidor), `6` (rate limited)

**Notas:**
- **Extensiones de imagen permitidas:** `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`
- El archivo debe existir y ser un archivo regular (no un directorio).
- Aceptacion de riesgo obligatoria (igual que `send text`).
- `--to` y `--to-file` son mutuamente exclusivos.

---

### gowa send file

Envia un documento o archivo adjunto.

**Sinopsis:**
```
gowa send file [flags]
```

**Flags:**

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--to` | string | `""` | **Obligatorio (o `--to-file`).** Numero del destinatario o JID |
| `--to-file` | string | `""` | Archivo con un numero de telefono por linea para envio por lotes |
| `--file` | string | `""` | **Obligatorio.** Ruta al archivo |
| `--dry-run` | bool | `false` | Valida entradas y visualiza la solicitud sin enviar |

**Ejemplos:**
```bash
gowa send file --to 5511999999999 --file reporte.pdf --accept-risk
gowa send file --to 5511999999999 --file datos.xlsx --json --accept-risk

# Dry-run — validar archivo y destinatario sin enviar
gowa send file --to 5511999999999 --file reporte.pdf --dry-run --accept-risk

# Envio por lotes de archivo a multiples destinatarios
gowa send file --to-file destinatarios.txt --file reporte.pdf --accept-risk
```

**Codigos de salida:** `0` (exito), `2` (flags ausentes, archivo no encontrado, `--accept-risk` ausente), `3` (error de auth), `5` (error del servidor), `6` (rate limited)

**Notas:**
- Sin restriccion de extension (a diferencia de `send image`). Cualquier tipo de archivo es aceptado.
- El archivo debe existir y ser un archivo regular.
- Aceptacion de riesgo obligatoria.
- `--to` y `--to-file` son mutuamente exclusivos.

---

### gowa chat list

Lista conversaciones con filtro de busqueda opcional.

**Sinopsis:**
```
gowa chat list [flags]
```

**Flags:**

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--limit` | int | `25` | Numero maximo de chats a retornar |
| `--search` | string | `""` | Filtro de busqueda (coincide con nombre del chat) |

**Columnas de salida:** `JID`, `NAME`, `LAST MESSAGE`, `UNREAD`

**Ejemplos:**
```bash
gowa chat list
gowa chat list --limit 20 --search "juan"
gowa chat list --json
```

**Codigos de salida:** `0` (exito), `3` (error de auth), `5` (error del servidor)

---

### gowa chat messages

Recupera el historial de mensajes de un chat especifico.

**Sinopsis:**
```
gowa chat messages <jid> [flags]
```

**Argumentos:**

| Argumento | Obligatorio | Descripcion |
|-----------|-------------|-------------|
| `jid` | **Si** | JID del chat (numero de telefono o JID de grupo) |

**Flags:**

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--limit` | int | `50` | Numero maximo de mensajes |
| `--since` | string | `""` | Filtro de fecha inicial (formato RFC3339) |
| `--until` | string | `""` | Filtro de fecha final (formato RFC3339) |
| `--search` | string | `""` | Busqueda en texto del mensaje |

**Columnas de salida:** `ID`, `FROM`, `TYPE`, `TEXT`, `STATUS`

**Ejemplos:**
```bash
gowa chat messages 5511999999999
gowa chat messages 5511999999999 --limit 50 --since 2024-01-15T00:00:00Z
gowa chat messages JID_GRUPO --json --search "reunion"
```

**Codigos de salida:** `0` (exito), `2` (formato de fecha invalido), `3` (error de auth), `4` (chat no encontrado), `5` (error del servidor)

**Notas:**
- Los valores de fecha deben estar en formato RFC3339 (ej: `2024-01-15T10:30:00Z`).
- Formatos de fecha invalidos producen un error descriptivo con el formato esperado.

---

### gowa api

Acceso directo a la API (escape hatch). Realiza llamadas HTTP crudas a cualquier endpoint del servidor GOWA.

**Sinopsis:**
```
gowa api <metodo> <ruta> [flags]
```

**Argumentos:**

| Argumento | Obligatorio | Descripcion |
|-----------|-------------|-------------|
| `metodo` | **Si** | Metodo HTTP (`GET`, `POST`, `PUT`, `DELETE`, etc.) |
| `ruta` | **Si** | Ruta del endpoint de la API (ej: `/devices`) |

**Flags:**

| Flag | Tipo | Por defecto | Descripcion |
|------|------|-------------|-------------|
| `--field` | string[] | `nil` | Campo del cuerpo de la solicitud como `clave=valor` (repetible) |
| `--query` | string[] | `nil` | Parametro de query como `clave=valor` (repetible) |
| `--input` | string | `""` | Lee el cuerpo de la solicitud de un archivo (use `-` para stdin) |

**Ejemplos:**
```bash
# Solicitud GET
gowa api GET /devices

# GET con parametros de query
gowa api GET /chats --query limit=10 --query search=juan

# POST con campos inline
gowa api POST /send/message --field phone=5511999 --field message="Hola" --accept-risk

# POST con cuerpo JSON desde archivo
gowa api POST /send/message --input body.json --accept-risk

# DELETE
gowa api DELETE /devices/123
```

**Codigos de salida:** Todos los codigos de salida pueden aplicar dependiendo del endpoint llamado.

**Notas:**
- La ruta recibe automaticamente un `/` inicial si esta ausente.
- Endpoints `POST /send/*` requieren `--accept-risk` (misma verificacion que los comandos `send`).
- Los valores de `--field` se combinan en un objeto JSON. `--input` lee JSON crudo.
- La respuesta siempre se imprime como JSON indentado, independiente de la flag `--json`.

---

### gowa completion

Genera scripts de completado de shell para bash, zsh, fish o powershell.

**Sinopsis:**
```
gowa completion [bash|zsh|fish|powershell]
```

**Argumentos:**

| Argumento | Obligatorio | Valores Validos | Descripcion |
|-----------|-------------|----------------|-------------|
| `shell` | **Si** | `bash`, `zsh`, `fish`, `powershell` | Shell destino |

**Ejemplos:**
```bash
# Bash — cargar directamente
source <(gowa completion bash)

# Bash — persistir
gowa completion bash > /etc/bash_completion.d/gowa

# Zsh
gowa completion zsh > "${fpath[1]}/_gowa"

# Fish
gowa completion fish | source
gowa completion fish > ~/.config/fish/completions/gowa.fish

# PowerShell
gowa completion powershell | Out-String | Invoke-Expression
```

**Codigos de salida:** `0` (exito), `2` (argumento invalido)

---

### gowa version

Muestra la version de la CLI, hash del commit y fecha de compilacion.

**Sinopsis:**
```
gowa version [flags]
```

**Flags:** `--json`, `--quiet` (de las flags globales).

**Campos de salida:** `cli_version`, `commit`, `build_date`

**Ejemplos:**
```bash
# Formato tabla
gowa version

# Formato JSON
gowa version --json

# Quiet — solo la cadena de version
gowa version --quiet
```

**Codigos de salida:** `0` (siempre exitoso)
