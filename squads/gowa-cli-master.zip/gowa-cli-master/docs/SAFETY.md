# GOWA CLI Safety Layer

[English](#english) | [Portugues](#portugues) | [Espanol](#espanol)

---

# English

## Table of Contents

1. [Why a Safety Layer?](#why-a-safety-layer)
2. [Risk Acknowledgment Gate](#risk-acknowledgment-gate)
3. [Rate Limiter](#rate-limiter)
4. [Persistent State](#persistent-state)
5. [Input Validation](#input-validation)
6. [Audit Log](#audit-log)
7. [Error Architecture](#error-architecture)
8. [HTTP Client Safety](#http-client-safety)
9. [For AI Agents](#for-ai-agents)
10. [Configuration](#configuration)
11. [Troubleshooting](#troubleshooting)

---

## Why a Safety Layer?

GOWA CLI wraps an **unofficial WhatsApp Web API**. This creates three categories of risk:

| Risk | Consequence | Mitigation |
|------|-------------|------------|
| **WhatsApp account ban** | Permanent loss of phone number on WhatsApp | Rate limiter, risk gate |
| **Unofficial API instability** | Breaking changes, no SLA, no support | No retry on send, audit trail |
| **AI agent automation loops** | Thousands of messages in seconds | Rate limits, input validation, exit codes |

WhatsApp actively detects and bans accounts that exhibit bot-like behavior: high message volume, repeated identical messages, or rapid-fire sends. The safety layer exists to make it **structurally impossible** to trigger these patterns, even when the CLI is driven by an AI agent in a retry loop.

**Design philosophy:** Every safety mechanism defaults to **deny**. The system must be explicitly told to proceed at each gate, and every send operation is counted *before* it happens (fail-safe).

---

## Risk Acknowledgment Gate

Before any `send` subcommand executes, the CLI requires explicit acknowledgment that the user understands the risks of using an unofficial API.

### Flow

```
gowa send text --to 5511999999999 "Hello"
  --> ERROR (exit code 2): Risk acknowledgment required

gowa send text --to 5511999999999 "Hello" --accept-risk
  --> WARNING printed to stderr
  --> risk_accepted: true written to ~/.config/gowa/config.yaml
  --> Command executes

gowa send text --to 5511999999999 "Hello"
  --> (subsequent runs) risk already accepted, command executes silently
```

### How It Works

1. `sendCmd.PersistentPreRunE` calls `checkAcceptRisk()` before every send subcommand
2. Checks `config.GetBool("risk_accepted")` -- if `true`, passes silently
3. If `--accept-risk` flag is present: persists `risk_accepted: true` to config, prints warning to stderr, continues
4. Otherwise: returns `CLIError` with exit code **2**

### Warning Message

```
WARNING: Unofficial WhatsApp API
This CLI uses an unofficial WhatsApp Web API. Using it may result in:
  - Temporary or permanent ban of your WhatsApp number
  - Loss of message history and contacts

Recommendations:
  - Use a disposable phone number (not your primary)
  - Consider the official WhatsApp Business API for production use

Risk acknowledged. This warning will not appear again.
```

### Persisting via Config File

Instead of passing `--accept-risk` on every invocation, add directly to `~/.config/gowa/config.yaml`:

```yaml
risk_accepted: true
```

---

## Rate Limiter

### Three Design Principles

1. **Count before send (fail-safe):** The timestamp is recorded in state *before* the HTTP request fires. If the request fails or the process crashes, the message is still counted. This prevents under-counting.
2. **Atomic check-and-record:** `CheckAndRecordSend()` acquires a single file lock, checks limits, records the timestamp, and saves -- all in one critical section. This eliminates TOCTOU (Time-of-Check-Time-of-Use) race conditions.
3. **Conservative defaults:** Limits are intentionally low to stay well below WhatsApp's detection thresholds.

### Default Limits

| Window | Limit | Rationale |
|--------|-------|-----------|
| Per minute | **3** | Prevents burst sends that look bot-like |
| Per hour | **30** | Stays under hourly detection thresholds |
| Per day (24h) | **200** | Conservative daily cap for account safety |

### Rate Limiter Decision Flow

```
                    +------------------+
                    | Send requested   |
                    +--------+---------+
                             |
                    +--------v---------+
                    | Acquire file lock |
                    | (state.json.lock)|
                    +--------+---------+
                             |
                    +--------v---------+
                    | Read state.json  |
                    +--------+---------+
                             |
                    +--------v---------+
                    | Clean expired    |
                    | entries (>24h)   |
                    +--------+---------+
                             |
              +--------------v--------------+
              | Count msgs in each window:  |
              | - last 1 min  >= 3?  BLOCK  |
              | - last 1 hour >= 30? BLOCK  |
              | - last 24 hrs >= 200? BLOCK |
              +---------+----------+--------+
                        |          |
                   ALLOWED      BLOCKED
                        |          |
               +--------v---+  +--v--------------+
               | Append now |  | Return error    |
               | to state   |  | with wait time  |
               +--------+---+  | (exit code 6)   |
                        |      +-----------------+
               +--------v--------+
               | Save state.json |
               | (atomic rename) |
               +--------+--------+
                        |
               +--------v--------+
               | Release lock    |
               +--------+--------+
                        |
               +--------v--------+
               | HTTP POST /send |
               +-----------------+
```

### Wait Time Calculation

When a limit is exceeded, the error message includes the number of seconds to wait. This is calculated as:

```
waitSeconds = ceil(windowDuration - timeSinceOldestEntryInWindow)
```

Example error: `Rate limit exceeded: 3 messages sent in last minute. Wait 42 seconds before sending again.`

---

## Persistent State

Rate limiter state persists across CLI invocations in a JSON file.

### File Location

```
~/.config/gowa/state.json
```

### File Format

```json
{
  "messages_sent": [
    "2026-03-19T10:30:00Z",
    "2026-03-19T10:30:25Z",
    "2026-03-19T10:30:50Z"
  ]
}
```

### Safety Mechanisms

| Mechanism | Implementation | Purpose |
|-----------|---------------|---------|
| **Atomic writes** | Write to `.tmp` then `os.Rename()` | Prevents corruption on crash |
| **File locking** | `flock` (POSIX advisory lock) via `state.json.lock` | Safe concurrent access |
| **24h cleanup** | `CleanExpiredEntries()` removes timestamps older than 24h | Keeps file compact |
| **Permissions** | File created with `0600`, directory with `0700` | Only owner can read/write |
| **Unparseable preservation** | Entries that fail RFC3339 parsing are kept | Prevents silent data loss |

### Concurrency Model

```
Process A: Lock -> Read -> Check -> Record -> Save -> Unlock
Process B:        [waits]                             Lock -> Read -> ...
```

The `flock` library provides blocking advisory locks. If process A holds the lock, process B blocks until A releases it.

---

## Input Validation

All user inputs are validated before any network call. Validation functions are in `internal/safety/validate.go`.

### Phone Number (`ValidatePhone`)

- **Regex:** `^\d{10,15}(@s\.whatsapp\.net)?$`
- Accepts E.164 format: `5511999999999` (10-15 digits)
- Accepts WhatsApp JID: `5511999999999@s.whatsapp.net`
- Rejects: letters, symbols, country code with `+`, numbers shorter than 10 digits

```
VALID:   5511999999999
VALID:   5511999999999@s.whatsapp.net
INVALID: +5511999999999  (has +)
INVALID: 551199999       (too short)
INVALID: hello           (not digits)
```

### File Path (`ValidateFilePath`)

- Uses `os.Stat()` to verify file exists
- Returns specific errors: "file not found" vs "cannot access" vs "path is a directory"

### File Extension (`ValidateFileExtension`)

- Case-insensitive comparison
- Image whitelist for `send image`: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`
- No extension restriction for `send file` (general document send)

### RFC3339 Date (`ValidateRFC3339`)

- Uses `time.Parse(time.RFC3339, value)` for strict validation
- Example valid format: `2024-01-15T10:30:00Z`
- Error includes the flag name for clear user feedback

---

## Audit Log

Every send operation (success or failure) is logged to a persistent audit trail.

### File Location

```
~/.config/gowa/audit.log
```

### Format: JSON Lines (JSONL)

Each line is a self-contained JSON object:

```jsonl
{"timestamp":"2026-03-19T10:30:00Z","operation":"send_text","recipient":"5511999999999","result":"success"}
{"timestamp":"2026-03-19T10:30:05Z","operation":"send_image","recipient":"5511888888888","result":"error","error_message":"Rate limit exceeded: 3 messages sent in last minute. Wait 42 seconds before sending again."}
```

### AuditEntry Fields

| Field | Type | Description |
|-------|------|-------------|
| `timestamp` | string | UTC RFC3339 timestamp of the operation |
| `operation` | string | `send_text`, `send_image`, or `send_file` |
| `recipient` | string | Phone number or JID |
| `result` | string | `success` or `error` |
| `error_message` | string | Error details (omitted on success) |

### Rotation

- **Threshold:** 1 MB (`maxAuditSize = 1 * 1024 * 1024`)
- **Strategy:** Simple rotation -- current file renamed to `audit.log.1` (overwrites previous `.1`)
- **Keeps:** Current file + 1 rotated file (max ~2 MB total)

### Concurrency

- File locking via `audit.log.lock` (same `flock` pattern as state)
- Append-only writes (`O_APPEND|O_CREATE|O_WRONLY`)
- File permissions: `0600`

---

## Error Architecture

All errors that should produce specific exit codes use the `CLIError` struct.

### CLIError Struct

```go
type CLIError struct {
    Type     string  // Category: "usage_error", "auth_error", "rate_limit", etc.
    Code     int     // Process exit code
    Message  string  // Human-readable error message
    Recovery string  // Actionable hint for the user
    Original error   // Wrapped underlying error (optional)
}
```

### Exit Code Mapping

| Code | Type | Meaning | Example |
|------|------|---------|---------|
| **0** | -- | Success | Command completed |
| **1** | `general` / `parse_error` | General error | Unparseable server response |
| **2** | `usage_error` | Bad usage / risk not accepted | Missing `--accept-risk`, bad request (HTTP 400) |
| **3** | `auth_error` | Authentication failure | HTTP 401/403, invalid credentials |
| **4** | `not_found` | Resource not found | HTTP 404, invalid device/contact |
| **5** | `server_error` | Server unreachable or error | Connection refused, HTTP 5xx |
| **6** | `rate_limit` | Rate limit exceeded | Local limiter or server HTTP 429 |

#### Structured Error Output

```
Rate limit exceeded: 3 messages sent in last minute. Wait 42 seconds before sending again.
  Hint: This limit protects your WhatsApp account from being banned
```

The `Hint:` line provides actionable recovery guidance. AI agents can parse the exit code programmatically.

### JSON Error Output

When the `--json` flag is set, errors are written to **stderr** as structured JSON instead of plain text:

```json
{"error":true,"type":"rate_limit","code":6,"message":"Rate limit exceeded: 3 messages sent in last minute. Wait 42 seconds before sending again.","recovery":"This limit protects your WhatsApp account from being banned"}
```

Fields: `error` (always `true`), `type`, `code` (exit code), `message`, and optionally `recovery`. This allows AI agents and scripts to parse errors programmatically without relying on string matching.

---

## HTTP Client Safety

### No Retry on Send

```go
maxAttempts := 3
if isSend {
    maxAttempts = 1  // POST /send/* NEVER retries
}
```

Send operations (`POST /send/*`) are **not retried** to prevent duplicate WhatsApp messages. If the HTTP request fails, the error is returned immediately. Other operations (GET, DELETE) retry up to 3 times with exponential backoff.

### Send Detection

```go
isSend := req.Method == http.MethodPost && strings.Contains(req.URL.Path, "/send/")
```

### Rate Limit Integration Point

The rate limit check happens inside `Client.do()`, **before** the HTTP request:

```go
if isSend {
    if err := safety.CheckAndRecordSend(c.statePath); err != nil {
        return nil, &CLIError{Type: "rate_limit", Code: 6, ...}
    }
}
```

### Response Body Handling

Response bodies are read immediately and `resp.Body.Close()` is called right after, preventing resource leaks:

```go
respBody, err := io.ReadAll(resp.Body)
resp.Body.Close()  // Close immediately, not deferred
```

---

## Dry-Run Mode

The `--dry-run` flag allows previewing a send operation without actually sending the message. All validations (phone number, file path, file extension, risk acknowledgment) are executed, but no HTTP request is made and no rate limit token is consumed.

### Usage

```bash
# Preview a text message
gowa send text --to 5511999999999 "Hello" --dry-run --json

# Preview a batch send
gowa send text --to-file recipients.txt "Hello everyone" --dry-run --json

# Preview an image send
gowa send image --to 5511999999999 --file photo.jpg --dry-run --json
```

### Dry-Run Output

```json
{"command":"send text","dry_run":true,"message":"Hello","to":"5511999999999","validations_passed":true,"would_send":true}
```

The output includes `dry_run: true` and `would_send: true` to confirm that all validations passed. For batch operations, one entry per recipient is returned.

### Why This Matters for Safety

- **AI agents** should always dry-run before sending to verify parameters are correct
- **No side effects:** no message sent, no rate limit consumed, no audit log entry
- **Catches errors early:** invalid phone numbers, missing files, unsupported extensions are caught without wasting a rate limit token

---

## For AI Agents

The safety layer is specifically designed to protect against common AI agent failure modes.

### Protection Matrix

| Agent Failure Mode | Safety Mechanism | Result |
|-------------------|------------------|--------|
| **Infinite retry loop** | Rate limiter (3/min, 30/hr, 200/day) | Exit code 6 after limit hit |
| **Mass send to contact list** | Rate limiter + persistent state | Blocks after 3 rapid sends |
| **Invalid phone number hallucination** | E.164/JID regex validation | Immediate rejection |
| **File path hallucination** | `os.Stat()` existence check | "file not found" error |
| **Missing risk acknowledgment** | Risk gate (`--accept-risk`) | Exit code 2, cannot proceed |
| **Concurrent send from multiple threads** | File locking (flock) | Serialized, safe counting |
| **Ignoring errors and retrying send** | No retry on POST /send | Single attempt only |
| **Sending without verification** | `--dry-run` flag | Preview before committing |

### Recommended Agent Integration Pattern

```bash
# 1. Accept risk once during setup
gowa send text --to 5511999999999 "test" --accept-risk

# 2. Always dry-run first, then send
gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json --dry-run
if [ $? -eq 0 ]; then
  gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json
fi

# 3. Check exit codes
EXIT_CODE=$?
case $EXIT_CODE in
  0) echo "Sent successfully" ;;
  2) echo "Risk not accepted or bad input" ;;
  6) echo "Rate limited -- DO NOT RETRY IMMEDIATELY" ;;
  *) echo "Error: $EXIT_CODE" ;;
esac

# 4. For batch sending, use --to-file (built-in 2s delay between messages)
gowa send text --to-file recipients.txt "Hello everyone" --accept-risk --json
```

### What Agents MUST NOT Do

1. **Do not retry on exit code 6.** The rate limiter protects the WhatsApp account. Wait for the duration specified in the error message.
2. **Do not bypass the rate limiter** by deleting or modifying `state.json`. The limits exist for account safety.
3. **Do not run multiple concurrent send processes.** File locking handles concurrency safely, but rapid parallel sends will quickly exhaust the per-minute limit.
4. **Do not send without `--dry-run` first.** Always preview the operation to catch validation errors before consuming a rate limit token.

---

## Configuration

### File Paths

| File | Path | Purpose |
|------|------|---------|
| Config | `~/.config/gowa/config.yaml` | CLI settings, risk acceptance |
| State | `~/.config/gowa/state.json` | Rate limiter timestamps |
| Audit | `~/.config/gowa/audit.log` | Send operation log |
| Lock (state) | `~/.config/gowa/state.json.lock` | flock advisory lock |
| Lock (audit) | `~/.config/gowa/audit.log.lock` | flock advisory lock |

### Environment Variables

All config values can be overridden with `GOWA_` prefixed environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `GOWA_API_URL` | `http://localhost:3000` | WhatsApp Web API server URL |
| `GOWA_USERNAME` | (empty) | API basic auth username |
| `GOWA_PASSWORD` | (empty) | API basic auth password |
| `GOWA_DEVICE_ID` | (empty) | WhatsApp device identifier |
| `GOWA_OUTPUT` | `table` | Output format (`table`, `json`) |
| `GOWA_RISK_ACCEPTED` | `false` | Skip risk warning for send operations (set to `true` for CI/CD) |
| `GOWA_TIMEOUT` | `30s` | HTTP request timeout (Go duration format: `10s`, `1m`, `2m30s`) |

### Rate Limit Defaults

The rate limits are currently hardcoded as `DefaultLimits` in `internal/safety/ratelimit.go`:

```go
var DefaultLimits = RateLimits{
    PerMinute: 3,
    PerHour:   30,
    PerDay:    200,
}
```

To adjust limits, modify the source code and rebuild. This is intentional -- rate limits should not be easily overridable to maintain safety guarantees.

---

## Troubleshooting

### "Risk acknowledgment required for send operations" (Exit Code 2)

**Cause:** The `--accept-risk` flag was never passed, and `risk_accepted` is not set in config.

**Fix:**
```bash
# Option A: Pass the flag once
gowa send text --to 5511999999999 "Hello" --accept-risk

# Option B: Set in config file
echo "risk_accepted: true" >> ~/.config/gowa/config.yaml
```

### "Rate limit exceeded" (Exit Code 6)

**Cause:** You have sent too many messages within a time window.

**Fix:** Wait for the duration specified in the error message. Do NOT delete `state.json` -- the limits protect your WhatsApp account.

```bash
# Check current state
cat ~/.config/gowa/state.json

# See how many messages were sent recently
cat ~/.config/gowa/state.json | python3 -c "
import json, sys
from datetime import datetime, timezone
state = json.load(sys.stdin)
for ts in state.get('messages_sent', []):
    print(ts)
print(f'Total: {len(state.get(\"messages_sent\", []))} entries')
"
```

### "invalid phone number" (Validation Error)

**Cause:** Phone number does not match E.164 format.

**Fix:** Use 10-15 digits without `+`, spaces, or dashes:
```bash
# Wrong
gowa send text --to "+55 11 99999-9999" "Hello"

# Correct
gowa send text --to 5511999999999 "Hello"
```

### "file not found" (Validation Error)

**Cause:** The file path does not exist or is inaccessible.

**Fix:** Verify the file exists and use an absolute or correct relative path:
```bash
ls -la /path/to/file.jpg
gowa send image --to 5511999999999 --file /path/to/file.jpg
```

### "unsupported file extension" (Validation Error)

**Cause:** The `send image` command only accepts `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`.

**Fix:** Use `send file` for non-image files, or convert the image to a supported format.

### Corrupted State File

**Cause:** Rare -- process killed during write, disk full, etc.

**Fix:**
```bash
# Back up and reset
cp ~/.config/gowa/state.json ~/.config/gowa/state.json.bak
echo '{"messages_sent":[]}' > ~/.config/gowa/state.json
```

### Audit Log Too Large

The audit log rotates automatically at 1 MB. If you need to clear it manually:

```bash
# View recent entries
tail -20 ~/.config/gowa/audit.log

# Clear (reset)
> ~/.config/gowa/audit.log
```

---

## Send Operation Lifecycle

```mermaid
sequenceDiagram
    participant User/Agent
    participant CLI (cmd/send.go)
    participant Validation (safety/validate.go)
    participant Risk Gate (checkAcceptRisk)
    participant HTTP Client (client.go)
    participant Rate Limiter (safety/ratelimit.go)
    participant WhatsApp API
    participant Audit Log (safety/audit.go)

    User/Agent->>CLI (cmd/send.go): gowa send text --to PHONE "msg"
    CLI (cmd/send.go)->>Risk Gate (checkAcceptRisk): PersistentPreRunE
    alt risk not accepted
        Risk Gate (checkAcceptRisk)-->>User/Agent: Exit code 2
    end
    CLI (cmd/send.go)->>Validation (safety/validate.go): ValidatePhone(phone)
    alt invalid phone
        Validation (safety/validate.go)-->>User/Agent: Error: invalid phone
    end
    CLI (cmd/send.go)->>HTTP Client (client.go): Post("/send/message", body)
    HTTP Client (client.go)->>Rate Limiter (safety/ratelimit.go): CheckAndRecordSend()
    alt rate limit exceeded
        Rate Limiter (safety/ratelimit.go)-->>User/Agent: Exit code 6
    end
    Note over Rate Limiter (safety/ratelimit.go): Timestamp recorded BEFORE send
    HTTP Client (client.go)->>WhatsApp API: POST /send/message
    WhatsApp API-->>HTTP Client (client.go): Response
    HTTP Client (client.go)-->>CLI (cmd/send.go): SendResult or error
    CLI (cmd/send.go)->>Audit Log (safety/audit.go): LogSendOperation(entry)
    CLI (cmd/send.go)-->>User/Agent: Exit code 0 + result
```

---
---

# Portugues

## Indice

1. [Por que uma Camada de Seguranca?](#por-que-uma-camada-de-seguranca)
2. [Gate de Reconhecimento de Risco](#gate-de-reconhecimento-de-risco)
3. [Rate Limiter](#rate-limiter-1)
4. [Estado Persistente](#estado-persistente)
5. [Validacao de Entrada](#validacao-de-entrada)
6. [Log de Auditoria](#log-de-auditoria)
7. [Arquitetura de Erros](#arquitetura-de-erros)
8. [Seguranca do Cliente HTTP](#seguranca-do-cliente-http)
9. [Para Agentes de IA](#para-agentes-de-ia)
10. [Configuracao](#configuracao-1)
11. [Resolucao de Problemas](#resolucao-de-problemas)

---

## Por que uma Camada de Seguranca?

O GOWA CLI utiliza uma **API nao oficial do WhatsApp Web**. Isso cria tres categorias de risco:

| Risco | Consequencia | Mitigacao |
|-------|-------------|-----------|
| **Banimento da conta WhatsApp** | Perda permanente do numero no WhatsApp | Rate limiter, gate de risco |
| **Instabilidade da API nao oficial** | Mudancas sem aviso, sem SLA, sem suporte | Sem retry em send, trilha de auditoria |
| **Loops de automacao de agentes IA** | Milhares de mensagens em segundos | Rate limits, validacao de entrada, codigos de saida |

O WhatsApp detecta e bane ativamente contas com comportamento de bot: alto volume de mensagens, mensagens identicas repetidas ou envios em rajada. A camada de seguranca existe para tornar **estruturalmente impossivel** acionar esses padroes, mesmo quando o CLI e controlado por um agente de IA em loop de retry.

**Filosofia de design:** Todo mecanismo de seguranca tem como padrao **negar**. O sistema precisa ser explicitamente instruido a prosseguir em cada gate, e toda operacao de envio e contada *antes* de acontecer (fail-safe).

---

## Gate de Reconhecimento de Risco

Antes de qualquer subcomando `send` ser executado, o CLI exige reconhecimento explicito de que o usuario entende os riscos de usar uma API nao oficial.

### Fluxo

```
gowa send text --to 5511999999999 "Ola"
  --> ERRO (codigo de saida 2): Reconhecimento de risco obrigatorio

gowa send text --to 5511999999999 "Ola" --accept-risk
  --> WARNING impresso no stderr
  --> risk_accepted: true gravado em ~/.config/gowa/config.yaml
  --> Comando executa

gowa send text --to 5511999999999 "Ola"
  --> (execucoes seguintes) risco ja aceito, comando executa silenciosamente
```

### Como Funciona

1. `sendCmd.PersistentPreRunE` chama `checkAcceptRisk()` antes de todo subcomando send
2. Verifica `config.GetBool("risk_accepted")` -- se `true`, passa silenciosamente
3. Se a flag `--accept-risk` esta presente: persiste `risk_accepted: true` no config, imprime aviso no stderr, continua
4. Caso contrario: retorna `CLIError` com codigo de saida **2**

### Persistindo via Arquivo de Config

Em vez de passar `--accept-risk` a cada invocacao, adicione diretamente em `~/.config/gowa/config.yaml`:

```yaml
risk_accepted: true
```

---

## Rate Limiter

### Tres Principios de Design

1. **Contar antes de enviar (fail-safe):** O timestamp e registrado no estado *antes* da requisicao HTTP. Se a requisicao falhar ou o processo travar, a mensagem ainda e contada. Isso previne sub-contagem.
2. **Check-and-record atomico:** `CheckAndRecordSend()` adquire um unico file lock, verifica limites, registra o timestamp e salva -- tudo em uma unica secao critica. Isso elimina condicoes de corrida TOCTOU.
3. **Defaults conservadores:** Os limites sao intencionalmente baixos para ficar bem abaixo dos limiares de deteccao do WhatsApp.

### Limites Padrao

| Janela | Limite | Justificativa |
|--------|--------|---------------|
| Por minuto | **3** | Previne envios em rajada que parecem bot |
| Por hora | **30** | Fica abaixo dos limiares de deteccao horaria |
| Por dia (24h) | **200** | Limite diario conservador para seguranca da conta |

### Fluxo de Decisao do Rate Limiter

```
                    +-------------------+
                    | Envio solicitado  |
                    +--------+----------+
                             |
                    +--------v----------+
                    | Adquirir file lock |
                    | (state.json.lock) |
                    +--------+----------+
                             |
                    +--------v----------+
                    | Ler state.json    |
                    +--------+----------+
                             |
                    +--------v----------+
                    | Limpar entradas   |
                    | expiradas (>24h)  |
                    +--------+----------+
                             |
              +--------------v---------------+
              | Contar msgs em cada janela:  |
              | - ultimo 1 min  >= 3?  BLOQ  |
              | - ultima 1 hora >= 30? BLOQ  |
              | - ultimas 24h   >= 200? BLOQ |
              +---------+----------+---------+
                        |          |
                   PERMITIDO    BLOQUEADO
                        |          |
               +--------v---+  +--v----------------+
               | Adicionar  |  | Retornar erro     |
               | timestamp  |  | com tempo de       |
               +--------+---+  | espera (saida 6)  |
                        |      +-------------------+
               +--------v---------+
               | Salvar state.json |
               | (rename atomico) |
               +--------+---------+
                        |
               +--------v--------+
               | Liberar lock    |
               +--------+--------+
                        |
               +--------v--------+
               | HTTP POST /send |
               +-----------------+
```

### Calculo do Tempo de Espera

Quando um limite e excedido, a mensagem de erro inclui quantos segundos esperar:

```
waitSeconds = ceil(duracaoJanela - tempoDesdeEntradaMaisAntigaNaJanela)
```

Exemplo: `Rate limit exceeded: 3 messages sent in last minute. Wait 42 seconds before sending again.`

---

## Estado Persistente

O estado do rate limiter persiste entre invocacoes do CLI em um arquivo JSON.

### Localizacao do Arquivo

```
~/.config/gowa/state.json
```

### Formato do Arquivo

```json
{
  "messages_sent": [
    "2026-03-19T10:30:00Z",
    "2026-03-19T10:30:25Z",
    "2026-03-19T10:30:50Z"
  ]
}
```

### Mecanismos de Seguranca

| Mecanismo | Implementacao | Proposito |
|-----------|--------------|-----------|
| **Escrita atomica** | Escreve em `.tmp` e depois `os.Rename()` | Previne corrupcao em crash |
| **File locking** | `flock` (POSIX advisory lock) via `state.json.lock` | Acesso concorrente seguro |
| **Limpeza 24h** | `CleanExpiredEntries()` remove timestamps com mais de 24h | Mantem arquivo compacto |
| **Permissoes** | Arquivo criado com `0600`, diretorio com `0700` | Somente o dono le/escreve |
| **Preservacao de nao-parseavel** | Entradas que falham no parse RFC3339 sao mantidas | Previne perda silenciosa de dados |

---

## Validacao de Entrada

Todas as entradas do usuario sao validadas antes de qualquer chamada de rede.

### Numero de Telefone (`ValidatePhone`)

- **Regex:** `^\d{10,15}(@s\.whatsapp\.net)?$`
- Aceita formato E.164: `5511999999999` (10-15 digitos)
- Aceita JID do WhatsApp: `5511999999999@s.whatsapp.net`
- Rejeita: letras, simbolos, codigo de pais com `+`, numeros com menos de 10 digitos

### Caminho de Arquivo (`ValidateFilePath`)

- Usa `os.Stat()` para verificar se o arquivo existe
- Retorna erros especificos: "file not found" vs "cannot access" vs "path is a directory"

### Extensao de Arquivo (`ValidateFileExtension`)

- Comparacao case-insensitive
- Whitelist de imagem para `send image`: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`
- Sem restricao de extensao para `send file`

### Data RFC3339 (`ValidateRFC3339`)

- Usa `time.Parse(time.RFC3339, value)` para validacao estrita
- Formato valido: `2024-01-15T10:30:00Z`

---

## Log de Auditoria

Toda operacao de envio (sucesso ou falha) e registrada em uma trilha de auditoria persistente.

### Localizacao

```
~/.config/gowa/audit.log
```

### Formato: JSON Lines (JSONL)

Cada linha e um objeto JSON independente:

```jsonl
{"timestamp":"2026-03-19T10:30:00Z","operation":"send_text","recipient":"5511999999999","result":"success"}
{"timestamp":"2026-03-19T10:30:05Z","operation":"send_image","recipient":"5511888888888","result":"error","error_message":"Rate limit exceeded..."}
```

### Campos do AuditEntry

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `timestamp` | string | Timestamp UTC em RFC3339 |
| `operation` | string | `send_text`, `send_image` ou `send_file` |
| `recipient` | string | Numero de telefone ou JID |
| `result` | string | `success` ou `error` |
| `error_message` | string | Detalhes do erro (omitido em sucesso) |

### Rotacao

- **Limiar:** 1 MB
- **Estrategia:** Rotacao simples -- arquivo atual renomeado para `audit.log.1`
- **Retencao:** Arquivo atual + 1 arquivo rotacionado (max ~2 MB total)

---

## Arquitetura de Erros

### Struct CLIError

```go
type CLIError struct {
    Type     string  // Categoria: "usage_error", "auth_error", "rate_limit", etc.
    Code     int     // Codigo de saida do processo
    Message  string  // Mensagem de erro legivel
    Recovery string  // Dica acionavel para o usuario
    Original error   // Erro subjacente (opcional)
}
```

### Tabela de Codigos de Saida

| Codigo | Tipo | Significado | Exemplo |
|--------|------|-------------|---------|
| **0** | -- | Sucesso | Comando completado |
| **1** | `general` | Erro geral | Resposta do servidor nao parseavel |
| **2** | `usage_error` | Uso incorreto / risco nao aceito | Falta `--accept-risk`, bad request |
| **3** | `auth_error` | Falha de autenticacao | HTTP 401/403 |
| **4** | `not_found` | Recurso nao encontrado | HTTP 404 |
| **5** | `server_error` | Servidor inacessivel | Conexao recusada, HTTP 5xx |
| **6** | `rate_limit` | Rate limit excedido | Limiter local ou HTTP 429 |

### Saida de Erro em JSON

Quando a flag `--json` esta ativa, erros sao escritos no **stderr** como JSON estruturado em vez de texto simples:

```json
{"error":true,"type":"rate_limit","code":6,"message":"Rate limit exceeded: 3 messages sent in last minute...","recovery":"This limit protects your WhatsApp account from being banned"}
```

Campos: `error` (sempre `true`), `type`, `code` (codigo de saida), `message`, e opcionalmente `recovery`. Isso permite que agentes IA e scripts parseiem erros programaticamente sem depender de correspondencia de strings.

---

## Seguranca do Cliente HTTP

### Sem Retry em Send

Operacoes de envio (`POST /send/*`) **nao tem retry** para prevenir mensagens duplicadas no WhatsApp. Outras operacoes (GET, DELETE) fazem retry ate 3 vezes com backoff exponencial.

### Ponto de Integracao do Rate Limit

O check de rate limit acontece dentro de `Client.do()`, **antes** da requisicao HTTP. O timestamp e gravado atomicamente junto com o check.

---

## Modo Dry-Run

A flag `--dry-run` permite visualizar uma operacao de envio sem enviar a mensagem. Todas as validacoes (numero de telefone, caminho de arquivo, extensao, reconhecimento de risco) sao executadas, mas nenhuma requisicao HTTP e feita e nenhum token de rate limit e consumido.

### Uso

```bash
# Visualizar envio de texto
gowa send text --to 5511999999999 "Ola" --dry-run --json

# Visualizar envio em lote
gowa send text --to-file destinatarios.txt "Ola a todos" --dry-run --json

# Visualizar envio de imagem
gowa send image --to 5511999999999 --file foto.jpg --dry-run --json
```

### Saida do Dry-Run

```json
{"command":"send text","dry_run":true,"message":"Ola","to":"5511999999999","validations_passed":true,"would_send":true}
```

A saida inclui `dry_run: true` e `would_send: true` para confirmar que todas as validacoes passaram. Para operacoes em lote, uma entrada por destinatario e retornada.

### Por Que Isso Importa para Seguranca

- **Agentes IA** devem sempre fazer dry-run antes de enviar para verificar que os parametros estao corretos
- **Sem efeitos colaterais:** nenhuma mensagem enviada, nenhum rate limit consumido, nenhuma entrada no log de auditoria
- **Detecta erros cedo:** numeros invalidos, arquivos ausentes, extensoes nao suportadas sao capturados sem desperdicar um token de rate limit

---

## Para Agentes de IA

### Matriz de Protecao

| Modo de Falha do Agente | Mecanismo de Seguranca | Resultado |
|--------------------------|------------------------|-----------|
| **Loop infinito de retry** | Rate limiter (3/min, 30/hr, 200/dia) | Codigo de saida 6 |
| **Envio em massa** | Rate limiter + estado persistente | Bloqueia apos 3 envios rapidos |
| **Alucinacao de telefone** | Validacao regex E.164/JID | Rejeicao imediata |
| **Alucinacao de caminho de arquivo** | Verificacao `os.Stat()` | Erro "file not found" |
| **Falta de reconhecimento de risco** | Gate de risco (`--accept-risk`) | Codigo de saida 2 |
| **Envio concorrente multi-thread** | File locking (flock) | Contagem serializada e segura |
| **Ignorar erros e re-enviar** | Sem retry em POST /send | Tentativa unica |
| **Enviar sem verificacao** | Flag `--dry-run` | Visualizar antes de confirmar |

### Padrao Recomendado de Integracao com Agentes

```bash
# 1. Aceitar risco uma vez durante setup
gowa send text --to 5511999999999 "test" --accept-risk

# 2. Sempre fazer dry-run primeiro, depois enviar
gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json --dry-run
if [ $? -eq 0 ]; then
  gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json
fi

# 3. Verificar codigos de saida
EXIT_CODE=$?
case $EXIT_CODE in
  0) echo "Enviado com sucesso" ;;
  2) echo "Risco nao aceito ou entrada invalida" ;;
  6) echo "Rate limited -- NAO TENTE NOVAMENTE IMEDIATAMENTE" ;;
  *) echo "Erro: $EXIT_CODE" ;;
esac

# 4. Para envio em lote, use --to-file (delay integrado de 2s entre mensagens)
gowa send text --to-file destinatarios.txt "Ola a todos" --accept-risk --json
```

### O Que Agentes NAO Devem Fazer

1. **Nao faca retry no codigo de saida 6.** O rate limiter protege a conta do WhatsApp.
2. **Nao contorne o rate limiter** deletando ou modificando `state.json`.
3. **Nao execute multiplos processos de envio concorrentes.** O file locking lida com concorrencia, mas envios paralelos rapidos esgotam o limite por minuto rapidamente.
4. **Nao envie sem `--dry-run` primeiro.** Sempre visualize a operacao para detectar erros de validacao antes de consumir um token de rate limit.

---

## Configuracao

### Caminhos dos Arquivos

| Arquivo | Caminho | Proposito |
|---------|---------|-----------|
| Config | `~/.config/gowa/config.yaml` | Configuracoes, aceitacao de risco |
| Estado | `~/.config/gowa/state.json` | Timestamps do rate limiter |
| Auditoria | `~/.config/gowa/audit.log` | Log de operacoes de envio |

### Variaveis de Ambiente

Todos os valores de config podem ser sobrescritos com variaveis prefixadas com `GOWA_`:

| Variavel | Padrao | Descricao |
|----------|--------|-----------|
| `GOWA_API_URL` | `http://localhost:3000` | URL do servidor WhatsApp Web API |
| `GOWA_USERNAME` | (vazio) | Usuario de autenticacao basica |
| `GOWA_PASSWORD` | (vazio) | Senha de autenticacao basica |
| `GOWA_DEVICE_ID` | (vazio) | Identificador do dispositivo WhatsApp |
| `GOWA_OUTPUT` | `table` | Formato de saida (`table`, `json`) |
| `GOWA_RISK_ACCEPTED` | `false` | Pular aviso de risco para operacoes de envio (defina como `true` para CI/CD) |
| `GOWA_TIMEOUT` | `30s` | Timeout de requisicao HTTP (formato Go duration: `10s`, `1m`, `2m30s`) |

### Limites de Rate Padrao

Os rate limits estao codificados em `internal/safety/ratelimit.go` como `DefaultLimits`. Para ajustar, modifique o codigo-fonte e recompile. Isso e intencional -- rate limits nao devem ser facilmente alteraveis para manter as garantias de seguranca.

---

## Resolucao de Problemas

### "Risk acknowledgment required" (Codigo de Saida 2)

```bash
# Opcao A: Passar a flag uma vez
gowa send text --to 5511999999999 "Ola" --accept-risk

# Opcao B: Definir no arquivo de config
echo "risk_accepted: true" >> ~/.config/gowa/config.yaml
```

### "Rate limit exceeded" (Codigo de Saida 6)

Espere o tempo especificado na mensagem de erro. NAO delete `state.json`.

```bash
# Verificar estado atual
cat ~/.config/gowa/state.json
```

### "invalid phone number"

Use 10-15 digitos sem `+`, espacos ou hifens:
```bash
# Errado
gowa send text --to "+55 11 99999-9999" "Ola"

# Correto
gowa send text --to 5511999999999 "Ola"
```

### "file not found"

Verifique se o arquivo existe e use caminho absoluto ou relativo correto:
```bash
ls -la /caminho/para/arquivo.jpg
gowa send image --to 5511999999999 --file /caminho/para/arquivo.jpg
```

### "unsupported file extension"

O comando `send image` aceita apenas `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`. Use `send file` para outros formatos.

### Arquivo de Estado Corrompido

```bash
cp ~/.config/gowa/state.json ~/.config/gowa/state.json.bak
echo '{"messages_sent":[]}' > ~/.config/gowa/state.json
```

---
---

# Espanol

## Indice

1. [Por que una Capa de Seguridad?](#por-que-una-capa-de-seguridad)
2. [Gate de Reconocimiento de Riesgo](#gate-de-reconocimiento-de-riesgo)
3. [Rate Limiter](#rate-limiter-2)
4. [Estado Persistente](#estado-persistente-1)
5. [Validacion de Entrada](#validacion-de-entrada)
6. [Log de Auditoria](#log-de-auditoria-1)
7. [Arquitectura de Errores](#arquitectura-de-errores)
8. [Seguridad del Cliente HTTP](#seguridad-del-cliente-http)
9. [Para Agentes de IA](#para-agentes-de-ia-1)
10. [Configuracion](#configuracion)
11. [Solucion de Problemas](#solucion-de-problemas)

---

## Por que una Capa de Seguridad?

GOWA CLI utiliza una **API no oficial de WhatsApp Web**. Esto crea tres categorias de riesgo:

| Riesgo | Consecuencia | Mitigacion |
|--------|-------------|------------|
| **Baneo de cuenta WhatsApp** | Perdida permanente del numero en WhatsApp | Rate limiter, gate de riesgo |
| **Inestabilidad de API no oficial** | Cambios sin previo aviso, sin SLA, sin soporte | Sin retry en send, pista de auditoria |
| **Loops de automatizacion de agentes IA** | Miles de mensajes en segundos | Rate limits, validacion de entrada, codigos de salida |

WhatsApp detecta y banea activamente cuentas con comportamiento de bot: alto volumen de mensajes, mensajes identicos repetidos o envios en rafaga. La capa de seguridad existe para hacer **estructuralmente imposible** activar estos patrones, incluso cuando el CLI es controlado por un agente de IA en un loop de retry.

**Filosofia de diseno:** Cada mecanismo de seguridad tiene como valor predeterminado **denegar**. El sistema debe ser explicitamente instruido para proceder en cada gate, y cada operacion de envio se cuenta *antes* de que ocurra (fail-safe).

---

## Gate de Reconocimiento de Riesgo

Antes de que cualquier subcomando `send` se ejecute, el CLI requiere reconocimiento explicito de que el usuario entiende los riesgos de usar una API no oficial.

### Flujo

```
gowa send text --to 5511999999999 "Hola"
  --> ERROR (codigo de salida 2): Reconocimiento de riesgo requerido

gowa send text --to 5511999999999 "Hola" --accept-risk
  --> WARNING impreso en stderr
  --> risk_accepted: true guardado en ~/.config/gowa/config.yaml
  --> Comando se ejecuta

gowa send text --to 5511999999999 "Hola"
  --> (ejecuciones siguientes) riesgo ya aceptado, comando se ejecuta silenciosamente
```

### Como Funciona

1. `sendCmd.PersistentPreRunE` llama a `checkAcceptRisk()` antes de cada subcomando send
2. Verifica `config.GetBool("risk_accepted")` -- si es `true`, pasa silenciosamente
3. Si el flag `--accept-risk` esta presente: persiste `risk_accepted: true` en config, imprime advertencia en stderr, continua
4. De lo contrario: retorna `CLIError` con codigo de salida **2**

### Persistir via Archivo de Config

En lugar de pasar `--accept-risk` en cada invocacion, agregar directamente en `~/.config/gowa/config.yaml`:

```yaml
risk_accepted: true
```

---

## Rate Limiter

### Tres Principios de Diseno

1. **Contar antes de enviar (fail-safe):** El timestamp se registra en el estado *antes* de la solicitud HTTP. Si la solicitud falla o el proceso se cuelga, el mensaje aun se cuenta. Esto previene sub-conteo.
2. **Check-and-record atomico:** `CheckAndRecordSend()` adquiere un unico file lock, verifica limites, registra el timestamp y guarda -- todo en una unica seccion critica. Esto elimina condiciones de carrera TOCTOU.
3. **Defaults conservadores:** Los limites son intencionalmente bajos para mantenerse bien por debajo de los umbrales de deteccion de WhatsApp.

### Limites Predeterminados

| Ventana | Limite | Justificacion |
|---------|--------|---------------|
| Por minuto | **3** | Previene envios en rafaga que parecen bot |
| Por hora | **30** | Se mantiene bajo los umbrales de deteccion por hora |
| Por dia (24h) | **200** | Limite diario conservador para seguridad de la cuenta |

### Flujo de Decision del Rate Limiter

```
                    +--------------------+
                    | Envio solicitado   |
                    +--------+-----------+
                             |
                    +--------v-----------+
                    | Adquirir file lock  |
                    | (state.json.lock)  |
                    +--------+-----------+
                             |
                    +--------v-----------+
                    | Leer state.json    |
                    +--------+-----------+
                             |
                    +--------v-----------+
                    | Limpiar entradas   |
                    | expiradas (>24h)   |
                    +--------+-----------+
                             |
              +--------------v----------------+
              | Contar msgs en cada ventana:  |
              | - ultimo 1 min  >= 3?  BLOQ   |
              | - ultima 1 hora >= 30? BLOQ   |
              | - ultimas 24h   >= 200? BLOQ  |
              +---------+----------+----------+
                        |          |
                   PERMITIDO    BLOQUEADO
                        |          |
               +--------v---+  +--v-----------------+
               | Agregar    |  | Retornar error     |
               | timestamp  |  | con tiempo de       |
               +--------+---+  | espera (salida 6)  |
                        |      +--------------------+
               +--------v---------+
               | Guardar state.json|
               | (rename atomico) |
               +--------+---------+
                        |
               +--------v--------+
               | Liberar lock    |
               +--------+--------+
                        |
               +--------v--------+
               | HTTP POST /send |
               +-----------------+
```

### Calculo del Tiempo de Espera

Cuando un limite se excede, el mensaje de error incluye cuantos segundos esperar:

```
waitSeconds = ceil(duracionVentana - tiempoDesdeEntradaMasAntiguaEnVentana)
```

---

## Estado Persistente

El estado del rate limiter persiste entre invocaciones del CLI en un archivo JSON.

### Ubicacion del Archivo

```
~/.config/gowa/state.json
```

### Formato

```json
{
  "messages_sent": [
    "2026-03-19T10:30:00Z",
    "2026-03-19T10:30:25Z",
    "2026-03-19T10:30:50Z"
  ]
}
```

### Mecanismos de Seguridad

| Mecanismo | Implementacion | Proposito |
|-----------|---------------|-----------|
| **Escritura atomica** | Escribe en `.tmp` luego `os.Rename()` | Previene corrupcion en crash |
| **File locking** | `flock` (POSIX advisory lock) via `state.json.lock` | Acceso concurrente seguro |
| **Limpieza 24h** | `CleanExpiredEntries()` elimina timestamps mayores a 24h | Mantiene archivo compacto |
| **Permisos** | Archivo creado con `0600`, directorio con `0700` | Solo el dueno lee/escribe |
| **Preservacion de no-parseable** | Entradas que fallan en parse RFC3339 se mantienen | Previene perdida silenciosa de datos |

---

## Validacion de Entrada

Todas las entradas del usuario son validadas antes de cualquier llamada de red.

### Numero de Telefono (`ValidatePhone`)

- **Regex:** `^\d{10,15}(@s\.whatsapp\.net)?$`
- Acepta formato E.164: `5511999999999` (10-15 digitos)
- Acepta JID de WhatsApp: `5511999999999@s.whatsapp.net`
- Rechaza: letras, simbolos, codigo de pais con `+`, numeros con menos de 10 digitos

### Ruta de Archivo (`ValidateFilePath`)

- Usa `os.Stat()` para verificar que el archivo existe
- Retorna errores especificos: "file not found" vs "cannot access" vs "path is a directory"

### Extension de Archivo (`ValidateFileExtension`)

- Comparacion case-insensitive
- Whitelist de imagen para `send image`: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`
- Sin restriccion de extension para `send file`

### Fecha RFC3339 (`ValidateRFC3339`)

- Usa `time.Parse(time.RFC3339, value)` para validacion estricta
- Formato valido: `2024-01-15T10:30:00Z`

---

## Log de Auditoria

Cada operacion de envio (exito o fallo) se registra en una pista de auditoria persistente.

### Ubicacion

```
~/.config/gowa/audit.log
```

### Formato: JSON Lines (JSONL)

Cada linea es un objeto JSON independiente:

```jsonl
{"timestamp":"2026-03-19T10:30:00Z","operation":"send_text","recipient":"5511999999999","result":"success"}
{"timestamp":"2026-03-19T10:30:05Z","operation":"send_image","recipient":"5511888888888","result":"error","error_message":"Rate limit exceeded..."}
```

### Campos del AuditEntry

| Campo | Tipo | Descripcion |
|-------|------|-------------|
| `timestamp` | string | Timestamp UTC en RFC3339 |
| `operation` | string | `send_text`, `send_image` o `send_file` |
| `recipient` | string | Numero de telefono o JID |
| `result` | string | `success` o `error` |
| `error_message` | string | Detalles del error (omitido en exito) |

### Rotacion

- **Umbral:** 1 MB
- **Estrategia:** Rotacion simple -- archivo actual renombrado a `audit.log.1`
- **Retencion:** Archivo actual + 1 archivo rotado (max ~2 MB total)

---

## Arquitectura de Errores

### Struct CLIError

```go
type CLIError struct {
    Type     string  // Categoria: "usage_error", "auth_error", "rate_limit", etc.
    Code     int     // Codigo de salida del proceso
    Message  string  // Mensaje de error legible
    Recovery string  // Sugerencia accionable para el usuario
    Original error   // Error subyacente (opcional)
}
```

### Tabla de Codigos de Salida

| Codigo | Tipo | Significado | Ejemplo |
|--------|------|-------------|---------|
| **0** | -- | Exito | Comando completado |
| **1** | `general` | Error general | Respuesta del servidor no parseable |
| **2** | `usage_error` | Uso incorrecto / riesgo no aceptado | Falta `--accept-risk`, bad request |
| **3** | `auth_error` | Fallo de autenticacion | HTTP 401/403 |
| **4** | `not_found` | Recurso no encontrado | HTTP 404 |
| **5** | `server_error` | Servidor inaccesible | Conexion rechazada, HTTP 5xx |
| **6** | `rate_limit` | Rate limit excedido | Limiter local o HTTP 429 |

### Salida de Error en JSON

Cuando el flag `--json` esta activo, los errores se escriben en **stderr** como JSON estructurado en lugar de texto plano:

```json
{"error":true,"type":"rate_limit","code":6,"message":"Rate limit exceeded: 3 messages sent in last minute...","recovery":"This limit protects your WhatsApp account from being banned"}
```

Campos: `error` (siempre `true`), `type`, `code` (codigo de salida), `message`, y opcionalmente `recovery`. Esto permite que agentes IA y scripts parseen errores programaticamente sin depender de coincidencia de strings.

---

## Seguridad del Cliente HTTP

### Sin Retry en Send

Las operaciones de envio (`POST /send/*`) **no se reintentan** para prevenir mensajes duplicados en WhatsApp. Otras operaciones (GET, DELETE) reintentan hasta 3 veces con backoff exponencial.

### Punto de Integracion del Rate Limit

La verificacion de rate limit ocurre dentro de `Client.do()`, **antes** de la solicitud HTTP. El timestamp se graba atomicamente junto con la verificacion.

---

## Modo Dry-Run

El flag `--dry-run` permite previsualizar una operacion de envio sin enviar el mensaje. Todas las validaciones (numero de telefono, ruta de archivo, extension, reconocimiento de riesgo) se ejecutan, pero no se hace ninguna solicitud HTTP y no se consume ningun token de rate limit.

### Uso

```bash
# Previsualizar envio de texto
gowa send text --to 5511999999999 "Hola" --dry-run --json

# Previsualizar envio en lote
gowa send text --to-file destinatarios.txt "Hola a todos" --dry-run --json

# Previsualizar envio de imagen
gowa send image --to 5511999999999 --file foto.jpg --dry-run --json
```

### Salida del Dry-Run

```json
{"command":"send text","dry_run":true,"message":"Hola","to":"5511999999999","validations_passed":true,"would_send":true}
```

La salida incluye `dry_run: true` y `would_send: true` para confirmar que todas las validaciones pasaron. Para operaciones en lote, se retorna una entrada por destinatario.

### Por Que Esto Importa para la Seguridad

- **Los agentes IA** deben siempre hacer dry-run antes de enviar para verificar que los parametros son correctos
- **Sin efectos secundarios:** ningun mensaje enviado, ningun rate limit consumido, ninguna entrada en el log de auditoria
- **Detecta errores temprano:** numeros invalidos, archivos faltantes, extensiones no soportadas se capturan sin desperdiciar un token de rate limit

---

## Para Agentes de IA

### Matriz de Proteccion

| Modo de Fallo del Agente | Mecanismo de Seguridad | Resultado |
|--------------------------|------------------------|-----------|
| **Loop infinito de retry** | Rate limiter (3/min, 30/hr, 200/dia) | Codigo de salida 6 |
| **Envio masivo** | Rate limiter + estado persistente | Bloquea despues de 3 envios rapidos |
| **Alucinacion de telefono** | Validacion regex E.164/JID | Rechazo inmediato |
| **Alucinacion de ruta de archivo** | Verificacion `os.Stat()` | Error "file not found" |
| **Falta de reconocimiento de riesgo** | Gate de riesgo (`--accept-risk`) | Codigo de salida 2 |
| **Envio concurrente multi-hilo** | File locking (flock) | Conteo serializado y seguro |
| **Ignorar errores y re-enviar** | Sin retry en POST /send | Intento unico |
| **Enviar sin verificacion** | Flag `--dry-run` | Previsualizar antes de confirmar |

### Lo Que Los Agentes NO Deben Hacer

1. **No reintentar en codigo de salida 6.** El rate limiter protege la cuenta de WhatsApp.
2. **No eludir el rate limiter** eliminando o modificando `state.json`.
3. **No ejecutar multiples procesos de envio concurrentes.** El file locking maneja la concurrencia, pero envios paralelos rapidos agotan el limite por minuto rapidamente.
4. **No enviar sin `--dry-run` primero.** Siempre previsualice la operacion para detectar errores de validacion antes de consumir un token de rate limit.

### Patron de Integracion Recomendado

```bash
# 1. Aceptar riesgo una vez durante setup
gowa send text --to 5511999999999 "test" --accept-risk

# 2. Siempre hacer dry-run primero, luego enviar
gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json --dry-run
if [ $? -eq 0 ]; then
  gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json
fi

# 3. Verificar codigos de salida
EXIT_CODE=$?
case $EXIT_CODE in
  0) echo "Enviado exitosamente" ;;
  2) echo "Riesgo no aceptado o entrada invalida" ;;
  6) echo "Rate limited -- NO REINTENTAR INMEDIATAMENTE" ;;
  *) echo "Error: $EXIT_CODE" ;;
esac

# 4. Para envio en lote, use --to-file (delay integrado de 2s entre mensajes)
gowa send text --to-file destinatarios.txt "Hola a todos" --accept-risk --json
```

---

## Configuracion

### Rutas de Archivos

| Archivo | Ruta | Proposito |
|---------|------|-----------|
| Config | `~/.config/gowa/config.yaml` | Configuraciones, aceptacion de riesgo |
| Estado | `~/.config/gowa/state.json` | Timestamps del rate limiter |
| Auditoria | `~/.config/gowa/audit.log` | Log de operaciones de envio |

### Variables de Entorno

Todos los valores de config pueden ser sobreescritos con variables prefijadas con `GOWA_`:

| Variable | Predeterminado | Descripcion |
|----------|---------------|-------------|
| `GOWA_API_URL` | `http://localhost:3000` | URL del servidor WhatsApp Web API |
| `GOWA_USERNAME` | (vacio) | Usuario de autenticacion basica |
| `GOWA_PASSWORD` | (vacio) | Contrasena de autenticacion basica |
| `GOWA_DEVICE_ID` | (vacio) | Identificador del dispositivo WhatsApp |
| `GOWA_OUTPUT` | `table` | Formato de salida (`table`, `json`) |
| `GOWA_RISK_ACCEPTED` | `false` | Omitir advertencia de riesgo para operaciones de envio (defina como `true` para CI/CD) |
| `GOWA_TIMEOUT` | `30s` | Timeout de solicitud HTTP (formato Go duration: `10s`, `1m`, `2m30s`) |

### Limites de Rate Predeterminados

Los rate limits estan codificados en `internal/safety/ratelimit.go` como `DefaultLimits`. Para ajustar, modifique el codigo fuente y recompile. Esto es intencional -- los rate limits no deben ser facilmente modificables para mantener las garantias de seguridad.

---

## Solucion de Problemas

### "Risk acknowledgment required" (Codigo de Salida 2)

```bash
# Opcion A: Pasar el flag una vez
gowa send text --to 5511999999999 "Hola" --accept-risk

# Opcion B: Definir en archivo de config
echo "risk_accepted: true" >> ~/.config/gowa/config.yaml
```

### "Rate limit exceeded" (Codigo de Salida 6)

Espere el tiempo especificado en el mensaje de error. NO elimine `state.json`.

```bash
# Verificar estado actual
cat ~/.config/gowa/state.json
```

### "invalid phone number"

Use 10-15 digitos sin `+`, espacios o guiones:
```bash
# Incorrecto
gowa send text --to "+55 11 99999-9999" "Hola"

# Correcto
gowa send text --to 5511999999999 "Hola"
```

### "file not found"

Verifique que el archivo existe y use ruta absoluta o relativa correcta:
```bash
ls -la /ruta/al/archivo.jpg
gowa send image --to 5511999999999 --file /ruta/al/archivo.jpg
```

### "unsupported file extension"

El comando `send image` solo acepta `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`. Use `send file` para otros formatos.

### Archivo de Estado Corrompido

```bash
cp ~/.config/gowa/state.json ~/.config/gowa/state.json.bak
echo '{"messages_sent":[]}' > ~/.config/gowa/state.json
```
