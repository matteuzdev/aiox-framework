# GOWA CLI -- Architecture Map & Knowledge Graph

**Version:** 0.6.0
**Module:** `github.com/murilloimparavel/gowa-cli`
**Go:** 1.25.0
**Generated:** 2026-03-22

---

## 1. System Overview

GOWA CLI (`gowa`) is a Go command-line tool that provides scriptable, agent-friendly access to WhatsApp via an embedded whatsmeow connection. It runs a background daemon that maintains a persistent WhatsApp WebSocket, exposes a JSON-RPC interface over a Unix socket, and stores messages/chats/contacts in a local SQLite database. The CLI communicates with the daemon via this socket for all operations that require WhatsApp connectivity (sending messages, listing chats, searching contacts). A comprehensive safety layer protects users from WhatsApp account bans through rate limiting, circuit breaking, input validation, and audit logging. All output supports three modes (table, JSON, quiet) making it equally useful for humans and AI agents.

---

## 2. Architecture Diagram

```
+----------------------------------------------------------------------+
|                           CLI PROCESS                                 |
|  main.go --> cmd/root.go (cobra + RunContext)                        |
|                                                                       |
|  +------------------+  +-----------+  +---------------------------+  |
|  | cmd/pair.go      |  | cmd/      |  | cmd/send.go              |  |
|  | cmd/logout.go    |  | daemon.go |  | cmd/chat.go              |  |
|  | cmd/version.go   |  |           |  | cmd/contact.go           |  |
|  | cmd/completion.go|  |           |  | cmd/device.go            |  |
|  |                  |  |           |  | cmd/group.go             |  |
|  +--------+---------+  +-----+-----+  +------------+-------------+  |
|           |                   |                      |                |
|    [Direct WA access]  [Daemon mgmt]          [Via DaemonClient]     |
|           |                   |                      |                |
|           v                   v                      v                |
|  +----------------+  +--------------+  +-------------------------+   |
|  | whatsapp/      |  | daemon/      |  | service/messenger.go    |   |
|  | client.go      |  | Start()      |  | DaemonMessenger         |   |
|  | (pair/logout)  |  | Stop()       |  | (SendText/Image/File)   |   |
|  +----------------+  +--------------+  +------------+------------+   |
|                                                      |                |
|  +-------------------+  +--------------+             |                |
|  | safety/validate   |  | output/      |             |                |
|  | (input checks)    |  | table/json/  |             |                |
|  +-------------------+  | quiet        |             |                |
|                          +--------------+             |                |
+----------------------------------------------------------------------+
                                                        |
               Unix Socket (gowa.sock)                  |
               Token Auth (daemon.token)                |
                                                        v
+----------------------------------------------------------------------+
|                         DAEMON PROCESS                                |
|  daemon.go --> RunForeground()                                       |
|                                                                       |
|  +-------------------------+   +----------------------------------+  |
|  | server.go               |   | daemon.go (event handlers)       |  |
|  | JSON-RPC over Unix sock |   | registerEventHandlers()          |  |
|  | Token authentication    |   |   OnMessage -> save to msgstore  |  |
|  | Idle timeout (disabled) |   |   OnHistorySync -> bulk import   |  |
|  +------------+------------+   |   Connected/Disconnected/Banned  |  |
|               |                |   LoggedOut -> shutdown           |  |
|               v                +----------------------------------+  |
|  +-------------------------+                                         |
|  | registerHandlers()      |   +----------------------------------+  |
|  | 22 RPC methods          |   | whatsapp/client.go               |  |
|  | daemon.*, chat.*,       |   | WaClient (whatsmeow wrapper)     |  |
|  | contact.*, send.*,      |   | Connect, SendText/Image/File     |  |
|  | device.*, safety.*,     |   | GroupManager interface            |  |
|  | group.*                 |   | Typing indicator (anti-ban)      |  |
|  |                         |   +----------------------------------+  |
|  +-------------------------+                                         |
|               |                +----------------------------------+  |
|               v                | safety/circuitbreaker.go         |  |
|  +-------------------------+  | 5 failures/30min -> 30min block   |  |
|  | msgstore/               |  | Controls auto-reconnect hook      |  |
|  | SQLite (messages.db)    |  +----------------------------------+  |
|  | WAL mode, FTS5 search   |                                        |
|  | chats, messages,        |  +----------------------------------+  |
|  | contacts tables         |  | safety/ratelimit.go              |  |
|  +-------------------------+  | 3/min, 30/hr, 200/day            |  |
|                                | Atomic check+record (flock)      |  |
|                                +----------------------------------+  |
+----------------------------------------------------------------------+
                    |
                    v
          +------------------+
          |  WhatsApp Servers |
          |  (WebSocket via   |
          |   whatsmeow)      |
          +------------------+
```

---

## 3. Package Map

| Package | Purpose | Key Types | Key Functions |
|---------|---------|-----------|---------------|
| `cmd` | Cobra command definitions, CLI entry point | `RunContext` | `Execute()`, `checkAcceptRisk()` |
| `internal/clierr` | Structured error type for CLI | `CLIError` (Type, Code, Message, Recovery) | `Error()`, `ExitCode()` |
| `internal/config` | Viper-based YAML config management | `Config` | `New()`, `Save()`, `DeviceID()`, `OutputFormat()` |
| `internal/daemon` | Background daemon lifecycle and RPC | `Daemon`, `Server`, `Client`, `Paths` | `Start()`, `Stop()`, `RunForeground()`, `Register()`, `Serve()`, `Shutdown()`, `Call()` |
| `internal/whatsapp` | whatsmeow wrapper with clean Go API | `WaClient`, `Messenger` (interface), `GroupManager` (interface), `GroupSummary`, `GroupDetail`, `GroupMember` | `NewWaClient()`, `Connect()`, `SendText()`, `SendImage()`, `SendFile()`, `Close()`, `GetJoinedGroups()`, `GetGroupInfo()`, `CreateGroup()`, `LeaveGroup()`, `GetGroupInviteLink()`, `JoinGroupWithLink()` |
| `internal/msgstore` | SQLite message/chat/contact storage | `MsgStore`, `Message`, `Chat`, `Contact`, `MessageFilter` | `SaveMessage()`, `GetMessages()`, `SearchMessages()`, `UpsertChat()`, `GetChats()`, `UpsertContact()` |
| `internal/safety` | Rate limiting, circuit breaker, audit, validation | `CircuitBreaker`, `RateStatus`, `AuditEntry`, `State` | `CheckAndRecordSend()`, `GetRateStatus()`, `NewCircuitBreaker()`, `Allow()`, `ValidatePhone()` |
| `internal/service` | Business logic layer (Messenger abstraction) | `DaemonMessenger` | `SendText()`, `SendImage()`, `SendFile()` |
| `internal/output` | Output formatting (table/JSON/quiet) | `Formatter` (interface) | `New()`, `AutoDetect()`, `FilterFields()`, `Format()`, `FormatSingle()` |

---

## 4. Data Flow Diagrams

### 4.1 Send Message Flow

```
User: gowa send text --to 5511999999999 "Hello" --accept-risk

  cmd/send.go
    +-- checkAcceptRisk()              # verify risk acknowledgment
    +-- safety.ValidatePhone()         # input validation
    |
    v
  service/DaemonMessenger.SendText()
    +-- daemon.Client.Call("send.text", {to, message})
    +-- logAudit()                     # safety.LogSendOperationTo()
    |
    v  [Unix socket RPC]
  DAEMON: "send.text" handler
    +-- safety.CheckAndRecordSend()    # atomic rate limit (flock)
    +-- wa.SendChatPresence(composing) # typing indicator (anti-ban)
    +-- time.Sleep(1500ms)
    +-- wa.SendText()                  # whatsmeow.SendMessage()
    |
    v
  Response: {message_id, timestamp, status: "sent"}
```

### 4.2 Receive Message Flow

```
WhatsApp Server --> WebSocket push --> whatsmeow event

  *events.Message
    |  (safeGo goroutine)
    v
  daemon.go handler
    +-- detectMsgType()      # text/image/video/audio/document/sticker/...
    +-- extractMsgText()     # conversation, caption, filename
    +-- extractReplyTo()     # stanza ID from ContextInfo
    |
    +-- store.SaveMessage()       # INSERT OR REPLACE
    +-- store.UpsertChat()        # update last_msg, preview
    +-- store.IncrementUnread()   # if !from_me
    +-- store.UpsertContact()     # push_name
    |
    v
  SQLite messages.db (WAL mode, FTS5)
```

### 4.3 Daemon Lifecycle

```
gowa daemon start
    |
    v
  daemon.Start() --> spawn child process (Setsid: true)
    |
    v  [CHILD PROCESS]
  daemon.RunForeground()
    +-- AcquireLock + WritePID
    +-- Setup lumberjack log rotation (5MB, 3 backups)
    +-- NewWaClient(session.db)
    +-- NewMsgStore(messages.db)
    +-- NewServer(gowa.sock) + token auth
    +-- NewCircuitBreaker(5 failures, 30min, 30min)
    +-- AutoReconnectHook -> cb.Allow()
    +-- Register 22 RPC handlers
    +-- Register event handlers (Message, HistorySync, Connected, etc.)
    +-- wa.Connect()
    |
    v
  select { SIGTERM | SIGINT | serverDone | ctx.Done }
    |
    v  [SHUTDOWN - 10s hard deadline]
    1. server.Shutdown()   # drain RPCs (5s)
    2. wa.Close()          # disconnect + flush session SQLite
    3. store.Close()       # close messages.db
    4. cleanup files       # socket, token
```

---

## 5. Storage Map

| File | Path | Format | Purpose |
|------|------|--------|---------|
| `config.yaml` | `~/.config/gowa/` | YAML | User preferences (device_id, output, risk_accepted) |
| `session.db` | `~/.config/gowa/` | SQLite | WhatsApp session keys (whatsmeow sqlstore) |
| `messages.db` | `~/.config/gowa/` | SQLite WAL | Messages, chats, contacts + FTS5 search |
| `state.json` | `~/.config/gowa/` | JSON | Rate limiter timestamps (RFC3339 array) |
| `audit.log` | `~/.config/gowa/` | JSONL | Send operation audit trail (1MB rotation) |
| `daemon.pid` | `~/.config/gowa/` | Text | Running daemon PID |
| `daemon.lock` | `~/.config/gowa/` | flock | Single-instance lock |
| `daemon.log` | `~/.config/gowa/` | JSON lines | Daemon structured logs (lumberjack: 5MB, 3 backups) |
| `daemon.token` | `~/.config/gowa/` | Text (64 hex) | RPC authentication token |
| `gowa.sock` | `~/.config/gowa/` | Unix socket | JSON-RPC 2.0 IPC channel |

All files are chmod 0600.

---

## 6. RPC Method Registry

| Method | Params | Response |
|--------|--------|----------|
| `daemon.ping` | -- | `{status: "ok"}` |
| `daemon.status` | -- | `{running, pid, uptime, whatsapp_connected, connection_status, cb_state, cb_failures, ...}` |
| `daemon.shutdown` | -- | `{status: "shutting_down"}` |
| `chat.list` | `{limit}` | `[Chat, ...]` |
| `chat.messages` | `{jid, limit, before, since, until, search}` | `[Message, ...]` |
| `chat.unread` | -- | `[Chat, ...]` |
| `chat.read` | `{jid}` | `{status: "ok"}` |
| `chat.search` | `{query, limit}` | `[Message, ...]` |
| `contact.list` | `{limit}` | `[Contact, ...]` |
| `contact.search` | `{query, limit}` | `[Contact, ...]` |
| `send.text` | `{to, message, reply_to}` | `{message_id, timestamp, status}` |
| `send.image` | `{to, file, caption}` | `{message_id, timestamp, status}` |
| `send.file` | `{to, file}` | `{message_id, timestamp, status}` |
| `safety.rate-status` | -- | `{minute_remaining, hour_remaining, day_remaining, ...}` |
| `device.status` | -- | `{connected, logged_in, needs_pairing}` |
| `group.list` | -- | `[GroupSummary, ...]` |
| `group.info` | `{jid}` | `GroupDetail` (with participants) |
| `group.create` | `{name, participants}` | `GroupDetail` |
| `group.leave` | `{jid}` | `{status: "left"}` |
| `group.inviteLink` | `{jid, reset}` | `{link}` |
| `group.join` | `{code}` | `{jid, name}` |

---

## 7. Event Handler Registry

| whatsmeow Event | Action |
|-----------------|--------|
| `*events.Message` | Save to msgstore, upsert chat/contact, increment unread |
| `*events.HistorySync` | Bulk import conversations, messages, push_names |
| `*events.Disconnected` | Status "reconnecting", CB RecordFailure() |
| `*events.Connected` | Status "connected", CB RecordSuccess() |
| `*events.LoggedOut` | Status "logged_out", trigger shutdown |
| `*events.StreamReplaced` | Status "logged_out", trigger shutdown |
| `*events.TemporaryBan` | Status "banned", log code + expiry |
| `*events.ClientOutdated` | Status "logged_out", trigger shutdown |
| `*events.ConnectFailure` | Branch: permanent → shutdown, transient → "reconnecting" |
| `*events.KeepAliveTimeout` | Status "keepalive_failing" |
| `*events.KeepAliveRestored` | Status "connected" |

---

## 8. Safety Layer Map

| Mechanism | What It Protects | How |
|-----------|-----------------|-----|
| **Rate Limiter** | Account from spam-flagging | 3/min, 30/hr, 200/day. Atomic check+record (flock). Fail-safe: record BEFORE send |
| **Circuit Breaker** | Against reconnect loops | 5 failures/30min → 30min cooldown. Controls AutoReconnectHook |
| **Input Validation** | Against malformed input | Phone (E.164), file path, extension whitelist, RFC3339 dates |
| **Audit Log** | Accountability | JSONL with flock. 1MB rotation. Every send logged |
| **Risk Gate** | Against accidental sends | `--accept-risk` / config / env var required for send |
| **Typing Indicator** | Anti-ban | Composing presence + 1.5s delay before text sends |
| **Batch Delay** | Anti-ban for bulk sends | Random 1-5s between recipients |
| **Token Auth** | Socket security | 32-byte random hex, 0600 permissions |
| **Panic Recovery** | Daemon stability | safeGo/recoverPanic on all goroutines |
| **Graceful Shutdown** | Data integrity | Ordered: stop RPCs → drain handlers → close WA → close store |

---

## 9. Exit Code Reference

| Code | Meaning | Trigger |
|------|---------|---------|
| 0 | Success | Any successful command |
| 1 | General error | Daemon not running, config error, parse error |
| 2 | Usage error | Invalid phone, conflicting flags, bad input |
| 3 | Not found | Group does not exist or was deleted |
| 4 | Permission error | Not admin for admin-only group operations |
| 5 | Connection/WhatsApp error | Not connected, message timeout, RPC failure |
| 6 | Rate limited | Exceeded 3/min, 30/hr, or 200/day |
| 7 | Session expired | No session, need re-pair |

---

## 10. Internal Dependency Graph

```
  cmd
   |
   +-------+--------+--------+--------+
   |       |        |        |        |
   v       v        v        v        v
 config  daemon   service  output  safety
           |        |
           +--+-----+
              |
              v
           whatsapp
              |
              v
           msgstore
              |
              v
           clierr (leaf)
```

---

## 11. Key Design Decisions

1. **Daemon + Unix Socket RPC** — WhatsApp connections take 2-5s to establish. Daemon keeps it alive, making CLI commands instant (~50ms).

2. **Fail-Safe Rate Limiting** — Timestamp recorded BEFORE send. If crash occurs, worst case is a phantom count (safe) vs missed count (unsafe).

3. **Atomic Check-and-Record** — Single flock for rate limit check + record eliminates TOCTOU race between concurrent processes.

4. **Three Output Modes** — Table (human), JSON (agents), Quiet (scripts). Every command uses Formatter interface. Errors are structured JSON on stderr.

5. **Circuit Breaker on Reconnect** — Prevents aggressive reconnection that could trigger WhatsApp anti-abuse. Wired into whatsmeow's AutoReconnectHook. State visible in `daemon status`.
