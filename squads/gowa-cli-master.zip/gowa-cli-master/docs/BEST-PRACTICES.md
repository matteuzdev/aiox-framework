# GOWA CLI — Best Practices & Automation Guide

**Navigation / Navegacao / Navegacion:**
[English](#english) | [Portugues](#portugues) | [Espanol](#espanol)

---

# English

## Table of Contents

1. [General Principles](#1-general-principles)
2. [For Shell Scripts](#2-for-shell-scripts)
3. [For AI Agents](#3-for-ai-agents-claude-code-codex-gemini-cursor-etc)
4. [For CI/CD Pipelines](#4-for-cicd-pipelines)
5. [WhatsApp-Specific Safety](#5-whatsapp-specific-safety)
6. [Automation Patterns](#6-automation-patterns)
7. [Anti-Patterns](#7-anti-patterns-what-not-to-do)
8. [Troubleshooting Guide](#8-troubleshooting-guide)

---

## 1. General Principles

### Safety First

GOWA CLI is built with a **safety-first** philosophy. Every send operation goes through:

1. **Risk acknowledgment** — `--accept-risk` flag or persisted config
2. **Phone validation** — E.164 format (10-15 digits) or WhatsApp JID
3. **File validation** — existence check + extension whitelist for images
4. **Rate limiting** — local state file with per-minute/hour/day windows
5. **Audit logging** — every send operation is recorded to `~/.config/gowa/audit.log`

### Structured Output

GOWA CLI supports three output modes:

| Flag | Mode | Use Case |
|------|------|----------|
| *(none)* | Table | Human-readable terminal output |
| `--json` | JSON | Machine-parseable, full data |
| `--quiet` | Bare value | Single-value extraction (message_id, status) |

**Rule:** Always use `--json` for automation. Never parse table output.

### Exit Codes

| Code | Meaning | Recovery |
|------|---------|----------|
| `0` | Success | -- |
| `1` | General error | Check stderr message |
| `2` | Usage/input error | Fix flags or arguments |
| `3` | Authentication error | Run `gowa auth login` |
| `4` | Resource not found | Verify resource ID |
| `5` | Server/connection error | Check GOWA server status |
| `6` | Rate limit exceeded | Wait and retry with backoff |

### Idempotent Operations

Read operations (`device list`, `chat list`, `chat messages`, `auth status`) are safe to repeat. Send operations are **not** idempotent — each call sends a new message and is recorded in the rate limiter state.

### Rate Limits (Built-in)

| Window | Limit |
|--------|-------|
| Per minute | 3 messages |
| Per hour | 30 messages |
| Per day | 200 messages |

These limits are **intentionally conservative** to protect your WhatsApp account from being flagged or banned.

---

## 2. For Shell Scripts

### Always Use --json for Parseable Output

```bash
# GOOD: Parse JSON with jq
DEVICE_ID=$(gowa device list --json | jq -r '.[0].id')

# BAD: Parse table output (fragile, breaks on format changes)
DEVICE_ID=$(gowa device list | awk 'NR==2 {print $1}')
```

### Check Exit Codes

```bash
gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json
EXIT_CODE=$?

case $EXIT_CODE in
  0) echo "Message sent successfully" ;;
  2) echo "Invalid input: check phone number or message" ;;
  3) echo "Auth failed: re-login required" ;;
  5) echo "Server unreachable: check GOWA server" ;;
  6) echo "Rate limited: backing off..." ; sleep 60 ;;
  *) echo "Unexpected error (exit $EXIT_CODE)" ;;
esac
```

### Handle Rate Limits with Exponential Backoff

```bash
#!/usr/bin/env bash
set -euo pipefail

send_with_backoff() {
  local to="$1"
  local message="$2"
  local max_retries=5
  local attempt=0
  local wait=10

  while [ $attempt -lt $max_retries ]; do
    RESULT=$(gowa send text --to "$to" "$message" --accept-risk --json 2>&1)
    EXIT_CODE=$?

    if [ $EXIT_CODE -eq 0 ]; then
      echo "$RESULT"
      return 0
    elif [ $EXIT_CODE -eq 6 ]; then
      echo "Rate limited. Waiting ${wait}s (attempt $((attempt+1))/$max_retries)..." >&2
      sleep $wait
      wait=$((wait * 2))  # exponential backoff: 10, 20, 40, 80, 160
      attempt=$((attempt + 1))
    else
      echo "Fatal error (exit $EXIT_CODE): $RESULT" >&2
      return $EXIT_CODE
    fi
  done

  echo "Max retries exhausted" >&2
  return 6
}

send_with_backoff "5511999999999" "Hello from script"
```

### Use --quiet for Simple Value Extraction

```bash
# Get just the message ID after sending
MSG_ID=$(gowa send text --to "$PHONE" "Hello" --accept-risk --quiet)
echo "Sent message: $MSG_ID"

# Check auth status (returns "true" or "false")
IS_AUTH=$(gowa auth status --quiet)
if [ "$IS_AUTH" = "true" ]; then
  echo "Authenticated"
fi
```

### Pipe stdin for Dynamic Messages

```bash
# Pipe from another command
echo "Deploy completed at $(date)" | gowa send text --to "$PHONE" --accept-risk

# Pipe from a file
cat /var/log/report.txt | gowa send text --to "$PHONE" --accept-risk

# Heredoc for multi-line messages
gowa send text --to "$PHONE" --accept-risk <<EOF
Build Report
Status: SUCCESS
Branch: main
Commit: $(git rev-parse --short HEAD)
EOF
```

### Example: Batch Sender with Rate Limit Awareness

```bash
#!/usr/bin/env bash
# batch-send.sh — Send message to a list of recipients with rate awareness
set -euo pipefail

MESSAGE="$1"
RECIPIENTS_FILE="$2"
DELAY=25  # 25 seconds between messages (safe for 3/min limit)

if [ ! -f "$RECIPIENTS_FILE" ]; then
  echo "File not found: $RECIPIENTS_FILE" >&2
  exit 1
fi

SENT=0
FAILED=0

while IFS= read -r phone; do
  # Skip empty lines and comments
  [[ -z "$phone" || "$phone" =~ ^# ]] && continue

  RESULT=$(gowa send text --to "$phone" "$MESSAGE" --accept-risk --json 2>&1)
  EXIT_CODE=$?

  if [ $EXIT_CODE -eq 0 ]; then
    MSG_ID=$(echo "$RESULT" | jq -r '.message_id // "unknown"')
    echo "[OK] $phone -> $MSG_ID"
    SENT=$((SENT + 1))
  elif [ $EXIT_CODE -eq 6 ]; then
    echo "[RATE] $phone -> waiting 120s..." >&2
    sleep 120
    # Retry once after waiting
    gowa send text --to "$phone" "$MESSAGE" --accept-risk --json >/dev/null 2>&1 && SENT=$((SENT + 1)) || FAILED=$((FAILED + 1))
  else
    echo "[FAIL] $phone -> exit $EXIT_CODE" >&2
    FAILED=$((FAILED + 1))
  fi

  sleep "$DELAY"
done < "$RECIPIENTS_FILE"

echo "Done: $SENT sent, $FAILED failed"
```

### Batch Send with --to-file (Built-in Rate Safety)

Instead of managing delays yourself, use `--to-file` for batch sends. The CLI applies a built-in 2-second delay between recipients and stops the batch on rate limit errors:

```bash
# recipients.txt — one phone number per line (# comments and blank lines are skipped)
# 5511999999999
# 5511888888888

# Dry-run first to validate all recipients
gowa send text --to-file recipients.txt "Hello everyone" --accept-risk --json --dry-run

# Send for real
gowa send text --to-file recipients.txt "Hello everyone" --accept-risk --json

# Send image to multiple recipients
gowa send image --to-file recipients.txt --file report.png --caption "Monthly report" --accept-risk --json
```

### Example: Monitoring Script with Chat Messages

```bash
#!/usr/bin/env bash
# monitor-and-alert.sh — Check a service and alert via WhatsApp
set -euo pipefail

ALERT_PHONE="5511999999999"
SERVICE_URL="https://myapp.example.com/health"
STATE_FILE="/tmp/gowa-monitor-state"

check_service() {
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$SERVICE_URL" 2>/dev/null || echo "000")
  echo "$HTTP_CODE"
}

STATUS=$(check_service)
PREV_STATUS=$(cat "$STATE_FILE" 2>/dev/null || echo "200")

if [ "$STATUS" != "200" ] && [ "$PREV_STATUS" = "200" ]; then
  # Service just went down — send alert
  gowa send text --to "$ALERT_PHONE" \
    "ALERT: Service DOWN. Status: $STATUS. URL: $SERVICE_URL. Time: $(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --accept-risk --quiet >/dev/null
elif [ "$STATUS" = "200" ] && [ "$PREV_STATUS" != "200" ]; then
  # Service recovered
  gowa send text --to "$ALERT_PHONE" \
    "RECOVERED: Service UP. URL: $SERVICE_URL. Time: $(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --accept-risk --quiet >/dev/null
fi

echo "$STATUS" > "$STATE_FILE"
```

---

## 3. For AI Agents (Claude Code, Codex, Gemini, Cursor, etc.)

AI agents that have shell access can use GOWA CLI as a tool for WhatsApp communication. Follow these patterns for reliable integration.

### Always Dry-Run Before Sending

The `--dry-run` flag validates all inputs (phone, file, extension) and previews the operation without sending. This is the recommended pattern for AI agents:

```bash
# Step 1: Dry-run to validate
gowa send text --to "$PHONE" "$MSG" --accept-risk --json --dry-run
if [ $? -ne 0 ]; then
  echo "Validation failed — do not send"
  exit 1
fi

# Step 2: Send for real (only after dry-run succeeds)
gowa send text --to "$PHONE" "$MSG" --accept-risk --json
```

This prevents wasting rate limit tokens on invalid inputs and catches hallucinated phone numbers or file paths before they reach the API.

### Use --json Flag, Parse with jq

```bash
# Agent reads chat list for context
CHATS=$(gowa chat list --json --limit 10)
echo "$CHATS" | jq -r '.[] | "\(.name): \(.last_message)"'

# Agent reads message history
MESSAGES=$(gowa chat messages 5511999999999 --json --limit 20 --since "2026-01-01T00:00:00Z")
echo "$MESSAGES" | jq -r '.[] | "[\(.from)] \(.text)"'
```

### Handle Exit Codes Programmatically

With `--json`, errors are written to stderr as structured JSON (fields: `error`, `type`, `code`, `message`, `recovery`):

```bash
# Agent checks if it can send before attempting
gowa auth status --json > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "GOWA not authenticated. Cannot send messages."
  exit 1
fi

# Agent sends with error handling (--json errors go to stderr)
OUTPUT=$(gowa send text --to "$PHONE" "$MSG" --accept-risk --json 2>/tmp/gowa-err.json)
if [ $? -eq 0 ]; then
  echo "Message sent: $(echo "$OUTPUT" | jq -r '.message_id')"
else
  echo "Send failed: $(jq -r '.message' /tmp/gowa-err.json)"
fi
```

### Never Loop Send Without Sleep

The rate limiter allows 3 messages per minute. An agent looping without delay will hit the limit on the 4th message and get exit code 6.

```bash
# BAD: Agent sends in tight loop
for phone in "${PHONES[@]}"; do
  gowa send text --to "$phone" "Update" --accept-risk  # Will hit rate limit on 4th call
done

# GOOD: Agent respects rate limits
for phone in "${PHONES[@]}"; do
  gowa send text --to "$phone" "Update" --accept-risk --json
  sleep 25  # Safe: stays under 3/min
done
```

### Use --quiet for Simple Extractions

```bash
# Agent captures just the message ID
MSG_ID=$(gowa send text --to "$PHONE" "Task done" --accept-risk --quiet)

# Agent checks connection status
gowa auth status --quiet  # Prints "true" or "false"
```

### Pipe Dynamic Content via stdin

```bash
# Agent sends task completion report
echo "Task #1234 completed successfully. Files changed: 3. Tests passed: 47/47." | \
  gowa send text --to "$PHONE" --accept-risk --json
```

### Example: Agent Sending Notification After Task Completion

```bash
#!/usr/bin/env bash
# Agent notifies team member after completing a development task

NOTIFY_PHONE="5511999999999"
TASK_SUMMARY="$1"

# Build notification message
MESSAGE="Task Complete
$TASK_SUMMARY
Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

# Send with full error handling
RESULT=$(gowa send text --to "$NOTIFY_PHONE" "$MESSAGE" --accept-risk --json 2>&1)
EXIT=$?

case $EXIT in
  0)
    MSG_ID=$(echo "$RESULT" | jq -r '.message_id // "sent"')
    echo "Notification sent: $MSG_ID"
    ;;
  3)
    echo "AUTH_ERROR: Agent cannot send — GOWA not configured"
    ;;
  5)
    echo "SERVER_ERROR: GOWA server unreachable"
    ;;
  6)
    echo "RATE_LIMITED: Too many messages sent recently. Try again later."
    ;;
  *)
    echo "ERROR ($EXIT): $RESULT"
    ;;
esac
```

### Example: Agent Reading Chat History for Context

```bash
#!/usr/bin/env bash
# Agent reads recent conversation to understand context before responding

JID="$1"
SINCE=$(date -u -d "2 hours ago" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || \
        date -u -v-2H +%Y-%m-%dT%H:%M:%SZ)  # Linux / macOS

MESSAGES=$(gowa chat messages "$JID" --json --limit 30 --since "$SINCE" 2>&1)
if [ $? -ne 0 ]; then
  echo "Failed to fetch messages: $MESSAGES" >&2
  exit 1
fi

# Extract conversation as text for agent context
echo "$MESSAGES" | jq -r '.[] | "[\(.from // "unknown")] \(.text // "(media)")"'
```

### Python: subprocess Integration

```python
import subprocess
import json
import time

def gowa_send(phone: str, message: str, max_retries: int = 3) -> dict:
    """Send a WhatsApp message via GOWA CLI with retry logic."""
    wait = 10
    for attempt in range(max_retries):
        result = subprocess.run(
            ["gowa", "send", "text", "--to", phone, message, "--accept-risk", "--json"],
            capture_output=True, text=True
        )

        if result.returncode == 0:
            return json.loads(result.stdout)
        elif result.returncode == 6:
            print(f"Rate limited. Waiting {wait}s (attempt {attempt + 1}/{max_retries})")
            time.sleep(wait)
            wait *= 2
        elif result.returncode == 3:
            raise PermissionError("GOWA authentication failed. Run: gowa auth login")
        else:
            raise RuntimeError(f"GOWA error (exit {result.returncode}): {result.stderr}")

    raise TimeoutError("Rate limit retries exhausted")


def gowa_chat_messages(jid: str, limit: int = 50) -> list:
    """Fetch chat messages from GOWA CLI."""
    result = subprocess.run(
        ["gowa", "chat", "messages", jid, "--json", "--limit", str(limit)],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"Failed to fetch messages: {result.stderr}")
    return json.loads(result.stdout)
```

### Node.js: exec Integration

```javascript
const { execSync } = require("child_process");

function gowaSend(phone, message) {
  try {
    const stdout = execSync(
      `gowa send text --to "${phone}" "${message}" --accept-risk --json`,
      { encoding: "utf-8", timeout: 30000 }
    );
    return JSON.parse(stdout);
  } catch (err) {
    const exitCode = err.status;
    if (exitCode === 6) {
      throw new Error("RATE_LIMITED: Wait before sending again");
    } else if (exitCode === 3) {
      throw new Error("AUTH_ERROR: Run gowa auth login");
    } else if (exitCode === 5) {
      throw new Error("SERVER_ERROR: GOWA server unreachable");
    }
    throw new Error(`GOWA_ERROR (${exitCode}): ${err.stderr}`);
  }
}

function gowaChatMessages(jid, limit = 50) {
  const stdout = execSync(
    `gowa chat messages "${jid}" --json --limit ${limit}`,
    { encoding: "utf-8", timeout: 30000 }
  );
  return JSON.parse(stdout);
}
```

---

## 4. For CI/CD Pipelines

### Non-interactive Auth

CI environments have no TTY. Always pass credentials via flags:

```bash
# GitHub Actions / GitLab CI / Jenkins
gowa auth login \
  --url "$GOWA_SERVER_URL" \
  --username "$GOWA_USERNAME" \
  --password "$GOWA_PASSWORD"
```

Store credentials in CI secrets, never in code.

### Exit Code-Based Flow Control

```yaml
# GitHub Actions example
- name: Notify via WhatsApp
  run: |
    gowa send text --to "${{ secrets.NOTIFY_PHONE }}" \
      "Deploy ${{ github.sha }} to production completed" \
      --accept-risk --json
  continue-on-error: true  # Don't fail the pipeline if notification fails

- name: Check notification result
  if: failure()
  run: echo "WhatsApp notification failed — check GOWA server"
```

### --accept-risk in CI Environment

The first send requires `--accept-risk`. For CI, use the environment variable or persist in config:

```bash
# Option A: Environment variable (recommended for CI)
export GOWA_RISK_ACCEPTED=true

# Option B: Persist in config file
mkdir -p ~/.config/gowa
echo "risk_accepted: true" >> ~/.config/gowa/config.yaml
```

Or pass `--accept-risk` on every send command.

### Timeout Configuration

For slow connections or high-latency environments, configure the HTTP timeout:

```bash
# Environment variable
export GOWA_TIMEOUT=60s

# Or per-command flag
gowa send text --to "$PHONE" "Hello" --accept-risk --timeout 60s
```

Valid duration formats: `10s`, `1m`, `2m30s`. Default is `30s`.

### Audit Log for Compliance

Every send operation is logged to `~/.config/gowa/audit.log` as newline-delimited JSON:

```json
{"timestamp":"2026-03-19T10:30:00Z","operation":"send_text","recipient":"5511999999999","result":"success"}
```

In CI, archive this file as a build artifact:

```yaml
- name: Archive audit log
  uses: actions/upload-artifact@v4
  with:
    name: gowa-audit-log
    path: ~/.config/gowa/audit.log
  if: always()
```

---

## 5. WhatsApp-Specific Safety

### Use Disposable Numbers for Testing

**GOWA CLI uses an unofficial WhatsApp Web API.** Your number can be temporarily or permanently banned. Always:

- Use a dedicated SIM card for automation (not your personal number)
- Buy a prepaid SIM specifically for testing
- Consider the official WhatsApp Business API for production use

### Respect Rate Limits

The built-in rate limits (3/min, 30/hr, 200/day) exist for YOUR protection:

- They prevent your number from being flagged as a spammer
- WhatsApp's anti-spam systems detect rapid message bursts
- A banned number loses all message history and contacts

### Monitor the Audit Log

```bash
# View recent send operations
tail -20 ~/.config/gowa/audit.log | jq .

# Count sends today
TODAY=$(date -u +%Y-%m-%d)
grep "$TODAY" ~/.config/gowa/audit.log | wc -l

# Find failed operations
grep '"result":"error"' ~/.config/gowa/audit.log | jq .
```

### Never Bulk Send to Unknown Numbers

- Only send to numbers that have contacted you first or opted in
- Sending to unknown numbers is the fastest way to get banned
- WhatsApp monitors block/report ratios per sender

### Image and File Validation

The CLI validates files before sending:

- **Images:** only `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp` allowed
- **Files:** must exist and be a regular file (not a directory)
- Validate files in your script before calling `gowa send`:

```bash
# Validate before sending
if [ ! -f "$FILE" ]; then
  echo "File not found: $FILE" >&2
  exit 1
fi

gowa send image --to "$PHONE" --file "$FILE" --caption "Report" --accept-risk --json
```

---

## 6. Automation Patterns

### Cron-Based Message Scheduling

```bash
# crontab -e
# Daily report at 9 AM (UTC)
0 9 * * * /usr/local/bin/gowa send text --to 5511999999999 "Good morning! Daily report is ready." --accept-risk --quiet >> /var/log/gowa-cron.log 2>&1

# Weekly summary on Mondays
0 10 * * 1 /path/to/weekly-summary.sh >> /var/log/gowa-cron.log 2>&1
```

### Event-Driven Notifications

```bash
#!/usr/bin/env bash
# git-post-deploy-hook.sh — Notify after successful deploy
set -euo pipefail

DEPLOY_ENV="$1"        # production | staging
NOTIFY_PHONE="$2"

COMMIT=$(git rev-parse --short HEAD)
BRANCH=$(git rev-parse --abbrev-ref HEAD)
AUTHOR=$(git log -1 --format='%an')

gowa send text --to "$NOTIFY_PHONE" \
  "Deploy to $DEPLOY_ENV complete. Branch: $BRANCH, Commit: $COMMIT, Author: $AUTHOR" \
  --accept-risk --quiet >/dev/null 2>&1 || true  # Best-effort, don't block deploy
```

### Chat Monitoring and Response

```bash
#!/usr/bin/env bash
# poll-messages.sh — Poll for new messages and trigger actions
set -euo pipefail

JID="$1"
LAST_CHECK_FILE="/tmp/gowa-last-check"
LAST_CHECK=$(cat "$LAST_CHECK_FILE" 2>/dev/null || date -u -d "5 minutes ago" +%Y-%m-%dT%H:%M:%SZ)

MESSAGES=$(gowa chat messages "$JID" --json --since "$LAST_CHECK" 2>/dev/null)
if [ $? -ne 0 ]; then
  exit 1
fi

# Update checkpoint
date -u +%Y-%m-%dT%H:%M:%SZ > "$LAST_CHECK_FILE"

# Process new messages
echo "$MESSAGES" | jq -c '.[]' | while read -r msg; do
  TEXT=$(echo "$msg" | jq -r '.text // ""')

  case "$TEXT" in
    *"status"*)
      gowa send text --to "$JID" "All systems operational." --accept-risk --quiet >/dev/null
      sleep 25
      ;;
    *"help"*)
      gowa send text --to "$JID" "Commands: status, help, report" --accept-risk --quiet >/dev/null
      sleep 25
      ;;
  esac
done
```

### Integration with Webhooks

```bash
#!/usr/bin/env bash
# webhook-to-whatsapp.sh — Forward webhook events to WhatsApp
# Called by: curl -X POST http://yourserver:8080/webhook -d '{"event":"deploy","status":"ok"}'

set -euo pipefail

PAYLOAD=$(cat)  # Read webhook body from stdin
EVENT=$(echo "$PAYLOAD" | jq -r '.event // "unknown"')
STATUS=$(echo "$PAYLOAD" | jq -r '.status // "unknown"')

NOTIFY_PHONE="5511999999999"

echo "$PAYLOAD" | jq -r '"Webhook: \(.event) - Status: \(.status)"' | \
  gowa send text --to "$NOTIFY_PHONE" --accept-risk --quiet >/dev/null
```

---

## 7. Anti-Patterns (What NOT to Do)

### Do NOT Parse Table Output

```bash
# WRONG — table format is for humans, not machines
gowa device list | grep "connected" | awk '{print $1}'

# RIGHT — use --json for reliable parsing
gowa device list --json | jq -r '.[] | select(.status == "connected") | .id'
```

### Do NOT Bypass --accept-risk Without Understanding

```bash
# WRONG — blindly accepting in every script
echo "risk_accepted: true" > ~/.config/gowa/config.yaml  # Overwrites all config!

# RIGHT — understand the risks, set once with proper config
gowa auth login --url http://localhost:3000 --username admin --password secret
gowa send text --to 5511999999999 "test" --accept-risk  # First time acknowledges
# Subsequent sends don't need the flag (persisted in config)
```

### Do NOT Ignore Exit Code 6

```bash
# WRONG — ignoring rate limit
gowa send text --to "$PHONE" "msg" --accept-risk || true  # Silently swallows rate limit!

# RIGHT — handle rate limit specifically
gowa send text --to "$PHONE" "msg" --accept-risk --json
EC=$?
if [ $EC -eq 6 ]; then
  echo "Rate limited — scheduling retry" >&2
  # ... implement backoff
fi
```

### Do NOT Send Without Phone Validation

```bash
# WRONG — passing unsanitized input
USER_INPUT="not-a-phone"
gowa send text --to "$USER_INPUT" "Hello" --accept-risk  # Will fail with exit 2

# RIGHT — validate format first
if [[ "$USER_INPUT" =~ ^[0-9]{10,15}$ ]]; then
  gowa send text --to "$USER_INPUT" "Hello" --accept-risk --json
else
  echo "Invalid phone number: $USER_INPUT" >&2
fi
```

### Do NOT Send Without --dry-run First (Agents)

```bash
# WRONG — agent sends directly without validating
gowa send text --to "$PHONE" "Hello" --accept-risk --json

# RIGHT — agent validates first, then sends
gowa send text --to "$PHONE" "Hello" --accept-risk --json --dry-run
if [ $? -eq 0 ]; then
  gowa send text --to "$PHONE" "Hello" --accept-risk --json
fi
```

A dry-run catches hallucinated phone numbers and invalid files without consuming a rate limit token.

### Do NOT Run Multiple CLI Instances Simultaneously

The state file (`~/.config/gowa/state.json`) uses file locking, but concurrent writes can cause contention:

```bash
# WRONG — parallel sends
echo "5511111111111
5522222222222
5533333333333" | xargs -P 4 -I {} gowa send text --to {} "Hello" --accept-risk

# RIGHT — use --to-file for batch (built-in delays)
gowa send text --to-file phones.txt "Hello" --accept-risk --json

# OR — sequential with delay
while read -r phone; do
  gowa send text --to "$phone" "Hello" --accept-risk --json
  sleep 25
done < phones.txt
```

---

## 8. Troubleshooting Guide

### Rate Limit Hit (Exit Code 6)

**Symptom:** `Rate limit exceeded: N messages sent in last minute/hour/day`

**Fix:**
1. Wait for the indicated duration (shown in error message)
2. Check state file: `cat ~/.config/gowa/state.json | jq .`
3. If state file is corrupted, reset it: `echo '{"messages_sent":[]}' > ~/.config/gowa/state.json`
4. Implement exponential backoff in your scripts (see Section 2)

### Authentication Failure (Exit Code 3)

**Symptom:** `Authentication failed` or connection test fails

**Fix:**
1. Re-login: `gowa auth login --url http://localhost:3000 --username admin --password secret`
2. Verify server is reachable: `curl -s http://localhost:3000/`
3. Check stored config: `cat ~/.config/gowa/config.yaml`
4. Verify credentials are correct with the GOWA server admin

### File Not Found (Exit Code 2)

**Symptom:** `file not found: /path/to/file.jpg`

**Fix:**
1. Validate the path exists before calling send: `[ -f "$FILE" ]`
2. Use absolute paths, not relative
3. For images, check extension is allowed: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`

### Connection Error (Exit Code 5)

**Symptom:** `Cannot connect to GOWA server at http://localhost:3000`

**Fix:**
1. Check GOWA server status: `curl -s http://localhost:3000/`
2. Start the server: `docker run -p 3000:3000 aldinokemal2104/go-whatsapp-web-multidevice`
3. Verify the URL in config: `gowa auth status --json | jq '.api_url'`
4. Check firewall and network connectivity

### Invalid Phone Number (Exit Code 2)

**Symptom:** `invalid phone number "...": expected 10-15 digits`

**Fix:**
1. Use E.164 format without `+` sign: `5511999999999` (country code + number)
2. Or use full JID: `5511999999999@s.whatsapp.net`
3. No dashes, spaces, or parentheses

### Risk Not Accepted (Exit Code 2)

**Symptom:** `Risk acknowledgment required for send operations`

**Fix:**
1. Pass `--accept-risk` on your first send command
2. Or add to config: `gowa send text --to 5511999999999 "test" --accept-risk`
3. For CI: set `risk_accepted: true` in `~/.config/gowa/config.yaml`

### Request Timeout (Slow Connection)

**Symptom:** Command hangs or returns timeout error on slow networks.

**Fix:**
1. Increase timeout: `gowa send text --to "$PHONE" "Hello" --accept-risk --timeout 60s`
2. Or set globally: `export GOWA_TIMEOUT=60s`
3. Valid formats: `10s`, `1m`, `2m30s`. Default is `30s`.

### State File Locked

**Symptom:** `acquiring lock: ...` error

**Fix:**
1. Remove stale lock file: `rm ~/.config/gowa/state.json.lock`
2. Ensure no other gowa process is running
3. Avoid running multiple instances in parallel (see Anti-Patterns)

---

# Portugues

## Indice

1. [Principios Gerais](#1-principios-gerais)
2. [Para Shell Scripts](#2-para-shell-scripts-1)
3. [Para Agentes IA](#3-para-agentes-ia-claude-code-codex-gemini-cursor-etc)
4. [Para Pipelines CI/CD](#4-para-pipelines-cicd)
5. [Seguranca Especifica do WhatsApp](#5-seguranca-especifica-do-whatsapp)
6. [Padroes de Automacao](#6-padroes-de-automacao)
7. [Anti-Padroes](#7-anti-padroes-o-que-nao-fazer)
8. [Guia de Solucao de Problemas](#8-guia-de-solucao-de-problemas)

---

## 1. Principios Gerais

### Seguranca em Primeiro Lugar

O GOWA CLI foi construido com uma filosofia de **seguranca em primeiro lugar**. Toda operacao de envio passa por:

1. **Reconhecimento de risco** — flag `--accept-risk` ou config persistida
2. **Validacao de telefone** — formato E.164 (10-15 digitos) ou JID do WhatsApp
3. **Validacao de arquivo** — verificacao de existencia + whitelist de extensoes para imagens
4. **Rate limiting** — arquivo de estado local com janelas por minuto/hora/dia
5. **Log de auditoria** — toda operacao de envio e registrada em `~/.config/gowa/audit.log`

### Saida Estruturada

O GOWA CLI suporta tres modos de saida:

| Flag | Modo | Caso de Uso |
|------|------|-------------|
| *(nenhuma)* | Tabela | Saida legivel para humanos no terminal |
| `--json` | JSON | Parseavel por maquina, dados completos |
| `--quiet` | Valor simples | Extracao de valor unico (message_id, status) |

**Regra:** Sempre use `--json` para automacao. Nunca parse saida em tabela.

### Codigos de Saida

| Codigo | Significado | Recuperacao |
|--------|-------------|-------------|
| `0` | Sucesso | -- |
| `1` | Erro geral | Verifique mensagem no stderr |
| `2` | Erro de uso/entrada | Corrija flags ou argumentos |
| `3` | Erro de autenticacao | Execute `gowa auth login` |
| `4` | Recurso nao encontrado | Verifique o ID do recurso |
| `5` | Erro de servidor/conexao | Verifique o status do servidor GOWA |
| `6` | Rate limit excedido | Aguarde e tente novamente com backoff |

### Operacoes Idempotentes

Operacoes de leitura (`device list`, `chat list`, `chat messages`, `auth status`) sao seguras para repetir. Operacoes de envio **nao** sao idempotentes — cada chamada envia uma nova mensagem e e registrada no estado do rate limiter.

### Rate Limits (Integrados)

| Janela | Limite |
|--------|--------|
| Por minuto | 3 mensagens |
| Por hora | 30 mensagens |
| Por dia | 200 mensagens |

Esses limites sao **intencionalmente conservadores** para proteger sua conta WhatsApp de ser marcada ou banida.

---

## 2. Para Shell Scripts

### Sempre Use --json para Saida Parseavel

```bash
# BOM: Parse JSON com jq
DEVICE_ID=$(gowa device list --json | jq -r '.[0].id')

# RUIM: Parse saida de tabela (fragil, quebra com mudancas de formato)
DEVICE_ID=$(gowa device list | awk 'NR==2 {print $1}')
```

### Verifique Codigos de Saida

```bash
gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json
EXIT_CODE=$?

case $EXIT_CODE in
  0) echo "Mensagem enviada com sucesso" ;;
  2) echo "Entrada invalida: verifique numero ou mensagem" ;;
  3) echo "Falha na auth: re-login necessario" ;;
  5) echo "Servidor inacessivel: verifique servidor GOWA" ;;
  6) echo "Rate limited: aguardando..." ; sleep 60 ;;
  *) echo "Erro inesperado (exit $EXIT_CODE)" ;;
esac
```

### Trate Rate Limits com Backoff Exponencial

```bash
#!/usr/bin/env bash
set -euo pipefail

enviar_com_backoff() {
  local to="$1"
  local mensagem="$2"
  local max_tentativas=5
  local tentativa=0
  local espera=10

  while [ $tentativa -lt $max_tentativas ]; do
    RESULTADO=$(gowa send text --to "$to" "$mensagem" --accept-risk --json 2>&1)
    EXIT_CODE=$?

    if [ $EXIT_CODE -eq 0 ]; then
      echo "$RESULTADO"
      return 0
    elif [ $EXIT_CODE -eq 6 ]; then
      echo "Rate limited. Aguardando ${espera}s (tentativa $((tentativa+1))/$max_tentativas)..." >&2
      sleep $espera
      espera=$((espera * 2))  # backoff exponencial: 10, 20, 40, 80, 160
      tentativa=$((tentativa + 1))
    else
      echo "Erro fatal (exit $EXIT_CODE): $RESULTADO" >&2
      return $EXIT_CODE
    fi
  done

  echo "Tentativas esgotadas" >&2
  return 6
}

enviar_com_backoff "5511999999999" "Ola do script"
```

### Use --quiet para Extracao Simples

```bash
# Obtenha apenas o ID da mensagem apos enviar
MSG_ID=$(gowa send text --to "$PHONE" "Ola" --accept-risk --quiet)
echo "Mensagem enviada: $MSG_ID"

# Verifique status de autenticacao
IS_AUTH=$(gowa auth status --quiet)
if [ "$IS_AUTH" = "true" ]; then
  echo "Autenticado"
fi
```

### Pipe stdin para Mensagens Dinamicas

```bash
# Pipe de outro comando
echo "Deploy concluido em $(date)" | gowa send text --to "$PHONE" --accept-risk

# Pipe de um arquivo
cat /var/log/relatorio.txt | gowa send text --to "$PHONE" --accept-risk

# Heredoc para mensagens multi-linha
gowa send text --to "$PHONE" --accept-risk <<EOF
Relatorio de Build
Status: SUCESSO
Branch: main
Commit: $(git rev-parse --short HEAD)
EOF
```

### Exemplo: Envio em Lote com Consciencia de Rate Limit

```bash
#!/usr/bin/env bash
# envio-lote.sh — Envia mensagem para lista de destinatarios com consciencia de rate
set -euo pipefail

MENSAGEM="$1"
ARQUIVO_DESTINATARIOS="$2"
DELAY=25  # 25 segundos entre mensagens (seguro para limite de 3/min)

if [ ! -f "$ARQUIVO_DESTINATARIOS" ]; then
  echo "Arquivo nao encontrado: $ARQUIVO_DESTINATARIOS" >&2
  exit 1
fi

ENVIADOS=0
FALHAS=0

while IFS= read -r telefone; do
  [[ -z "$telefone" || "$telefone" =~ ^# ]] && continue

  RESULTADO=$(gowa send text --to "$telefone" "$MENSAGEM" --accept-risk --json 2>&1)
  EXIT_CODE=$?

  if [ $EXIT_CODE -eq 0 ]; then
    MSG_ID=$(echo "$RESULTADO" | jq -r '.message_id // "desconhecido"')
    echo "[OK] $telefone -> $MSG_ID"
    ENVIADOS=$((ENVIADOS + 1))
  elif [ $EXIT_CODE -eq 6 ]; then
    echo "[RATE] $telefone -> aguardando 120s..." >&2
    sleep 120
    gowa send text --to "$telefone" "$MENSAGEM" --accept-risk --json >/dev/null 2>&1 && ENVIADOS=$((ENVIADOS + 1)) || FALHAS=$((FALHAS + 1))
  else
    echo "[FALHA] $telefone -> exit $EXIT_CODE" >&2
    FALHAS=$((FALHAS + 1))
  fi

  sleep "$DELAY"
done < "$ARQUIVO_DESTINATARIOS"

echo "Concluido: $ENVIADOS enviados, $FALHAS falhas"
```

### Envio em Lote com --to-file (Seguranca de Rate Integrada)

Em vez de gerenciar delays manualmente, use `--to-file` para envios em lote. O CLI aplica um delay integrado de 2 segundos entre destinatarios e para o lote em erros de rate limit:

```bash
# destinatarios.txt — um numero de telefone por linha (# comentarios e linhas em branco sao ignorados)

# Dry-run primeiro para validar todos os destinatarios
gowa send text --to-file destinatarios.txt "Ola a todos" --accept-risk --json --dry-run

# Enviar de verdade
gowa send text --to-file destinatarios.txt "Ola a todos" --accept-risk --json

# Enviar imagem para multiplos destinatarios
gowa send image --to-file destinatarios.txt --file relatorio.png --caption "Relatorio mensal" --accept-risk --json
```

### Exemplo: Script de Monitoramento com Mensagens de Chat

```bash
#!/usr/bin/env bash
# monitorar-e-alertar.sh — Verifica servico e alerta via WhatsApp
set -euo pipefail

TELEFONE_ALERTA="5511999999999"
URL_SERVICO="https://meuapp.exemplo.com/health"
ARQUIVO_ESTADO="/tmp/gowa-monitor-estado"

verificar_servico() {
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL_SERVICO" 2>/dev/null || echo "000")
  echo "$HTTP_CODE"
}

STATUS=$(verificar_servico)
STATUS_ANTERIOR=$(cat "$ARQUIVO_ESTADO" 2>/dev/null || echo "200")

if [ "$STATUS" != "200" ] && [ "$STATUS_ANTERIOR" = "200" ]; then
  gowa send text --to "$TELEFONE_ALERTA" \
    "ALERTA: Servico FORA DO AR. Status: $STATUS. URL: $URL_SERVICO. Hora: $(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --accept-risk --quiet >/dev/null
elif [ "$STATUS" = "200" ] && [ "$STATUS_ANTERIOR" != "200" ]; then
  gowa send text --to "$TELEFONE_ALERTA" \
    "RECUPERADO: Servico NO AR. URL: $URL_SERVICO. Hora: $(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --accept-risk --quiet >/dev/null
fi

echo "$STATUS" > "$ARQUIVO_ESTADO"
```

---

## 3. Para Agentes IA (Claude Code, Codex, Gemini, Cursor, etc.)

Agentes IA com acesso ao shell podem usar o GOWA CLI como ferramenta para comunicacao via WhatsApp. Siga esses padroes para integracao confiavel.

### Sempre Faca Dry-Run Antes de Enviar

A flag `--dry-run` valida todas as entradas (telefone, arquivo, extensao) e visualiza a operacao sem enviar. Este e o padrao recomendado para agentes IA:

```bash
# Passo 1: Dry-run para validar
gowa send text --to "$PHONE" "$MSG" --accept-risk --json --dry-run
if [ $? -ne 0 ]; then
  echo "Validacao falhou — nao enviar"
  exit 1
fi

# Passo 2: Enviar de verdade (somente apos dry-run bem-sucedido)
gowa send text --to "$PHONE" "$MSG" --accept-risk --json
```

Isso previne desperdicio de tokens de rate limit em entradas invalidas e captura numeros de telefone alucinados ou caminhos de arquivo antes que cheguem a API.

### Use Flag --json, Parse com jq

```bash
# Agente le lista de chats para contexto
CHATS=$(gowa chat list --json --limit 10)
echo "$CHATS" | jq -r '.[] | "\(.name): \(.last_message)"'

# Agente le historico de mensagens
MENSAGENS=$(gowa chat messages 5511999999999 --json --limit 20 --since "2026-01-01T00:00:00Z")
echo "$MENSAGENS" | jq -r '.[] | "[\(.from)] \(.text)"'
```

### Trate Erros com --json no stderr

Com `--json`, erros sao escritos no stderr como JSON estruturado (campos: `error`, `type`, `code`, `message`, `recovery`):

```bash
# Agente envia com tratamento de erros (erros --json vao para stderr)
OUTPUT=$(gowa send text --to "$PHONE" "$MSG" --accept-risk --json 2>/tmp/gowa-err.json)
if [ $? -eq 0 ]; then
  echo "Mensagem enviada: $(echo "$OUTPUT" | jq -r '.message_id')"
else
  echo "Envio falhou: $(jq -r '.message' /tmp/gowa-err.json)"
fi
```

### Nunca Faca Loop de Envio Sem Sleep

O rate limiter permite 3 mensagens por minuto. Um agente fazendo loop sem delay vai bater no limite na 4a mensagem e receber exit code 6.

```bash
# RUIM: Agente envia em loop apertado
for phone in "${PHONES[@]}"; do
  gowa send text --to "$phone" "Update" --accept-risk  # Vai bater no rate limit na 4a chamada
done

# BOM: Agente respeita rate limits
for phone in "${PHONES[@]}"; do
  gowa send text --to "$phone" "Update" --accept-risk --json
  sleep 25  # Seguro: fica abaixo de 3/min
done
```

### Exemplo: Agente Enviando Notificacao Apos Conclusao de Tarefa

```bash
#!/usr/bin/env bash
# Agente notifica membro da equipe apos completar tarefa de desenvolvimento

TELEFONE_NOTIFICACAO="5511999999999"
RESUMO_TAREFA="$1"

MENSAGEM="Tarefa Concluida
$RESUMO_TAREFA
Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

RESULTADO=$(gowa send text --to "$TELEFONE_NOTIFICACAO" "$MENSAGEM" --accept-risk --json 2>&1)
EXIT=$?

case $EXIT in
  0) echo "Notificacao enviada: $(echo "$RESULTADO" | jq -r '.message_id // "enviado"')" ;;
  3) echo "ERRO_AUTH: Agente nao pode enviar — GOWA nao configurado" ;;
  5) echo "ERRO_SERVIDOR: Servidor GOWA inacessivel" ;;
  6) echo "RATE_LIMITED: Muitas mensagens enviadas recentemente. Tente mais tarde." ;;
  *) echo "ERRO ($EXIT): $RESULTADO" ;;
esac
```

### Python: Integracao com subprocess

```python
import subprocess
import json
import time

def gowa_enviar(telefone: str, mensagem: str, max_tentativas: int = 3) -> dict:
    """Envia mensagem WhatsApp via GOWA CLI com logica de retry."""
    espera = 10
    for tentativa in range(max_tentativas):
        resultado = subprocess.run(
            ["gowa", "send", "text", "--to", telefone, mensagem, "--accept-risk", "--json"],
            capture_output=True, text=True
        )

        if resultado.returncode == 0:
            return json.loads(resultado.stdout)
        elif resultado.returncode == 6:
            print(f"Rate limited. Aguardando {espera}s (tentativa {tentativa + 1}/{max_tentativas})")
            time.sleep(espera)
            espera *= 2
        elif resultado.returncode == 3:
            raise PermissionError("Autenticacao GOWA falhou. Execute: gowa auth login")
        else:
            raise RuntimeError(f"Erro GOWA (exit {resultado.returncode}): {resultado.stderr}")

    raise TimeoutError("Tentativas de rate limit esgotadas")
```

---

## 4. Para Pipelines CI/CD

### Autenticacao Nao-Interativa

Ambientes CI nao tem TTY. Sempre passe credenciais via flags:

```bash
gowa auth login \
  --url "$GOWA_SERVER_URL" \
  --username "$GOWA_USERNAME" \
  --password "$GOWA_PASSWORD"
```

Armazene credenciais em secrets do CI, nunca no codigo.

### --accept-risk em Ambiente CI

```bash
# Opcao A: Variavel de ambiente (recomendado para CI)
export GOWA_RISK_ACCEPTED=true

# Opcao B: Persistir no arquivo de config
mkdir -p ~/.config/gowa
echo "risk_accepted: true" >> ~/.config/gowa/config.yaml
```

### Configuracao de Timeout

Para conexoes lentas ou ambientes de alta latencia, configure o timeout HTTP:

```bash
# Variavel de ambiente
export GOWA_TIMEOUT=60s

# Ou flag por comando
gowa send text --to "$PHONE" "Ola" --accept-risk --timeout 60s
```

Formatos de duracao validos: `10s`, `1m`, `2m30s`. Padrao e `30s`.

### Log de Auditoria para Compliance

Toda operacao de envio e logada em `~/.config/gowa/audit.log` como JSON delimitado por newline. No CI, arquive como artefato de build.

---

## 5. Seguranca Especifica do WhatsApp

### Use Numeros Descartaveis para Testes

**O GOWA CLI usa uma API nao oficial do WhatsApp Web.** Seu numero pode ser banido temporaria ou permanentemente. Sempre:

- Use um chip SIM dedicado para automacao (nao seu numero pessoal)
- Compre um chip pre-pago especificamente para testes
- Considere a API oficial do WhatsApp Business para uso em producao

### Respeite os Rate Limits

Os rate limits integrados (3/min, 30/hr, 200/dia) existem para SUA protecao:

- Eles previnem que seu numero seja marcado como spammer
- Os sistemas anti-spam do WhatsApp detectam rajadas rapidas de mensagens
- Um numero banido perde todo o historico de mensagens e contatos

### Monitore o Log de Auditoria

```bash
# Ver operacoes de envio recentes
tail -20 ~/.config/gowa/audit.log | jq .

# Contar envios de hoje
HOJE=$(date -u +%Y-%m-%d)
grep "$HOJE" ~/.config/gowa/audit.log | wc -l

# Encontrar operacoes com falha
grep '"result":"error"' ~/.config/gowa/audit.log | jq .
```

### Nunca Envie em Massa para Numeros Desconhecidos

- Envie apenas para numeros que entraram em contato com voce primeiro ou fizeram opt-in
- Enviar para numeros desconhecidos e a forma mais rapida de ser banido
- O WhatsApp monitora taxas de bloqueio/denuncia por remetente

---

## 6. Padroes de Automacao

### Agendamento de Mensagens via Cron

```bash
# crontab -e
# Relatorio diario as 9h (UTC)
0 9 * * * /usr/local/bin/gowa send text --to 5511999999999 "Bom dia! Relatorio diario pronto." --accept-risk --quiet >> /var/log/gowa-cron.log 2>&1
```

### Notificacoes Orientadas a Eventos

```bash
#!/usr/bin/env bash
# hook-pos-deploy.sh — Notifica apos deploy bem-sucedido
set -euo pipefail

AMBIENTE="$1"
TELEFONE="$2"
COMMIT=$(git rev-parse --short HEAD)
BRANCH=$(git rev-parse --abbrev-ref HEAD)

gowa send text --to "$TELEFONE" \
  "Deploy para $AMBIENTE concluido. Branch: $BRANCH, Commit: $COMMIT" \
  --accept-risk --quiet >/dev/null 2>&1 || true
```

---

## 7. Anti-Padroes (O Que NAO Fazer)

### NAO Parse Saida de Tabela

```bash
# ERRADO
gowa device list | grep "connected" | awk '{print $1}'

# CERTO
gowa device list --json | jq -r '.[] | select(.status == "connected") | .id'
```

### NAO Ignore Exit Code 6

```bash
# ERRADO
gowa send text --to "$PHONE" "msg" --accept-risk || true

# CERTO
gowa send text --to "$PHONE" "msg" --accept-risk --json
EC=$?
if [ $EC -eq 6 ]; then
  echo "Rate limited — agendando retry" >&2
fi
```

### NAO Envie Sem --dry-run Primeiro (Agentes)

```bash
# ERRADO — agente envia diretamente sem validar
gowa send text --to "$PHONE" "Ola" --accept-risk --json

# CERTO — agente valida primeiro, depois envia
gowa send text --to "$PHONE" "Ola" --accept-risk --json --dry-run
if [ $? -eq 0 ]; then
  gowa send text --to "$PHONE" "Ola" --accept-risk --json
fi
```

Um dry-run captura numeros de telefone alucinados e arquivos invalidos sem consumir um token de rate limit.

### NAO Execute Multiplas Instancias Simultaneamente

```bash
# ERRADO — envios em paralelo
xargs -P 4 -I {} gowa send text --to {} "Ola" --accept-risk < phones.txt

# CERTO — use --to-file para lote (delays integrados)
gowa send text --to-file phones.txt "Ola" --accept-risk --json

# OU — sequencial com delay
while read -r telefone; do
  gowa send text --to "$telefone" "Ola" --accept-risk --json
  sleep 25
done < phones.txt
```

---

## 8. Guia de Solucao de Problemas

### Rate Limit Atingido (Exit Code 6)

**Sintoma:** `Rate limit exceeded: N messages sent in last minute/hour/day`

**Solucao:**
1. Aguarde a duracao indicada na mensagem de erro
2. Verifique arquivo de estado: `cat ~/.config/gowa/state.json | jq .`
3. Se corrompido, resete: `echo '{"messages_sent":[]}' > ~/.config/gowa/state.json`
4. Implemente backoff exponencial nos seus scripts (veja Secao 2)

### Falha de Autenticacao (Exit Code 3)

**Solucao:**
1. Re-login: `gowa auth login --url http://localhost:3000 --username admin --password secret`
2. Verifique se servidor esta acessivel: `curl -s http://localhost:3000/`
3. Confira config armazenada: `cat ~/.config/gowa/config.yaml`

### Arquivo Nao Encontrado (Exit Code 2)

**Solucao:**
1. Valide se caminho existe antes de chamar send: `[ -f "$ARQUIVO" ]`
2. Use caminhos absolutos, nao relativos
3. Para imagens, verifique extensao permitida: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`

### Erro de Conexao (Exit Code 5)

**Solucao:**
1. Verifique status do servidor GOWA: `curl -s http://localhost:3000/`
2. Inicie o servidor: `docker run -p 3000:3000 aldinokemal2104/go-whatsapp-web-multidevice`
3. Verifique URL no config: `gowa auth status --json | jq '.api_url'`

### Numero de Telefone Invalido (Exit Code 2)

**Solucao:**
1. Use formato E.164 sem sinal `+`: `5511999999999` (codigo do pais + numero)
2. Ou use JID completo: `5511999999999@s.whatsapp.net`
3. Sem tracos, espacos ou parenteses

### Timeout de Requisicao (Conexao Lenta)

**Sintoma:** Comando trava ou retorna erro de timeout em redes lentas.

**Solucao:**
1. Aumente o timeout: `gowa send text --to "$PHONE" "Ola" --accept-risk --timeout 60s`
2. Ou defina globalmente: `export GOWA_TIMEOUT=60s`
3. Formatos validos: `10s`, `1m`, `2m30s`. Padrao e `30s`.

### Arquivo de Estado Travado

**Solucao:**
1. Remova lock file obsoleto: `rm ~/.config/gowa/state.json.lock`
2. Garanta que nenhum outro processo gowa esta rodando
3. Evite rodar multiplas instancias em paralelo

---

# Espanol

## Indice

1. [Principios Generales](#1-principios-generales)
2. [Para Shell Scripts](#2-para-shell-scripts-2)
3. [Para Agentes IA](#3-para-agentes-ia-claude-code-codex-gemini-cursor-etc-1)
4. [Para Pipelines CI/CD](#4-para-pipelines-cicd-1)
5. [Seguridad Especifica de WhatsApp](#5-seguridad-especifica-de-whatsapp)
6. [Patrones de Automatizacion](#6-patrones-de-automatizacion)
7. [Anti-Patrones](#7-anti-patrones-lo-que-no-hacer)
8. [Guia de Solucion de Problemas](#8-guia-de-solucion-de-problemas-1)

---

## 1. Principios Generales

### Seguridad Primero

GOWA CLI fue construido con una filosofia de **seguridad primero**. Toda operacion de envio pasa por:

1. **Reconocimiento de riesgo** — flag `--accept-risk` o config persistida
2. **Validacion de telefono** — formato E.164 (10-15 digitos) o JID de WhatsApp
3. **Validacion de archivo** — verificacion de existencia + whitelist de extensiones para imagenes
4. **Rate limiting** — archivo de estado local con ventanas por minuto/hora/dia
5. **Log de auditoria** — toda operacion de envio se registra en `~/.config/gowa/audit.log`

### Salida Estructurada

GOWA CLI soporta tres modos de salida:

| Flag | Modo | Caso de Uso |
|------|------|-------------|
| *(ninguna)* | Tabla | Salida legible para humanos en terminal |
| `--json` | JSON | Parseable por maquina, datos completos |
| `--quiet` | Valor simple | Extraccion de valor unico (message_id, status) |

**Regla:** Siempre use `--json` para automatizacion. Nunca parsee salida de tabla.

### Codigos de Salida

| Codigo | Significado | Recuperacion |
|--------|-------------|--------------|
| `0` | Exito | -- |
| `1` | Error general | Verifique mensaje en stderr |
| `2` | Error de uso/entrada | Corrija flags o argumentos |
| `3` | Error de autenticacion | Ejecute `gowa auth login` |
| `4` | Recurso no encontrado | Verifique el ID del recurso |
| `5` | Error de servidor/conexion | Verifique el estado del servidor GOWA |
| `6` | Rate limit excedido | Espere y reintente con backoff |

### Operaciones Idempotentes

Las operaciones de lectura (`device list`, `chat list`, `chat messages`, `auth status`) son seguras de repetir. Las operaciones de envio **no** son idempotentes — cada llamada envia un nuevo mensaje y se registra en el estado del rate limiter.

### Rate Limits (Integrados)

| Ventana | Limite |
|---------|--------|
| Por minuto | 3 mensajes |
| Por hora | 30 mensajes |
| Por dia | 200 mensajes |

Estos limites son **intencionalmente conservadores** para proteger su cuenta de WhatsApp de ser marcada o baneada.

---

## 2. Para Shell Scripts

### Siempre Use --json para Salida Parseable

```bash
# BIEN: Parsear JSON con jq
DEVICE_ID=$(gowa device list --json | jq -r '.[0].id')

# MAL: Parsear salida de tabla (fragil, se rompe con cambios de formato)
DEVICE_ID=$(gowa device list | awk 'NR==2 {print $1}')
```

### Verifique Codigos de Salida

```bash
gowa send text --to "$PHONE" "$MESSAGE" --accept-risk --json
EXIT_CODE=$?

case $EXIT_CODE in
  0) echo "Mensaje enviado exitosamente" ;;
  2) echo "Entrada invalida: verifique numero o mensaje" ;;
  3) echo "Fallo de auth: re-login necesario" ;;
  5) echo "Servidor inaccesible: verifique servidor GOWA" ;;
  6) echo "Rate limited: esperando..." ; sleep 60 ;;
  *) echo "Error inesperado (exit $EXIT_CODE)" ;;
esac
```

### Trate Rate Limits con Backoff Exponencial

```bash
#!/usr/bin/env bash
set -euo pipefail

enviar_con_backoff() {
  local to="$1"
  local mensaje="$2"
  local max_intentos=5
  local intento=0
  local espera=10

  while [ $intento -lt $max_intentos ]; do
    RESULTADO=$(gowa send text --to "$to" "$mensaje" --accept-risk --json 2>&1)
    EXIT_CODE=$?

    if [ $EXIT_CODE -eq 0 ]; then
      echo "$RESULTADO"
      return 0
    elif [ $EXIT_CODE -eq 6 ]; then
      echo "Rate limited. Esperando ${espera}s (intento $((intento+1))/$max_intentos)..." >&2
      sleep $espera
      espera=$((espera * 2))
      intento=$((intento + 1))
    else
      echo "Error fatal (exit $EXIT_CODE): $RESULTADO" >&2
      return $EXIT_CODE
    fi
  done

  echo "Intentos agotados" >&2
  return 6
}

enviar_con_backoff "5511999999999" "Hola desde script"
```

### Use --quiet para Extraccion Simple

```bash
# Obtener solo el ID del mensaje despues de enviar
MSG_ID=$(gowa send text --to "$PHONE" "Hola" --accept-risk --quiet)
echo "Mensaje enviado: $MSG_ID"

# Verificar estado de autenticacion
IS_AUTH=$(gowa auth status --quiet)
if [ "$IS_AUTH" = "true" ]; then
  echo "Autenticado"
fi
```

### Pipe stdin para Mensajes Dinamicos

```bash
# Pipe desde otro comando
echo "Deploy completado en $(date)" | gowa send text --to "$PHONE" --accept-risk

# Heredoc para mensajes multi-linea
gowa send text --to "$PHONE" --accept-risk <<EOF
Reporte de Build
Estado: EXITOSO
Branch: main
Commit: $(git rev-parse --short HEAD)
EOF
```

### Ejemplo: Envio en Lote con Conciencia de Rate Limit

```bash
#!/usr/bin/env bash
# envio-lote.sh — Envia mensaje a lista de destinatarios con conciencia de rate
set -euo pipefail

MENSAJE="$1"
ARCHIVO_DESTINATARIOS="$2"
DELAY=25

if [ ! -f "$ARCHIVO_DESTINATARIOS" ]; then
  echo "Archivo no encontrado: $ARCHIVO_DESTINATARIOS" >&2
  exit 1
fi

ENVIADOS=0
FALLOS=0

while IFS= read -r telefono; do
  [[ -z "$telefono" || "$telefono" =~ ^# ]] && continue

  RESULTADO=$(gowa send text --to "$telefono" "$MENSAJE" --accept-risk --json 2>&1)
  EXIT_CODE=$?

  if [ $EXIT_CODE -eq 0 ]; then
    MSG_ID=$(echo "$RESULTADO" | jq -r '.message_id // "desconocido"')
    echo "[OK] $telefono -> $MSG_ID"
    ENVIADOS=$((ENVIADOS + 1))
  elif [ $EXIT_CODE -eq 6 ]; then
    echo "[RATE] $telefono -> esperando 120s..." >&2
    sleep 120
    gowa send text --to "$telefono" "$MENSAJE" --accept-risk --json >/dev/null 2>&1 && ENVIADOS=$((ENVIADOS + 1)) || FALLOS=$((FALLOS + 1))
  else
    echo "[FALLO] $telefono -> exit $EXIT_CODE" >&2
    FALLOS=$((FALLOS + 1))
  fi

  sleep "$DELAY"
done < "$ARCHIVO_DESTINATARIOS"

echo "Completado: $ENVIADOS enviados, $FALLOS fallos"
```

### Envio en Lote con --to-file (Seguridad de Rate Integrada)

En lugar de gestionar delays manualmente, use `--to-file` para envios en lote. El CLI aplica un delay integrado de 2 segundos entre destinatarios y detiene el lote en errores de rate limit:

```bash
# destinatarios.txt — un numero de telefono por linea (# comentarios y lineas en blanco se ignoran)

# Dry-run primero para validar todos los destinatarios
gowa send text --to-file destinatarios.txt "Hola a todos" --accept-risk --json --dry-run

# Enviar de verdad
gowa send text --to-file destinatarios.txt "Hola a todos" --accept-risk --json

# Enviar imagen a multiples destinatarios
gowa send image --to-file destinatarios.txt --file reporte.png --caption "Reporte mensual" --accept-risk --json
```

### Ejemplo: Script de Monitoreo con Mensajes de Chat

```bash
#!/usr/bin/env bash
# monitorear-y-alertar.sh — Verifica servicio y alerta via WhatsApp
set -euo pipefail

TELEFONO_ALERTA="5511999999999"
URL_SERVICIO="https://miapp.ejemplo.com/health"
ARCHIVO_ESTADO="/tmp/gowa-monitor-estado"

verificar_servicio() {
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL_SERVICIO" 2>/dev/null || echo "000")
  echo "$HTTP_CODE"
}

STATUS=$(verificar_servicio)
STATUS_ANTERIOR=$(cat "$ARCHIVO_ESTADO" 2>/dev/null || echo "200")

if [ "$STATUS" != "200" ] && [ "$STATUS_ANTERIOR" = "200" ]; then
  gowa send text --to "$TELEFONO_ALERTA" \
    "ALERTA: Servicio CAIDO. Estado: $STATUS. URL: $URL_SERVICIO. Hora: $(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --accept-risk --quiet >/dev/null
elif [ "$STATUS" = "200" ] && [ "$STATUS_ANTERIOR" != "200" ]; then
  gowa send text --to "$TELEFONO_ALERTA" \
    "RECUPERADO: Servicio ACTIVO. URL: $URL_SERVICIO. Hora: $(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --accept-risk --quiet >/dev/null
fi

echo "$STATUS" > "$ARCHIVO_ESTADO"
```

---

## 3. Para Agentes IA (Claude Code, Codex, Gemini, Cursor, etc.)

Los agentes IA con acceso al shell pueden usar GOWA CLI como herramienta para comunicacion via WhatsApp. Siga estos patrones para una integracion confiable.

### Siempre Haga Dry-Run Antes de Enviar

El flag `--dry-run` valida todas las entradas (telefono, archivo, extension) y previsualiza la operacion sin enviar. Este es el patron recomendado para agentes IA:

```bash
# Paso 1: Dry-run para validar
gowa send text --to "$PHONE" "$MSG" --accept-risk --json --dry-run
if [ $? -ne 0 ]; then
  echo "Validacion fallo — no enviar"
  exit 1
fi

# Paso 2: Enviar de verdad (solo despues de dry-run exitoso)
gowa send text --to "$PHONE" "$MSG" --accept-risk --json
```

Esto previene desperdiciar tokens de rate limit en entradas invalidas y captura numeros de telefono alucinados o rutas de archivo antes de que lleguen a la API.

### Use Flag --json, Parsee con jq

```bash
# Agente lee lista de chats para contexto
CHATS=$(gowa chat list --json --limit 10)
echo "$CHATS" | jq -r '.[] | "\(.name): \(.last_message)"'

# Agente lee historial de mensajes
MENSAJES=$(gowa chat messages 5511999999999 --json --limit 20 --since "2026-01-01T00:00:00Z")
echo "$MENSAJES" | jq -r '.[] | "[\(.from)] \(.text)"'
```

### Trate Errores con --json en stderr

Con `--json`, los errores se escriben en stderr como JSON estructurado (campos: `error`, `type`, `code`, `message`, `recovery`):

```bash
# Agente envia con manejo de errores (errores --json van a stderr)
OUTPUT=$(gowa send text --to "$PHONE" "$MSG" --accept-risk --json 2>/tmp/gowa-err.json)
if [ $? -eq 0 ]; then
  echo "Mensaje enviado: $(echo "$OUTPUT" | jq -r '.message_id')"
else
  echo "Envio fallo: $(jq -r '.message' /tmp/gowa-err.json)"
fi
```

### Nunca Haga Loop de Envio Sin Sleep

El rate limiter permite 3 mensajes por minuto. Un agente haciendo loop sin delay alcanzara el limite en el 4to mensaje y recibira exit code 6.

```bash
# MAL: Agente envia en loop apretado
for phone in "${PHONES[@]}"; do
  gowa send text --to "$phone" "Update" --accept-risk
done

# BIEN: Agente respeta rate limits
for phone in "${PHONES[@]}"; do
  gowa send text --to "$phone" "Update" --accept-risk --json
  sleep 25
done
```

### Ejemplo: Agente Enviando Notificacion Despues de Completar Tarea

```bash
#!/usr/bin/env bash
TELEFONO_NOTIFICACION="5511999999999"
RESUMEN_TAREA="$1"

MENSAJE="Tarea Completada
$RESUMEN_TAREA
Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"

RESULTADO=$(gowa send text --to "$TELEFONO_NOTIFICACION" "$MENSAJE" --accept-risk --json 2>&1)
EXIT=$?

case $EXIT in
  0) echo "Notificacion enviada: $(echo "$RESULTADO" | jq -r '.message_id // "enviado"')" ;;
  3) echo "ERROR_AUTH: Agente no puede enviar — GOWA no configurado" ;;
  5) echo "ERROR_SERVIDOR: Servidor GOWA inaccesible" ;;
  6) echo "RATE_LIMITED: Demasiados mensajes enviados recientemente. Intente mas tarde." ;;
  *) echo "ERROR ($EXIT): $RESULTADO" ;;
esac
```

### Python: Integracion con subprocess

```python
import subprocess
import json
import time

def gowa_enviar(telefono: str, mensaje: str, max_intentos: int = 3) -> dict:
    """Envia mensaje de WhatsApp via GOWA CLI con logica de reintento."""
    espera = 10
    for intento in range(max_intentos):
        resultado = subprocess.run(
            ["gowa", "send", "text", "--to", telefono, mensaje, "--accept-risk", "--json"],
            capture_output=True, text=True
        )

        if resultado.returncode == 0:
            return json.loads(resultado.stdout)
        elif resultado.returncode == 6:
            print(f"Rate limited. Esperando {espera}s (intento {intento + 1}/{max_intentos})")
            time.sleep(espera)
            espera *= 2
        elif resultado.returncode == 3:
            raise PermissionError("Autenticacion GOWA fallo. Ejecute: gowa auth login")
        else:
            raise RuntimeError(f"Error GOWA (exit {resultado.returncode}): {resultado.stderr}")

    raise TimeoutError("Intentos de rate limit agotados")
```

### Node.js: Integracion con exec

```javascript
const { execSync } = require("child_process");

function gowaEnviar(telefono, mensaje) {
  try {
    const stdout = execSync(
      `gowa send text --to "${telefono}" "${mensaje}" --accept-risk --json`,
      { encoding: "utf-8", timeout: 30000 }
    );
    return JSON.parse(stdout);
  } catch (err) {
    const exitCode = err.status;
    if (exitCode === 6) {
      throw new Error("RATE_LIMITED: Espere antes de enviar de nuevo");
    } else if (exitCode === 3) {
      throw new Error("ERROR_AUTH: Ejecute gowa auth login");
    } else if (exitCode === 5) {
      throw new Error("ERROR_SERVIDOR: Servidor GOWA inaccesible");
    }
    throw new Error(`ERROR_GOWA (${exitCode}): ${err.stderr}`);
  }
}
```

---

## 4. Para Pipelines CI/CD

### Autenticacion No-Interactiva

Entornos CI no tienen TTY. Siempre pase credenciales via flags:

```bash
gowa auth login \
  --url "$GOWA_SERVER_URL" \
  --username "$GOWA_USERNAME" \
  --password "$GOWA_PASSWORD"
```

Almacene credenciales en secrets de CI, nunca en codigo.

### --accept-risk en Entorno CI

```bash
# Opcion A: Variable de entorno (recomendado para CI)
export GOWA_RISK_ACCEPTED=true

# Opcion B: Persistir en archivo de config
mkdir -p ~/.config/gowa
echo "risk_accepted: true" >> ~/.config/gowa/config.yaml
```

### Configuracion de Timeout

Para conexiones lentas o entornos de alta latencia, configure el timeout HTTP:

```bash
# Variable de entorno
export GOWA_TIMEOUT=60s

# O flag por comando
gowa send text --to "$PHONE" "Hola" --accept-risk --timeout 60s
```

Formatos de duracion validos: `10s`, `1m`, `2m30s`. Predeterminado es `30s`.

### Control de Flujo Basado en Exit Code

```yaml
# Ejemplo GitHub Actions
- name: Notificar via WhatsApp
  run: |
    gowa send text --to "${{ secrets.NOTIFY_PHONE }}" \
      "Deploy ${{ github.sha }} a produccion completado" \
      --accept-risk --json
  continue-on-error: true

- name: Verificar resultado de notificacion
  if: failure()
  run: echo "Notificacion WhatsApp fallo — verificar servidor GOWA"
```

### Log de Auditoria para Compliance

Toda operacion de envio se registra en `~/.config/gowa/audit.log` como JSON delimitado por newline. En CI, archive como artefacto de build.

---

## 5. Seguridad Especifica de WhatsApp

### Use Numeros Desechables para Pruebas

**GOWA CLI usa una API no oficial de WhatsApp Web.** Su numero puede ser baneado temporal o permanentemente. Siempre:

- Use una tarjeta SIM dedicada para automatizacion (no su numero personal)
- Compre una tarjeta prepago especificamente para pruebas
- Considere la API oficial de WhatsApp Business para uso en produccion

### Respete los Rate Limits

Los rate limits integrados (3/min, 30/hr, 200/dia) existen para SU proteccion:

- Previenen que su numero sea marcado como spammer
- Los sistemas anti-spam de WhatsApp detectan rafagas rapidas de mensajes
- Un numero baneado pierde todo el historial de mensajes y contactos

### Monitoree el Log de Auditoria

```bash
# Ver operaciones de envio recientes
tail -20 ~/.config/gowa/audit.log | jq .

# Contar envios de hoy
HOY=$(date -u +%Y-%m-%d)
grep "$HOY" ~/.config/gowa/audit.log | wc -l

# Encontrar operaciones fallidas
grep '"result":"error"' ~/.config/gowa/audit.log | jq .
```

### Nunca Envie Masivamente a Numeros Desconocidos

- Solo envie a numeros que lo contactaron primero o hicieron opt-in
- Enviar a numeros desconocidos es la forma mas rapida de ser baneado
- WhatsApp monitorea tasas de bloqueo/denuncia por remitente

### Validacion de Imagenes y Archivos

El CLI valida archivos antes de enviar:

- **Imagenes:** solo `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp` permitidas
- **Archivos:** deben existir y ser archivos regulares (no directorios)

---

## 6. Patrones de Automatizacion

### Programacion de Mensajes via Cron

```bash
# crontab -e
# Reporte diario a las 9 AM (UTC)
0 9 * * * /usr/local/bin/gowa send text --to 5511999999999 "Buenos dias! Reporte diario listo." --accept-risk --quiet >> /var/log/gowa-cron.log 2>&1
```

### Notificaciones Orientadas a Eventos

```bash
#!/usr/bin/env bash
# hook-post-deploy.sh — Notifica despues de deploy exitoso
set -euo pipefail

ENTORNO="$1"
TELEFONO="$2"
COMMIT=$(git rev-parse --short HEAD)
BRANCH=$(git rev-parse --abbrev-ref HEAD)

gowa send text --to "$TELEFONO" \
  "Deploy a $ENTORNO completado. Branch: $BRANCH, Commit: $COMMIT" \
  --accept-risk --quiet >/dev/null 2>&1 || true
```

### Monitoreo de Chat y Respuesta

```bash
#!/usr/bin/env bash
# sondear-mensajes.sh — Sondea mensajes nuevos y ejecuta acciones
set -euo pipefail

JID="$1"
ARCHIVO_ULTIMO_CHECK="/tmp/gowa-ultimo-check"
ULTIMO_CHECK=$(cat "$ARCHIVO_ULTIMO_CHECK" 2>/dev/null || date -u -d "5 minutes ago" +%Y-%m-%dT%H:%M:%SZ)

MENSAJES=$(gowa chat messages "$JID" --json --since "$ULTIMO_CHECK" 2>/dev/null)
if [ $? -ne 0 ]; then exit 1; fi

date -u +%Y-%m-%dT%H:%M:%SZ > "$ARCHIVO_ULTIMO_CHECK"

echo "$MENSAJES" | jq -c '.[]' | while read -r msg; do
  TEXTO=$(echo "$msg" | jq -r '.text // ""')
  case "$TEXTO" in
    *"estado"*) gowa send text --to "$JID" "Todos los sistemas operativos." --accept-risk --quiet >/dev/null; sleep 25 ;;
    *"ayuda"*) gowa send text --to "$JID" "Comandos: estado, ayuda, reporte" --accept-risk --quiet >/dev/null; sleep 25 ;;
  esac
done
```

### Integracion con Webhooks

```bash
#!/usr/bin/env bash
# webhook-a-whatsapp.sh — Reenviar eventos de webhook a WhatsApp
set -euo pipefail

PAYLOAD=$(cat)
EVENTO=$(echo "$PAYLOAD" | jq -r '.event // "desconocido"')
ESTADO=$(echo "$PAYLOAD" | jq -r '.status // "desconocido"')

TELEFONO_NOTIFICACION="5511999999999"

echo "$PAYLOAD" | jq -r '"Webhook: \(.event) - Estado: \(.status)"' | \
  gowa send text --to "$TELEFONO_NOTIFICACION" --accept-risk --quiet >/dev/null
```

---

## 7. Anti-Patrones (Lo Que NO Hacer)

### NO Parsee Salida de Tabla

```bash
# MAL
gowa device list | grep "connected" | awk '{print $1}'

# BIEN
gowa device list --json | jq -r '.[] | select(.status == "connected") | .id'
```

### NO Bypass --accept-risk Programaticamente Sin Entender los Riesgos

Entienda que esta usando una API no oficial. Su numero puede ser baneado.

### NO Ignore Exit Code 6

```bash
# MAL
gowa send text --to "$PHONE" "msg" --accept-risk || true

# BIEN
gowa send text --to "$PHONE" "msg" --accept-risk --json
EC=$?
if [ $EC -eq 6 ]; then
  echo "Rate limited — programando reintento" >&2
fi
```

### NO Envie Sin Validacion de Telefono

```bash
# MAL
gowa send text --to "$USER_INPUT" "Hola" --accept-risk

# BIEN
if [[ "$USER_INPUT" =~ ^[0-9]{10,15}$ ]]; then
  gowa send text --to "$USER_INPUT" "Hola" --accept-risk --json
else
  echo "Numero de telefono invalido: $USER_INPUT" >&2
fi
```

### NO Envie Sin --dry-run Primero (Agentes)

```bash
# MAL — agente envia directamente sin validar
gowa send text --to "$PHONE" "Hola" --accept-risk --json

# BIEN — agente valida primero, luego envia
gowa send text --to "$PHONE" "Hola" --accept-risk --json --dry-run
if [ $? -eq 0 ]; then
  gowa send text --to "$PHONE" "Hola" --accept-risk --json
fi
```

Un dry-run captura numeros de telefono alucinados y archivos invalidos sin consumir un token de rate limit.

### NO Ejecute Multiples Instancias Simultaneamente

```bash
# MAL — envios en paralelo
xargs -P 4 -I {} gowa send text --to {} "Hola" --accept-risk < phones.txt

# BIEN — use --to-file para lote (delays integrados)
gowa send text --to-file phones.txt "Hola" --accept-risk --json

# O — secuencial con delay
while read -r telefono; do
  gowa send text --to "$telefono" "Hola" --accept-risk --json
  sleep 25
done < phones.txt
```

---

## 8. Guia de Solucion de Problemas

### Rate Limit Alcanzado (Exit Code 6)

**Sintoma:** `Rate limit exceeded: N messages sent in last minute/hour/day`

**Solucion:**
1. Espere la duracion indicada en el mensaje de error
2. Verifique archivo de estado: `cat ~/.config/gowa/state.json | jq .`
3. Si esta corrupto, resetee: `echo '{"messages_sent":[]}' > ~/.config/gowa/state.json`
4. Implemente backoff exponencial en sus scripts (ver Seccion 2)

### Fallo de Autenticacion (Exit Code 3)

**Solucion:**
1. Re-login: `gowa auth login --url http://localhost:3000 --username admin --password secret`
2. Verifique si servidor esta accesible: `curl -s http://localhost:3000/`
3. Revise config almacenado: `cat ~/.config/gowa/config.yaml`

### Archivo No Encontrado (Exit Code 2)

**Solucion:**
1. Valide que el path existe antes de llamar send: `[ -f "$ARCHIVO" ]`
2. Use paths absolutos, no relativos
3. Para imagenes, verifique extension permitida: `.jpg`, `.jpeg`, `.png`, `.gif`, `.webp`

### Error de Conexion (Exit Code 5)

**Solucion:**
1. Verifique estado del servidor GOWA: `curl -s http://localhost:3000/`
2. Inicie el servidor: `docker run -p 3000:3000 aldinokemal2104/go-whatsapp-web-multidevice`
3. Verifique URL en config: `gowa auth status --json | jq '.api_url'`

### Numero de Telefono Invalido (Exit Code 2)

**Solucion:**
1. Use formato E.164 sin signo `+`: `5511999999999` (codigo de pais + numero)
2. O use JID completo: `5511999999999@s.whatsapp.net`
3. Sin guiones, espacios o parentesis

### Timeout de Solicitud (Conexion Lenta)

**Sintoma:** El comando se cuelga o retorna error de timeout en redes lentas.

**Solucion:**
1. Aumente el timeout: `gowa send text --to "$PHONE" "Hola" --accept-risk --timeout 60s`
2. O defina globalmente: `export GOWA_TIMEOUT=60s`
3. Formatos validos: `10s`, `1m`, `2m30s`. Predeterminado es `30s`.

### Archivo de Estado Bloqueado

**Solucion:**
1. Remueva lock file obsoleto: `rm ~/.config/gowa/state.json.lock`
2. Asegure que ningun otro proceso gowa este corriendo
3. Evite correr multiples instancias en paralelo

---

*GOWA CLI Best Practices Guide v1.0 — Generated 2026-03-19*
