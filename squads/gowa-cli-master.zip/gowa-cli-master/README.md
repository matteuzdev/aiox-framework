# GOWA CLI

[![Go Version](https://img.shields.io/badge/Go-1.25+-00ADD8?style=flat&logo=go)](https://go.dev/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Release](https://img.shields.io/github/v/release/murilloimparavel/gowa-cli?style=flat)](https://github.com/murilloimparavel/gowa-cli/releases)

**WhatsApp CLI for AI agents and developers.** Send messages, query chats, search contacts — all from your terminal.

---

## What is GOWA CLI?

GOWA CLI (`gowa`) is a Go command-line tool for WhatsApp built on [whatsmeow](https://github.com/tulir/whatsmeow). It compiles to a **single binary with zero external dependencies** — no Docker, no servers, no runtime requirements.

- **Embedded WhatsApp connection** via whatsmeow (multi-device API)
- **Daemon mode** keeps WhatsApp connected in the background
- **Agent-friendly** — JSON output, semantic exit codes, structured errors on stderr
- **Safety-first** — rate limiter, circuit breaker, audit log, risk acknowledgment gate
- **Scriptable** — pipe messages via stdin, batch send via `--to-file`, use `--quiet` for subshells

## Quick Start

```bash
# Install
go install github.com/murilloimparavel/gowa-cli@latest

# Pair your WhatsApp account (one-time, interactive)
gowa pair

# Start the background daemon
gowa daemon start

# Send a message
gowa send text --to 5511999999999 "Hello from GOWA!" --accept-risk

# List your chats
gowa chat list --json

# Search contacts
gowa contact search "João" --json
```

## Commands

### Pairing & Session

| Command | Description |
|---------|-------------|
| `gowa pair [--phone NUMBER]` | Link WhatsApp via QR code or phone number |
| `gowa pair --qr-file qr.png` | Save QR code as PNG for remote pairing |
| `gowa pair --force` | Re-pair even if already linked |
| `gowa logout [--purge]` | Unlink WhatsApp and clean up session |

### Daemon

| Command | Description |
|---------|-------------|
| `gowa daemon start [--foreground]` | Start background daemon |
| `gowa daemon stop` | Gracefully stop daemon |
| `gowa daemon status` | Show connection state, uptime, circuit breaker |
| `gowa daemon logs` | Show daemon log output |

### Messaging

| Command | Description |
|---------|-------------|
| `gowa send text --to JID "message"` | Send text message |
| `gowa send image --to JID --file photo.jpg` | Send image with optional `--caption` |
| `gowa send file --to JID --file doc.pdf` | Send document |
| `gowa send text --to-file contacts.txt "msg"` | Batch send (one JID per line) |
| `gowa send text --dry-run --to JID "msg"` | Validate without sending |

### Chats & Contacts

| Command | Description |
|---------|-------------|
| `gowa chat list [--limit N]` | List recent conversations |
| `gowa chat messages JID [--limit N]` | Message history with `--since`/`--until`/`--search` |
| `gowa chat unread` | List chats with unread messages |
| `gowa chat read JID` | Mark chat as read |
| `gowa chat search "query"` | Full-text search across all messages |
| `gowa contact list [--limit N]` | List WhatsApp contacts |
| `gowa contact search "name"` | Search contacts by name or phone |

### Group Management

| Command | Description |
|---------|-------------|
| `gowa group list [--name FILTER]` | List joined groups |
| `gowa group info JID [--members] [--role ROLE]` | Group details and member list |
| `gowa group create NAME [--members PHONES]` | Create a new group |
| `gowa group leave JID` | Leave a group (irreversible) |
| `gowa group invite-link JID [--reset]` | Get or reset group invite link |
| `gowa group join LINK` | Join a group via invite link or code |

```bash
# List your groups
gowa group list
gowa group list --name "dev" --json

# Group details and members
gowa group info 120363012345678901@g.us
gowa group info 120363012345678901@g.us --members --role admin

# Create a group
gowa group create "Project Team" --members 5511999999999,5511888888888 --accept-risk

# Join via invite link
gowa group join https://chat.whatsapp.com/AbCdEfGhIjKl --accept-risk

# Send to a group (uses existing send command with group JID)
gowa send text --to 120363012345678901@g.us "Hello group!" --accept-risk
```

> **Note:** There is no separate `group send` command. To send messages to a group, use `gowa send text --to <group-jid>` with any `@g.us` JID.

### Other

| Command | Description |
|---------|-------------|
| `gowa device status` | Show device connection info |
| `gowa version` | Print version info |
| `gowa completion bash\|zsh\|fish\|powershell` | Generate shell completions |

### Global Flags

| Flag | Description |
|------|-------------|
| `--json` | Output in JSON format (machine-readable) |
| `--quiet` | Minimal output (bare values for scripting) |
| `--no-color` | Disable colored output |
| `--timeout DURATION` | Request timeout (default: `30s`) |

### Send Flags

| Flag | Description |
|------|-------------|
| `--to JID` | Recipient (phone number, `@s.whatsapp.net`, `@lid`, or `@g.us` JID) |
| `--to-file PATH` | Batch: one recipient per line, randomized delays |
| `--accept-risk` | Acknowledge unofficial API risk (required for send) |
| `--dry-run` | Validate inputs without sending |

## Architecture

```
┌──────────────────────────────────────────────────┐
│                  CLI Process                      │
│  gowa send/chat/contact/* → DaemonClient          │
│      ↓ Unix Socket (JSON-RPC 2.0, token auth)    │
├──────────────────────────────────────────────────┤
│                 Daemon Process                    │
│  WhatsApp ← whatsmeow (WebSocket, E2E encrypted) │
│  Messages → SQLite msgstore (WAL, FTS5 search)   │
│  Safety → rate limiter, circuit breaker, audit    │
└──────────────────────────────────────────────────┘
```

**How it works:**
1. `gowa pair` — one-time WhatsApp linking (QR or phone code)
2. `gowa daemon start` — background process holds the WhatsApp connection open
3. All other commands are short-lived clients that talk to the daemon via Unix socket
4. Incoming messages are automatically saved to a local SQLite database
5. The daemon handles reconnection, circuit breaking, and graceful shutdown

## Agent Integration

GOWA CLI is designed for AI agents (Claude Code, Cursor, Codex, etc.):

```bash
# Agent workflow
gowa daemon start                                          # ensure connected
gowa chat list --json                                      # discover conversations
gowa contact search "client name" --json                   # find a contact
gowa send text --to JID "Your report is ready" --json --accept-risk  # send message
gowa chat messages JID --since 2024-01-15T00:00:00Z --json # check replies
```

### Why it works for agents

- **`--json`** on every command → structured output on stdout
- **Structured errors** on stderr as JSON when `--json` is active
- **Semantic exit codes** (0=success, 2=bad input, 3=not found, 4=permission error, 5=connection error, 6=rate limited, 7=session expired)
- **`--quiet`** outputs bare values for `$(gowa ...)` subshell usage
- **`--dry-run`** validates commands without side effects
- **`gowa.tools.json`** — machine-readable manifest of all commands for agent discovery

## Safety

Multiple layers protect your WhatsApp account from bans:

| Protection | Details |
|-----------|---------|
| **Rate limiter** | 3/minute, 30/hour, 200/day — atomic check+record under file lock |
| **Circuit breaker** | 5 failures in 30min → blocks reconnection for 30min cooldown |
| **Risk gate** | `--accept-risk` required for send (or `GOWA_RISK_ACCEPTED=true`) |
| **Typing indicator** | Simulates composing before text messages (anti-ban) |
| **Batch delay** | Randomized 1-5s delay between batch recipients |
| **Dry run** | `--dry-run` validates everything without sending |
| **Input validation** | Phone numbers (E.164), file paths, extensions, dates |
| **Audit log** | Every send logged in JSONL with file locking and rotation |
| **Fail-safe** | Rate limit state recorded BEFORE send, not after |
| **Graceful shutdown** | Session flushed on SIGTERM, daemon drains active RPCs |

## Configuration

```yaml
# ~/.config/gowa/config.yaml
device_id: ""           # Default device JID
output: table           # Default format (table | json | quiet)
risk_accepted: false    # Skip --accept-risk on send commands
timeout: 30s            # Request timeout
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `GOWA_DEVICE_ID` | Default device JID |
| `GOWA_OUTPUT` | Default output format |
| `GOWA_RISK_ACCEPTED` | Accept risk globally (`true` for CI/CD) |
| `GOWA_TIMEOUT` | Request timeout |

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error, daemon not running |
| 2 | Bad input, usage error |
| 3 | Not found (group does not exist) |
| 4 | Permission error (not admin) |
| 5 | Connection error, WhatsApp error |
| 6 | Rate limited |
| 7 | Session expired (re-pair required) |

## Files

```
~/.config/gowa/
├── config.yaml      # User configuration
├── session.db       # WhatsApp session (encrypted, whatsmeow)
├── messages.db      # Message/chat/contact store (SQLite WAL + FTS5)
├── state.json       # Rate limiter state (file-locked)
├── audit.log        # Send operation log (JSONL, 1MB rotation)
├── daemon.pid       # Daemon PID
├── daemon.log       # Daemon structured logs (JSON, 5MB rotation)
├── daemon.lock      # Single-instance lock
├── daemon.token     # RPC auth token (random, 0600)
└── gowa.sock        # Unix domain socket (JSON-RPC 2.0)
```

## Building from Source

```bash
git clone https://github.com/murilloimparavel/gowa-cli
cd gowa-cli
go build -o gowa .
```

### Run tests

```bash
go test ./...
go vet ./...

# E2E tests (requires paired WhatsApp)
bash tests/e2e-test.sh [PHONE_NUMBER]
```

## Requirements

- **Go 1.25+** (required by whatsmeow)
- **WhatsApp account** with multi-device support
- **Interactive terminal** for initial pairing (QR code display)

## License

[MIT](LICENSE) — Murillo Alves
