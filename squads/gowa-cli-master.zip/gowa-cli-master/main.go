package main

import (
	"os"

	"github.com/murilloimparavel/gowa-cli/cmd"
)

// These variables are set via ldflags at build time.
var (
	version = "dev"
	commit  = "none"
	date    = "unknown"
)

func main() {
	cmd.SetVersion(version, commit, date)
	os.Exit(cmd.Execute())
}
