package cmd

import (
	"encoding/json"
	"fmt"
	"regexp"

	"github.com/spf13/cobra"
	"github.com/murilloimparavel/gowa-cli/internal/clierr"
)

var deviceIDPattern = regexp.MustCompile(`^\d+@s\.whatsapp\.net$`)

var deviceCmd = &cobra.Command{
	Use:   "device",
	Short: "Manage WhatsApp device",
	Long: `Check your WhatsApp device connection status and set the default device ID.

Requires the daemon to be running (gowa daemon start). Use 'gowa pair' first
to link your WhatsApp account if you haven't already.`,
}

var deviceStatusCmd = &cobra.Command{
	Use:   "status",
	Short: "Check device connection status",
	Example: `  gowa device status
  gowa device status --json`,
	RunE: func(cmd *cobra.Command, args []string) error {
		resp, err := runCtx.DaemonClient.Call("device.status", nil)
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to get device status: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		// Parse and format the result
		data, _ := json.Marshal(resp.Result)
		var status map[string]interface{}
		if err := json.Unmarshal(data, &status); err != nil {
			return fmt.Errorf("parsing device status: %w", err)
		}

		return runCtx.Formatter.FormatSingle(status)
	},
}

var deviceUseCmd = &cobra.Command{
	Use:   "use <device-id>",
	Short: "Set default device for all commands",
	Example: `  gowa device use 628xxx@s.whatsapp.net`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		deviceID := args[0]

		if !deviceIDPattern.MatchString(deviceID) {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("Invalid device ID format: %s", deviceID),
				Recovery: "Use format: <digits>@s.whatsapp.net (e.g., 628xxx@s.whatsapp.net)",
			}
		}

		runCtx.Config.Set("device_id", deviceID)
		if err := runCtx.Config.Save(); err != nil {
			return fmt.Errorf("saving config: %w", err)
		}

		return runCtx.Formatter.FormatSingle(map[string]string{
			"device_id": deviceID,
			"status":    "default_set",
		})
	},
}

func init() {
	deviceCmd.AddCommand(deviceStatusCmd)
	deviceCmd.AddCommand(deviceUseCmd)
	rootCmd.AddCommand(deviceCmd)
}
