package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/mdp/qrterminal/v3"
	qrcode "github.com/skip2/go-qrcode"
	"github.com/spf13/cobra"
	waLog "go.mau.fi/whatsmeow/util/log"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/daemon"
	"github.com/murilloimparavel/gowa-cli/internal/whatsapp"
)

var pairCmd = &cobra.Command{
	Use:   "pair",
	Short: "Pair WhatsApp account via QR code or phone number",
	Long: `Pair your WhatsApp account with the CLI. Uses QR code by default.

This command must be run in an interactive terminal (not via scripts or agents).
The QR code is displayed directly in the terminal for you to scan.

For AI agents / Claude Code: instruct the user to run this command in a
separate terminal, then use 'gowa daemon start' and 'gowa send' normally.

Examples:
  gowa pair                           # Scan QR code in terminal
  gowa pair --phone +5511999999999    # Use phone number pairing code
  gowa pair --qr-file /tmp/qr.png     # Also save QR as PNG file
  gowa pair --force                   # Re-pair even if already paired

Agent integration:
  # Step 1: User runs in their terminal
  gowa pair

  # Step 2: After paired, agent can use normally
  gowa daemon start
  gowa send text --to 5511999999999 "Hello" --accept-risk --json`,
	RunE: runPair,
}

func init() {
	pairCmd.Flags().String("phone", "", "Pair via phone number (e.g., +5511999999999)")
	pairCmd.Flags().String("qr-file", "", "Save QR code as PNG to this path")
	pairCmd.Flags().Bool("force", false, "Force re-pair even if already paired")
	rootCmd.AddCommand(pairCmd)
}

func runPair(cmd *cobra.Command, args []string) error {
	phone, _ := cmd.Flags().GetString("phone")
	qrFile, _ := cmd.Flags().GetString("qr-file")
	force, _ := cmd.Flags().GetBool("force")
	jsonMode, _ := cmd.Flags().GetBool("json")

	// Warn if daemon is running with old session
	if daemonPaths, pathErr := daemon.NewPaths(); pathErr == nil {
		if running, _ := daemon.IsRunning(daemonPaths.PID); running {
			fmt.Fprintln(os.Stderr, "Warning: daemon is running with old session. Restart it after pairing: gowa daemon stop && gowa daemon start")
		}
	}

	// Determine session DB path
	homeDir, err := os.UserHomeDir()
	if err != nil {
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  "Cannot determine home directory",
			Original: err,
		}
	}
	sessionDB := filepath.Join(homeDir, ".config", "gowa", "session.db")

	// Create whatsmeow client
	var logLevel string
	if jsonMode {
		logLevel = "ERROR" // suppress logs in JSON mode
	} else {
		logLevel = "WARN"
	}
	waClient, err := whatsapp.NewWaClient(cmd.Context(), sessionDB, waLog.Stdout("GOWA", logLevel, true))
	if err != nil {
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  fmt.Sprintf("Failed to create WhatsApp client: %s", err),
			Recovery: "Check session DB permissions at ~/.config/gowa/session.db",
			Original: err,
		}
	}
	defer waClient.Close()

	// Check if already paired
	if !waClient.NeedsPairing() && !force {
		jid := waClient.UnderlyingClient().Store.ID.String()
		if jsonMode {
			emitJSON(os.Stdout, map[string]any{
				"event": "already_paired",
				"jid":   jid,
			})
		} else {
			fmt.Fprintf(os.Stderr, "Already paired as %s\nUse --force to re-pair with a different account.\n", jid)
		}
		return nil
	}

	// Force re-pair: logout first
	if !waClient.NeedsPairing() && force {
		waClient.Logout(context.Background())
		waClient.Close()

		// Re-create client after logout
		// L-14: No additional defer needed — the original defer waClient.Close()
		// operates on the reassigned waClient variable (closure semantics).
		waClient, err = whatsapp.NewWaClient(cmd.Context(), sessionDB, waLog.Stdout("GOWA", logLevel, true))
		if err != nil {
			return &clierr.CLIError{
				Type:     "general",
				Code:     1,
				Message:  fmt.Sprintf("Failed to re-create WhatsApp client after logout: %s", err),
				Recovery: "Try again with 'gowa pair --force'",
				Original: err,
			}
		}
	}

	if phone != "" {
		return pairWithPhone(cmd.Context(), waClient, phone, jsonMode)
	}
	return pairWithQR(cmd.Context(), waClient, qrFile, jsonMode)
}

func pairWithQR(ctx context.Context, waClient *whatsapp.WaClient, qrFile string, jsonMode bool) error {
	qrChan, err := waClient.GetQRChannel(ctx)
	if err != nil {
		return err
	}

	// Connect AFTER GetQRChannel
	if err := waClient.UnderlyingClient().Connect(); err != nil {
		return &clierr.CLIError{
			Type:     "whatsapp_error",
			Code:     5,
			Message:  fmt.Sprintf("Failed to connect: %s", err),
			Recovery: "Check your internet connection",
			Original: err,
		}
	}

	if !jsonMode {
		fmt.Fprintln(os.Stderr, "Scan this QR code with WhatsApp:")
		fmt.Fprintln(os.Stderr, "  WhatsApp > Settings > Linked Devices > Link a Device")
		fmt.Fprintln(os.Stderr)
	}

	attempt := 0
	maxAttempts := 8

	for evt := range qrChan {
		switch evt.Event {
		case "code":
			attempt++

			if jsonMode {
				emitJSON(os.Stdout, map[string]any{
					"event":        "qr",
					"code":         evt.Code,
					"attempt":      attempt,
					"max_attempts": maxAttempts,
				})
			} else {
				qrterminal.GenerateHalfBlock(evt.Code, qrterminal.M, os.Stderr)
				fmt.Fprintf(os.Stderr, "\n  QR refreshes automatically... (%d/%d)\n\n", attempt, maxAttempts)
			}

			// Write QR as PNG if requested
			if qrFile != "" {
				if err := qrcode.WriteFile(evt.Code, qrcode.Medium, 256, qrFile); err != nil {
					fmt.Fprintf(os.Stderr, "Warning: failed to write QR PNG: %s\n", err)
				}
			}

		case "success":
			jid := waClient.UnderlyingClient().Store.ID.String()
			if jsonMode {
				emitJSON(os.Stdout, map[string]any{
					"event": "paired",
					"jid":   jid,
				})
			} else {
				fmt.Fprintln(os.Stderr, "Paired successfully!")
				fmt.Fprintf(os.Stderr, "  JID: %s\n", jid)
				homeDir, _ := os.UserHomeDir()
				fmt.Fprintf(os.Stderr, "  Session saved to: %s\n", filepath.Join(homeDir, ".config", "gowa", "session.db"))
			}
			return nil

		case "timeout":
			return &clierr.CLIError{
				Type:     "general",
				Code:     1,
				Message:  "QR pairing timed out after ~160 seconds",
				Recovery: "Try again with 'gowa pair' or use '--phone' for phone pairing",
			}

		default:
			// Error events
			if evt.Error != nil {
				return &clierr.CLIError{
					Type:     "whatsapp_error",
					Code:     5,
					Message:  fmt.Sprintf("Pairing error: %s", evt.Event),
					Recovery: "Try again or check WhatsApp status",
					Original: evt.Error,
				}
			}
		}
	}

	return &clierr.CLIError{
		Type:     "general",
		Code:     1,
		Message:  "QR channel closed unexpectedly",
		Recovery: "Try again with 'gowa pair'",
	}
}

func pairWithPhone(ctx context.Context, waClient *whatsapp.WaClient, phone string, jsonMode bool) error {
	// Clean phone number
	phone = strings.TrimPrefix(phone, "+")
	phone = strings.ReplaceAll(phone, " ", "")
	phone = strings.ReplaceAll(phone, "-", "")

	// Need to connect first for phone pairing
	qrChan, err := waClient.GetQRChannel(ctx)
	if err != nil {
		return err
	}

	if err := waClient.UnderlyingClient().Connect(); err != nil {
		return &clierr.CLIError{
			Type:     "whatsapp_error",
			Code:     5,
			Message:  fmt.Sprintf("Failed to connect: %s", err),
			Recovery: "Check your internet connection",
			Original: err,
		}
	}

	// Wait for first QR event before calling PairPhone
	select {
	case <-qrChan:
		// First QR event received, now we can pair via phone
	case <-ctx.Done():
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  "Pairing cancelled",
			Recovery: "Try again with 'gowa pair --phone " + phone + "'",
			Original: ctx.Err(),
		}
	}

	code, err := waClient.PairPhone(ctx, phone)
	if err != nil {
		return &clierr.CLIError{
			Type:     "whatsapp_error",
			Code:     5,
			Message:  fmt.Sprintf("Phone pairing failed: %s", err),
			Recovery: "Check the phone number format and try again",
			Original: err,
		}
	}

	if jsonMode {
		emitJSON(os.Stdout, map[string]any{
			"event": "code",
			"code":  code,
			"phone": phone,
		})
	} else {
		fmt.Fprintln(os.Stderr, "Link using this code:")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintf(os.Stderr, "  %s\n", code)
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "  On your phone: WhatsApp > Linked Devices > Link with phone number")
		fmt.Fprintln(os.Stderr, "  Enter the code above when prompted.")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "  Waiting for pairing... (timeout: 120s)")
	}

	// Wait for pairing confirmation
	timeout := time.NewTimer(120 * time.Second)
	defer timeout.Stop()

	for {
		select {
		case evt, ok := <-qrChan:
			if !ok {
				// Channel closed — check if we're paired
				if !waClient.NeedsPairing() {
					jid := waClient.UnderlyingClient().Store.ID.String()
					if jsonMode {
						emitJSON(os.Stdout, map[string]any{
							"event": "paired",
							"jid":   jid,
						})
					} else {
						fmt.Fprintln(os.Stderr, "Paired successfully!")
						fmt.Fprintf(os.Stderr, "  JID: %s\n", jid)
					}
					return nil
				}
				return &clierr.CLIError{
					Type:     "general",
					Code:     1,
					Message:  "Pairing channel closed without confirmation",
					Recovery: "Try again with 'gowa pair --phone " + phone + "'",
				}
			}

			if evt.Event == "success" {
				jid := waClient.UnderlyingClient().Store.ID.String()
				if jsonMode {
					emitJSON(os.Stdout, map[string]any{
						"event": "paired",
						"jid":   jid,
					})
				} else {
					fmt.Fprintln(os.Stderr, "Paired successfully!")
					fmt.Fprintf(os.Stderr, "  JID: %s\n", jid)
				}
				return nil
			}

		case <-timeout.C:
			return &clierr.CLIError{
				Type:     "general",
				Code:     1,
				Message:  "Phone pairing timed out after 120 seconds",
				Recovery: "Try again with 'gowa pair --phone " + phone + "'",
			}

		case <-ctx.Done():
			return ctx.Err()
		}
	}
}

func emitJSON(w *os.File, data map[string]any) {
	_ = json.NewEncoder(w).Encode(data)
}
