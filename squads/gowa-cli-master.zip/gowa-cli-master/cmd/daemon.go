package cmd

import (
	"bufio"
	"fmt"
	"os"
	"time"

	"github.com/spf13/cobra"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/daemon"
)

func wrapNewPathsError(err error) *clierr.CLIError {
	return &clierr.CLIError{
		Type:     "daemon_error",
		Code:     1,
		Message:  fmt.Sprintf("Failed to resolve daemon paths: %s", err),
		Recovery: "Check permissions of ~/.config/gowa directory",
		Original: err,
	}
}

var daemonCmd = &cobra.Command{
	Use:   "daemon",
	Short: "Manage the WhatsApp background daemon",
	Long: `Manage the background daemon that maintains the WhatsApp connection.

The daemon keeps the connection alive so that commands are instant
and messages are received continuously.`,
}

var daemonStartCmd = &cobra.Command{
	Use:   "start",
	Short: "Start the daemon",
	RunE:  runDaemonStart,
}

var daemonStopCmd = &cobra.Command{
	Use:   "stop",
	Short: "Stop the daemon",
	RunE:  runDaemonStop,
}

var daemonStatusCmd = &cobra.Command{
	Use:   "status",
	Short: "Show daemon status",
	RunE:  runDaemonStatus,
}

var daemonLogsCmd = &cobra.Command{
	Use:   "logs",
	Short: "Show daemon log output",
	RunE:  runDaemonLogs,
}

func init() {
	daemonStartCmd.Flags().Bool("foreground", false, "Run in foreground (for debugging)")
	daemonStartCmd.Flags().String("idle-timeout", "0", "Idle timeout before auto-shutdown (0 to disable, e.g. 30m, 1h)")

	rootCmd.AddCommand(daemonCmd)
	daemonCmd.AddCommand(daemonStartCmd)
	daemonCmd.AddCommand(daemonStopCmd)
	daemonCmd.AddCommand(daemonStatusCmd)
	daemonCmd.AddCommand(daemonLogsCmd)
}

func runDaemonStart(cmd *cobra.Command, args []string) error {
	paths, err := daemon.NewPaths()
	if err != nil {
		return wrapNewPathsError(err)
	}

	// Pre-check: session must exist before spawning daemon
	if _, statErr := os.Stat(paths.SessionDB); os.IsNotExist(statErr) {
		return &clierr.CLIError{
			Type:     "auth_error",
			Code:     7,
			Message:  "No WhatsApp session found",
			Recovery: "Run 'gowa pair' first to link your WhatsApp account",
		}
	}

	foreground, _ := cmd.Flags().GetBool("foreground")
	idleStr, _ := cmd.Flags().GetString("idle-timeout")

	idleTimeout, err := time.ParseDuration(idleStr)
	if err != nil {
		return &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  fmt.Sprintf("Invalid idle-timeout: %s", idleStr),
			Recovery: "Use Go duration format: 30m, 1h, 0 (disable)",
		}
	}

	if foreground {
		return daemon.RunForeground(paths, idleTimeout)
	}

	jsonMode, _ := cmd.Flags().GetBool("json")

	pid, err := daemon.Start(paths, idleTimeout)
	if err != nil {
		// If already running, it's not an error — just inform
		if pid > 0 {
			if jsonMode {
				return runCtx.Formatter.FormatSingle(map[string]interface{}{
					"status": "already_running",
					"pid":    pid,
				})
			}
			fmt.Fprintf(os.Stderr, "Daemon already running (PID: %d)\n", pid)
			return nil
		}
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  err.Error(),
			Recovery: "Check 'gowa daemon logs' for details",
		}
	}

	if jsonMode {
		return runCtx.Formatter.FormatSingle(map[string]interface{}{
			"status": "started",
			"pid":    pid,
		})
	}
	fmt.Fprintf(os.Stderr, "Daemon started (PID: %d)\n", pid)
	return nil
}

func runDaemonStop(cmd *cobra.Command, args []string) error {
	paths, err := daemon.NewPaths()
	if err != nil {
		return wrapNewPathsError(err)
	}

	if err := daemon.Stop(paths); err != nil {
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  err.Error(),
			Recovery: "The daemon may not be running",
		}
	}

	jsonMode, _ := cmd.Flags().GetBool("json")
	if jsonMode {
		return runCtx.Formatter.FormatSingle(map[string]interface{}{
			"status": "stopped",
		})
	}
	fmt.Fprintln(os.Stderr, "Daemon stopped")
	return nil
}

func runDaemonStatus(cmd *cobra.Command, args []string) error {
	paths, err := daemon.NewPaths()
	if err != nil {
		return wrapNewPathsError(err)
	}

	running, pid := daemon.IsRunning(paths.PID)
	jsonMode, _ := cmd.Flags().GetBool("json")

	if !running {
		if jsonMode {
			return runCtx.Formatter.FormatSingle(map[string]interface{}{
				"running": false,
				"mode":    "stopped",
				"hint":    "Start with 'gowa daemon start'",
			})
		} else {
			fmt.Fprintln(os.Stderr, "Daemon is not running")
			fmt.Fprintln(os.Stderr, "  Start with 'gowa daemon start'")
		}
		return nil
	}

	// Try to get detailed status from daemon
	dc, err := daemon.NewClient(paths.Socket, paths.Token)
	if err != nil {
		// Can't connect to socket but process is running
		if jsonMode {
			return runCtx.Formatter.FormatSingle(map[string]interface{}{
				"running": true,
				"pid":     pid,
				"mode":    "daemon",
			})
		} else {
			fmt.Fprintf(os.Stderr, "Daemon running (PID: %d) but socket unavailable\n", pid)
		}
		return nil
	}

	resp, err := dc.Call("daemon.status", nil)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Daemon running (PID: %d) — status unavailable: %s\n", pid, err)
		return nil
	}

	if resp.Error != nil {
		fmt.Fprintf(os.Stderr, "Daemon running (PID: %d) — status error: %s\n", pid, resp.Error.Message)
		return nil
	}

	if jsonMode {
		return runCtx.Formatter.FormatSingle(resp.Result)
	} else {
		// Pretty print status
		if status, ok := resp.Result.(map[string]interface{}); ok {
			fmt.Fprintf(os.Stderr, "Daemon running (PID: %d)\n", pid)
			if connStatus, ok := status["connection_status"].(string); ok {
				fmt.Fprintf(os.Stderr, "  Connection: %s\n", connStatus)
			} else if connected, ok := status["whatsapp_connected"].(bool); ok {
				if connected {
					fmt.Fprintln(os.Stderr, "  WhatsApp: connected")
				} else {
					fmt.Fprintln(os.Stderr, "  WhatsApp: disconnected")
				}
			}
			if uptime, ok := status["uptime_seconds"].(float64); ok {
				fmt.Fprintf(os.Stderr, "  Uptime: %s\n", (time.Duration(uptime) * time.Second).String())
			}
			if cbState, ok := status["cb_state"].(string); ok && cbState != "closed" {
				fmt.Fprintf(os.Stderr, "  Circuit Breaker: %s", cbState)
				if failures, ok := status["cb_failures"].(float64); ok {
					fmt.Fprintf(os.Stderr, " (%d failures)", int(failures))
				}
				fmt.Fprintln(os.Stderr)
			}
		}
	}

	return nil
}

func runDaemonLogs(cmd *cobra.Command, args []string) error {
	paths, err := daemon.NewPaths()
	if err != nil {
		return wrapNewPathsError(err)
	}

	f, err := os.Open(paths.Log)
	if err != nil {
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  "No daemon log file found",
			Recovery: "Start the daemon first with 'gowa daemon start'",
		}
	}
	defer f.Close()

	// Read last 50 lines
	lines := readLastLines(f, 50)

	jsonMode, _ := cmd.Flags().GetBool("json")
	if jsonMode {
		return runCtx.Formatter.FormatSingle(map[string]interface{}{
			"lines": lines,
			"count": len(lines),
		})
	}
	for _, line := range lines {
		fmt.Fprintln(os.Stderr, line)
	}

	return nil
}

func readLastLines(f *os.File, n int) []string {
	scanner := bufio.NewScanner(f)
	var lines []string
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}

	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}

	// Handle empty file
	if len(lines) == 0 {
		return []string{}
	}

	return lines
}
