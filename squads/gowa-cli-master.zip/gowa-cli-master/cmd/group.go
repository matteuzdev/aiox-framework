package cmd

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/spf13/cobra"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/output"
	"github.com/murilloimparavel/gowa-cli/internal/safety"
)

var groupCmd = &cobra.Command{
	Use:   "group",
	Short: "Manage WhatsApp groups",
	Long: `Manage WhatsApp groups: list joined groups, view group details, and more.

Requires the daemon to be running (gowa daemon start).`,
}

var groupListCmd = &cobra.Command{
	Use:   "list",
	Short: "List joined groups",
	Example: `  gowa group list
  gowa group list --name "dev" --json
  gowa group list --limit 10`,
	RunE: func(cmd *cobra.Command, args []string) error {
		nameFilter, _ := cmd.Flags().GetString("name")
		limit, _ := cmd.Flags().GetInt("limit")

		resp, err := runCtx.DaemonClient.Call("group.list", nil)
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to list groups: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var groups []map[string]interface{}
		if err := json.Unmarshal(data, &groups); err != nil {
			return fmt.Errorf("parsing group list: %w", err)
		}

		// Client-side name filter (case-insensitive substring)
		if nameFilter != "" {
			lowerFilter := strings.ToLower(nameFilter)
			var filtered []map[string]interface{}
			for _, g := range groups {
				name, _ := g["name"].(string)
				if strings.Contains(strings.ToLower(name), lowerFilter) {
					filtered = append(filtered, g)
				}
			}
			groups = filtered
		}

		// Apply limit consistently for both JSON and table output so that
		// --limit behaves the same regardless of output format.
		if limit > 0 && len(groups) > limit {
			groups = groups[:limit]
		}

		return runCtx.Formatter.Format(groups, []output.Column{
			{Name: "JID", Field: "jid"},
			{Name: "NAME", Field: "name"},
			{Name: "MEMBERS", Field: "participant_count"},
			{Name: "LAST_ACTIVITY", Field: "last_activity"},
		})
	},
}

var groupCreateCmd = &cobra.Command{
	Use:   "create <name>",
	Short: "Create a new WhatsApp group",
	Example: `  gowa group create "Project Team" --accept-risk
  gowa group create "Dev Chat" --members 5511999999999,5511888888888 --accept-risk
  gowa group create "Test Group" --dry-run --accept-risk`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		if err := checkAcceptRisk(cmd); err != nil {
			return err
		}

		name := args[0]
		membersStr, _ := cmd.Flags().GetString("members")
		dryRun, _ := cmd.Flags().GetBool("dry-run")

		if err := safety.ValidateGroupName(name); err != nil {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("Invalid group name: %s", err),
				Recovery: "Group names must be 1-25 characters",
			}
		}

		var phones []string
		if membersStr != "" {
			phones = strings.Split(membersStr, ",")
			for i, phone := range phones {
				phone = strings.TrimSpace(phone)
				phones[i] = phone
				if err := safety.ValidatePhone(phone); err != nil {
					return &clierr.CLIError{
						Type:     "usage_error",
						Code:     2,
						Message:  fmt.Sprintf("Invalid phone number #%d: %s", i+1, err),
						Recovery: "Use E.164 format without '+': e.g., 5511999999999",
					}
				}
			}
		}

		if dryRun {
			return runCtx.Formatter.FormatSingle(map[string]interface{}{
				"dry_run":      true,
				"command":      "group create",
				"name":         name,
				"members":      phones,
				"would_create": true,
			})
		}

		resp, err := runCtx.DaemonClient.Call("group.create", map[string]interface{}{
			"name":         name,
			"participants": phones,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to create group: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var detail map[string]interface{}
		if err := json.Unmarshal(data, &detail); err != nil {
			return &clierr.CLIError{
				Type:     "general",
				Code:     1,
				Message:  fmt.Sprintf("Failed to parse create response: %s", err),
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		return runCtx.Formatter.FormatSingle(detail)
	},
}

var groupLeaveCmd = &cobra.Command{
	Use:   "leave <jid>",
	Short: "Leave a WhatsApp group",
	Example: `  gowa group leave 120363012345678901@g.us --accept-risk
  gowa group leave 120363012345678901@g.us --dry-run --accept-risk`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		if err := checkAcceptRisk(cmd); err != nil {
			return err
		}

		jid := args[0]
		dryRun, _ := cmd.Flags().GetBool("dry-run")

		if err := safety.ValidateGroupJID(jid); err != nil {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("Invalid group JID: %s", err),
				Recovery: "Group JIDs end with @g.us, e.g. 120363012345678901@g.us",
			}
		}

		if dryRun {
			return runCtx.Formatter.FormatSingle(map[string]interface{}{
				"dry_run":     true,
				"command":     "group leave",
				"jid":         jid,
				"would_leave": true,
			})
		}

		resp, err := runCtx.DaemonClient.Call("group.leave", map[string]string{"jid": jid})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to leave group: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		return runCtx.Formatter.FormatSingle(map[string]interface{}{
			"status": "left",
			"jid":    jid,
		})
	},
}

var groupInviteLinkCmd = &cobra.Command{
	Use:   "invite-link <jid>",
	Short: "Get the group invite link",
	Example: `  gowa group invite-link 120363012345678901@g.us
  gowa group invite-link 120363012345678901@g.us --reset --accept-risk
  gowa group invite-link 120363012345678901@g.us --quiet`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		jid := args[0]
		reset, _ := cmd.Flags().GetBool("reset")

		if reset {
			if err := checkAcceptRisk(cmd); err != nil {
				return err
			}
		}

		if err := safety.ValidateGroupJID(jid); err != nil {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("Invalid group JID: %s", err),
				Recovery: "Group JIDs end with @g.us, e.g. 120363012345678901@g.us",
			}
		}

		resp, err := runCtx.DaemonClient.Call("group.inviteLink", map[string]interface{}{
			"jid":   jid,
			"reset": reset,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to get invite link: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var result map[string]interface{}
		if err := json.Unmarshal(data, &result); err != nil {
			return &clierr.CLIError{
				Type:     "general",
				Code:     1,
				Message:  fmt.Sprintf("Failed to parse invite link response: %s", err),
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		return runCtx.Formatter.FormatSingle(result)
	},
}

var groupJoinCmd = &cobra.Command{
	Use:   "join <link-or-code>",
	Short: "Join a group via invite link or code",
	Example: `  gowa group join https://chat.whatsapp.com/AbCdEfGhIjKl --accept-risk
  gowa group join AbCdEfGhIjKl --accept-risk
  gowa group join https://chat.whatsapp.com/AbCdEfGhIjKl --dry-run --accept-risk`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		if err := checkAcceptRisk(cmd); err != nil {
			return err
		}

		input := args[0]
		code, err := safety.ParseInviteCode(input)
		if err != nil {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("Invalid invite link or code: %v", err),
				Recovery: "Provide a WhatsApp invite URL (https://chat.whatsapp.com/...) or a 10-30 character alphanumeric invite code",
			}
		}
		dryRun, _ := cmd.Flags().GetBool("dry-run")

		if dryRun {
			// Preview group info from invite link without joining
			resp, err := runCtx.DaemonClient.Call("group.infoFromLink", map[string]string{"code": code})
			if err == nil && resp.Error == nil {
				data, _ := json.Marshal(resp.Result)
				var preview map[string]interface{}
				if json.Unmarshal(data, &preview) == nil {
					preview["dry_run"] = true
					preview["would_join"] = true
					return runCtx.Formatter.FormatSingle(preview)
				}
			}
			// Fallback if preview fails (e.g., daemon not running)
			return runCtx.Formatter.FormatSingle(map[string]interface{}{
				"dry_run":     true,
				"command":     "group join",
				"invite_code": code,
				"would_join":  true,
			})
		}

		resp, err := runCtx.DaemonClient.Call("group.join", map[string]string{"code": code})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to join group: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var result map[string]interface{}
		if err := json.Unmarshal(data, &result); err != nil {
			return &clierr.CLIError{
				Type:     "general",
				Code:     1,
				Message:  fmt.Sprintf("Failed to parse join response: %s", err),
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		return runCtx.Formatter.FormatSingle(result)
	},
}

var groupInfoCmd = &cobra.Command{
	Use:   "info <jid>",
	Short: "Show group details",
	Example: `  gowa group info 120363012345678901@g.us
  gowa group info 120363012345678901@g.us --members
  gowa group info 120363012345678901@g.us --members --role admin --json`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		jid := args[0]

		if err := safety.ValidateGroupJID(jid); err != nil {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("Invalid group JID: %s", err),
				Recovery: "Group JIDs end with @g.us, e.g. 120363012345678901@g.us",
			}
		}

		resp, err := runCtx.DaemonClient.Call("group.info", map[string]string{"jid": jid})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to get group info: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		showMembers, _ := cmd.Flags().GetBool("members")
		roleFilter, _ := cmd.Flags().GetString("role")

		if showMembers {
			// Parse full detail to extract participants
			data, _ := json.Marshal(resp.Result)
			var detail map[string]interface{}
			if err := json.Unmarshal(data, &detail); err != nil {
				return fmt.Errorf("parsing group info: %w", err)
			}

			participantsRaw, _ := json.Marshal(detail["participants"])
			var members []map[string]interface{}
			if err := json.Unmarshal(participantsRaw, &members); err != nil {
				return fmt.Errorf("parsing participants: %w", err)
			}

			// Filter by role if specified
			if roleFilter != "" {
				lowerRole := strings.ToLower(roleFilter)
				var filtered []map[string]interface{}
				for _, m := range members {
					role, _ := m["role"].(string)
					if strings.ToLower(role) == lowerRole {
						filtered = append(filtered, m)
					}
				}
				members = filtered
			}

			return runCtx.Formatter.Format(members, []output.Column{
				{Name: "JID", Field: "jid"},
				{Name: "NAME", Field: "display_name"},
				{Name: "ROLE", Field: "role"},
			})
		}

		// Default: show group details as single object
		data, _ := json.Marshal(resp.Result)
		var detail map[string]interface{}
		if err := json.Unmarshal(data, &detail); err != nil {
			return fmt.Errorf("parsing group info: %w", err)
		}

		return runCtx.Formatter.FormatSingle(detail)
	},
}

func init() {
	groupListCmd.Flags().String("name", "", "Filter groups by name (case-insensitive substring match)")
	groupListCmd.Flags().Int("limit", 50, "Maximum number of groups to display (table/quiet only; --json returns all)")

	groupInfoCmd.Flags().Bool("members", false, "Show group members instead of group details")
	groupInfoCmd.Flags().String("role", "", "Filter members by role: admin, member, superadmin (requires --members)")

	groupCreateCmd.Flags().String("members", "", "Comma-separated phone numbers for initial group members")
	groupCreateCmd.Flags().Bool("accept-risk", false, "Acknowledge WhatsApp ban risk")
	groupCreateCmd.Flags().Bool("dry-run", false, "Preview without creating the group")

	groupLeaveCmd.Flags().Bool("accept-risk", false, "Acknowledge WhatsApp ban risk")
	groupLeaveCmd.Flags().Bool("dry-run", false, "Preview without leaving the group")

	groupInviteLinkCmd.Flags().Bool("reset", false, "Generate a new invite link (admin only, requires --accept-risk)")
	groupInviteLinkCmd.Flags().Bool("accept-risk", false, "Acknowledge WhatsApp ban risk (required for --reset)")

	groupJoinCmd.Flags().Bool("accept-risk", false, "Acknowledge WhatsApp ban risk")
	groupJoinCmd.Flags().Bool("dry-run", false, "Preview without joining the group")

	groupCmd.AddCommand(groupListCmd)
	groupCmd.AddCommand(groupInfoCmd)
	groupCmd.AddCommand(groupCreateCmd)
	groupCmd.AddCommand(groupLeaveCmd)
	groupCmd.AddCommand(groupInviteLinkCmd)
	groupCmd.AddCommand(groupJoinCmd)
	rootCmd.AddCommand(groupCmd)
}
