package cmd

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/spf13/cobra"
	waLog "go.mau.fi/whatsmeow/util/log"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/daemon"
	"github.com/murilloimparavel/gowa-cli/internal/whatsapp"
)

var logoutCmd = &cobra.Command{
	Use:   "logout",
	Short: "Disconnect WhatsApp and clean up session",
	Long: `Logout stops the daemon, sends a WhatsApp unlink request, and deletes
the session database. Use --purge to also delete stored messages.

Examples:
  gowa logout            # stop daemon + unlink WhatsApp + delete session.db
  gowa logout --purge    # also delete messages.db
  gowa logout --json     # structured output`,
	RunE: runLogout,
}

func init() {
	logoutCmd.Flags().Bool("purge", false, "Also delete messages.db")
	rootCmd.AddCommand(logoutCmd)
}

func runLogout(cmd *cobra.Command, args []string) error {
	purge, _ := cmd.Flags().GetBool("purge")
	jsonMode, _ := cmd.Flags().GetBool("json")

	paths, err := daemon.NewPaths()
	if err != nil {
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  "Cannot determine config paths",
			Recovery: "Check your home directory permissions",
			Original: err,
		}
	}

	// Short-circuit: if no session and daemon not running, nothing to do
	running, _ := daemon.IsRunning(paths.PID)
	_, sessionErr := os.Stat(paths.SessionDB)
	if os.IsNotExist(sessionErr) && !running {
		if jsonMode {
			return runCtx.Formatter.FormatSingle(map[string]interface{}{
				"status": "not_paired",
			})
		}
		fmt.Fprintln(os.Stderr, "Not paired — nothing to clean up")
		return nil
	}

	steps := make([]map[string]interface{}, 0, 6)

	// Step 1: Stop daemon if running
	if running {
		if stopErr := daemon.Stop(paths); stopErr != nil {
			steps = append(steps, map[string]interface{}{
				"step": "stop_daemon", "status": "warning", "detail": stopErr.Error(),
			})
		} else {
			steps = append(steps, map[string]interface{}{
				"step": "stop_daemon", "status": "done",
			})
		}
	} else {
		steps = append(steps, map[string]interface{}{
			"step": "stop_daemon", "status": "skipped", "detail": "not running",
		})
	}

	// Step 2: Open WaClient and send WhatsApp logout (unlink IQ)
	logLevel := "ERROR"
	waClient, waErr := whatsapp.NewWaClient(cmd.Context(), paths.SessionDB, waLog.Stdout("GOWA", logLevel, true))
	if waErr != nil {
		steps = append(steps, map[string]interface{}{
			"step": "whatsapp_logout", "status": "skipped", "detail": "no session found",
		})
	} else {
		if waClient.NeedsPairing() {
			steps = append(steps, map[string]interface{}{
				"step": "whatsapp_logout", "status": "skipped", "detail": "not paired",
			})
		} else {
			ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
			defer cancel()

			// Must connect to WhatsApp before sending logout IQ
			if connErr := waClient.Connect(ctx); connErr != nil {
				steps = append(steps, map[string]interface{}{
					"step": "whatsapp_logout", "status": "warning",
					"detail": fmt.Sprintf("could not connect to send unlink: %s (local session deleted anyway)", connErr),
				})
			} else if logoutErr := waClient.Logout(ctx); logoutErr != nil {
				steps = append(steps, map[string]interface{}{
					"step": "whatsapp_logout", "status": "warning", "detail": logoutErr.Error(),
				})
			} else {
				steps = append(steps, map[string]interface{}{
					"step": "whatsapp_logout", "status": "done",
				})
			}
		}
		waClient.Close()
	}

	// Step 3: Delete session.db
	if removeErr := os.Remove(paths.SessionDB); removeErr != nil && !os.IsNotExist(removeErr) {
		steps = append(steps, map[string]interface{}{
			"step": "delete_session_db", "status": "warning", "detail": removeErr.Error(),
		})
	} else {
		steps = append(steps, map[string]interface{}{
			"step": "delete_session_db", "status": "done",
		})
	}

	// Step 4: Optionally delete messages.db
	if purge {
		if removeErr := os.Remove(paths.MsgDB); removeErr != nil && !os.IsNotExist(removeErr) {
			steps = append(steps, map[string]interface{}{
				"step": "delete_messages_db", "status": "warning", "detail": removeErr.Error(),
			})
		} else {
			steps = append(steps, map[string]interface{}{
				"step": "delete_messages_db", "status": "done",
			})
		}
	}

	// Step 5: Reset state.json (rate limiter)
	homeDir, _ := os.UserHomeDir()
	statePath := filepath.Join(homeDir, ".config", "gowa", "state.json")
	if removeErr := os.Remove(statePath); removeErr != nil && !os.IsNotExist(removeErr) {
		steps = append(steps, map[string]interface{}{
			"step": "reset_state", "status": "warning", "detail": removeErr.Error(),
		})
	} else {
		steps = append(steps, map[string]interface{}{
			"step": "reset_state", "status": "done",
		})
	}

	// Step 6: Clean stale daemon files
	daemon.CleanStale(paths)
	steps = append(steps, map[string]interface{}{
		"step": "clean_stale_files", "status": "done",
	})

	// Output
	if jsonMode {
		return runCtx.Formatter.FormatSingle(map[string]interface{}{
			"status": "logged_out",
			"purge":  purge,
			"steps":  steps,
		})
	}

	fmt.Fprintln(os.Stderr, "Logout complete:")
	for _, s := range steps {
		status := s["status"]
		detail, hasDetail := s["detail"]
		if hasDetail && detail != "" {
			fmt.Fprintf(os.Stderr, "  %s: %s (%s)\n", s["step"], status, detail)
		} else {
			fmt.Fprintf(os.Stderr, "  %s: %s\n", s["step"], status)
		}
	}
	return nil
}
