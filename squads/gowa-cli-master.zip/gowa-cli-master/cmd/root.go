package cmd

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/fatih/color"
	"github.com/spf13/cobra"
	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/config"
	"github.com/murilloimparavel/gowa-cli/internal/daemon"
	"github.com/murilloimparavel/gowa-cli/internal/output"
	"github.com/murilloimparavel/gowa-cli/internal/service"
)

var (
	cliVersion = "dev"
	cliCommit  = "none"
	cliDate    = "unknown"
)

type RunContext struct {
	Config       *config.Config
	Formatter    output.Formatter
	Messenger    service.Messenger
	DaemonClient *daemon.Client
}

var runCtx = &RunContext{}

var rootCmd = &cobra.Command{
	Use:   "gowa",
	Short: "WhatsApp CLI powered by embedded whatsmeow",
	Long: `gowa is a command-line interface for WhatsApp with an embedded WhatsApp
connection (whatsmeow). It provides agent-friendly, scriptable commands for
sending messages, managing devices, and more.

Get started:
  gowa pair                                          # link your WhatsApp account
  gowa daemon start                                  # start background daemon
  gowa send text --to 5511999999999 "Hello from CLI" # send a message
  gowa logout                                        # disconnect and clean up`,
	SilenceUsage:  true,
	SilenceErrors: true,
	PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
		if cmd.Name() == "help" {
			return nil
		}

		// Bypass daemon for commands that don't need it
		path := cmd.CommandPath()
		switch {
		case path == "gowa pair",
			path == "gowa logout",
			path == "gowa version",
			strings.HasPrefix(path, "gowa daemon"),
			strings.HasPrefix(path, "gowa completion"):
			jsonFlag, _ := cmd.Flags().GetBool("json")
			quietFlag, _ := cmd.Flags().GetBool("quiet")
			format := output.AutoDetect(jsonFlag, quietFlag)
			runCtx.Formatter = output.New(format, os.Stdout)
			return nil
		}

		cfg, err := config.New()
		if err != nil {
			return err
		}

		if d, _ := cmd.Flags().GetString("device"); d != "" {
			cfg.Set("device_id", d)
		}

		// Apply --no-color flag
		if noColor, _ := cmd.Flags().GetBool("no-color"); noColor {
			color.NoColor = true
		}

		jsonFlag, _ := cmd.Flags().GetBool("json")
		quietFlag, _ := cmd.Flags().GetBool("quiet")
		format := output.AutoDetect(jsonFlag, quietFlag)
		f := output.New(format, os.Stdout)

		runCtx.Config = cfg
		runCtx.Formatter = f

		// Daemon-only mode: connect to running daemon
		paths, pathErr := daemon.NewPaths()
		if pathErr != nil {
			return &clierr.CLIError{
				Type:     "general",
				Code:     1,
				Message:  "Cannot determine config paths",
				Recovery: "Check your home directory permissions",
				Original: pathErr,
			}
		}

		running, _ := daemon.IsRunning(paths.PID)
		if !running {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     1,
				Message:  "Daemon is not running",
				Recovery: "Start it with 'gowa daemon start'",
			}
		}

		dc, dcErr := daemon.NewClient(paths.Socket, paths.Token)
		if dcErr != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     1,
				Message:  fmt.Sprintf("Cannot connect to daemon: %s", dcErr),
				Recovery: "Try 'gowa daemon stop && gowa daemon start'",
				Original: dcErr,
			}
		}

		// Apply --timeout flag to daemon client
		if timeoutStr, _ := cmd.Flags().GetString("timeout"); timeoutStr != "" {
			if d, err := time.ParseDuration(timeoutStr); err == nil {
				dc.Timeout = d
			}
		}

		runCtx.DaemonClient = dc
		runCtx.Messenger = service.NewDaemonMessenger(dc)

		return nil
	},
}

func SetVersion(version, commit, date string) {
	cliVersion = version
	cliCommit = commit
	cliDate = date
}

func Execute() int {
	if err := rootCmd.Execute(); err != nil {
		jsonFlag, _ := rootCmd.PersistentFlags().GetBool("json")

		var cliErr *clierr.CLIError
		if errors.As(err, &cliErr) {
			if jsonFlag {
				writeJSONError(cliErr.Type, cliErr.Code, cliErr.Message, cliErr.Recovery)
			} else {
				fmt.Fprintln(os.Stderr, cliErr.Error())
			}
			return cliErr.ExitCode()
		}

		if jsonFlag {
			writeJSONError("general", 1, err.Error(), "")
		} else {
			fmt.Fprintln(os.Stderr, "Error: "+err.Error())
		}
		return 1
	}
	return 0
}

func writeJSONError(errType string, code int, message, recovery string) {
	payload := map[string]interface{}{
		"error":   true,
		"type":    errType,
		"code":    code,
		"message": message,
	}
	if recovery != "" {
		payload["recovery"] = recovery
	}
	_ = json.NewEncoder(os.Stderr).Encode(payload)
}

func init() {
	rootCmd.PersistentFlags().Bool("json", false, "Output in JSON format")
	rootCmd.PersistentFlags().Bool("quiet", false, "Minimal output (bare values)")
	rootCmd.PersistentFlags().String("device", "", "Device JID override")
	rootCmd.PersistentFlags().Bool("no-color", false, "Disable colored output")
	rootCmd.PersistentFlags().String("timeout", "30s", "Request timeout (e.g., 10s, 1m)")
}
