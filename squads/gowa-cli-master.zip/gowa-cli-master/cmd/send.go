package cmd

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"os"
	"strings"
	"time"

	"github.com/mattn/go-isatty"
	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/config"
	"github.com/murilloimparavel/gowa-cli/internal/output"
	"github.com/murilloimparavel/gowa-cli/internal/safety"
	"github.com/spf13/cobra"
)

const riskWarning = `
WARNING: Unofficial WhatsApp API
This CLI uses an unofficial WhatsApp Web API. Using it may result in:
  - Temporary or permanent ban of your WhatsApp number
  - Loss of message history and contacts

Recommendations:
  - Use a disposable phone number (not your primary)
  - Consider the official WhatsApp Business API for production use

Risk acknowledged. This warning will not appear again.
`

func checkAcceptRisk(cmd *cobra.Command) error {
	// Already accepted in config — skip silently
	if runCtx.Config != nil && runCtx.Config.GetBool("risk_accepted") {
		return nil
	}

	// Flag --accept-risk passed — persist and show warning
	acceptRisk, _ := cmd.Flags().GetBool("accept-risk")
	if acceptRisk {
		if runCtx.Config != nil {
			runCtx.Config.SetValue("risk_accepted", true)
			_ = runCtx.Config.Save()
		}
		fmt.Fprint(os.Stderr, riskWarning)
		return nil
	}

	// Not accepted — return exit code 2
	return &clierr.CLIError{
		Type:     "usage_error",
		Code:     2,
		Message:  "Risk acknowledgment required for send operations",
		Recovery: "Run with --accept-risk to acknowledge risks, or add 'risk_accepted: true' to ~/.config/gowa/config.yaml",
	}
}

// readRecipientsFile reads phone numbers from a file, one per line.
// Empty lines and lines starting with # are skipped.
func readRecipientsFile(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("opening recipients file: %w", err)
	}
	defer f.Close()

	var phones []string
	scanner := bufio.NewScanner(f)
	lineNum := 0
	for scanner.Scan() {
		lineNum++
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		phones = append(phones, line)
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("reading recipients file: %w", err)
	}
	if len(phones) == 0 {
		return nil, fmt.Errorf("recipients file %s contains no phone numbers", path)
	}
	return phones, nil
}

// validateRecipients validates all phone numbers and returns a CLIError on the first invalid one.
func validateRecipients(phones []string) error {
	for i, phone := range phones {
		if err := safety.ValidatePhone(phone); err != nil {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("recipient #%d: %s", i+1, err.Error()),
				Recovery: "Use E.164 format without '+': e.g., 5511999999999",
			}
		}
	}
	return nil
}

// checkToFlags checks that --to and --to-file are not both set, and returns
// the list of recipients. If --to-file is set, reads recipients from the file.
// If --to is set, returns a single-element slice. Returns error if neither is set.
func checkToFlags(cmd *cobra.Command) ([]string, error) {
	to, _ := cmd.Flags().GetString("to")
	toFile, _ := cmd.Flags().GetString("to-file")

	if to != "" && toFile != "" {
		return nil, &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  "--to and --to-file are mutually exclusive",
			Recovery: "Use --to for a single recipient or --to-file for batch sending, not both",
		}
	}

	if to == "" && toFile == "" {
		return nil, &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  "--to or --to-file flag is required",
			Recovery: "Use --to for a single recipient or --to-file for batch sending",
		}
	}

	if toFile != "" {
		phones, err := readRecipientsFile(toFile)
		if err != nil {
			return nil, err
		}
		return phones, nil
	}

	return []string{to}, nil
}

// BatchResult holds the outcome of a single send in a batch operation.
type BatchResult struct {
	Recipient string `json:"recipient"`
	MessageID string `json:"message_id,omitempty"`
	Status    string `json:"status"`
	Error     string `json:"error,omitempty"`
}

// randomBatchDelay returns a randomized delay between 1-5 seconds for anti-ban.
func randomBatchDelay() time.Duration {
	return time.Duration(1000+rand.Intn(4000)) * time.Millisecond
}

var sendCmd = &cobra.Command{
	Use:   "send",
	Short: "Send messages (text, media, files)",
	Long: `Send text messages, images, and files via WhatsApp.

Requires the daemon to be running (gowa daemon start) and risk acknowledgment
(--accept-risk flag or 'risk_accepted: true' in config). Use --dry-run to
preview without actually sending. Supports batch sending with --to-file.`,
	PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
		dryRun, _ := cmd.Flags().GetBool("dry-run")

		if dryRun {
			// Dry-run only needs formatter and config, not daemon
			jsonFlag, _ := cmd.Flags().GetBool("json")
			quietFlag, _ := cmd.Flags().GetBool("quiet")
			format := output.AutoDetect(jsonFlag, quietFlag)
			runCtx.Formatter = output.New(format, os.Stdout)

			// Initialize config so checkAcceptRisk can read risk_accepted
			if runCtx.Config == nil {
				cfg, err := config.New()
				if err != nil {
					return &clierr.CLIError{
					Type:     "general",
					Code:     1,
					Message:  fmt.Sprintf("Failed to load config: %s", err),
					Recovery: "Check config file at ~/.config/gowa/config.yaml",
					Original: err,
				}
				}
				runCtx.Config = cfg
			}

			return checkAcceptRisk(cmd)
		}

		// Cobra does NOT chain PersistentPreRunE — must call parent explicitly
		if rootCmd.PersistentPreRunE != nil {
			if err := rootCmd.PersistentPreRunE(cmd, args); err != nil {
				return err
			}
		}
		return checkAcceptRisk(cmd)
	},
}

var sendTextCmd = &cobra.Command{
	Use:   "text [message]",
	Short: "Send text message",
	Example: `  gowa send text --to 5511999999999 "Hello World"
  gowa send text --to 5511999999999 "Reply" --reply MSG_ID
  echo "piped message" | gowa send text --to 5511999999999
  gowa send text --to-file recipients.txt "Hello everyone"
  gowa send text --to 5511999999999 "Hello" --dry-run`,
	RunE: func(cmd *cobra.Command, args []string) error {
		reply, _ := cmd.Flags().GetString("reply")
		dryRun, _ := cmd.Flags().GetBool("dry-run")

		recipients, err := checkToFlags(cmd)
		if err != nil {
			return err
		}

		// Validate all recipients
		if err := validateRecipients(recipients); err != nil {
			return err
		}

		message := strings.Join(args, " ")

		// If no args provided, try reading from stdin
		if message == "" {
			if isatty.IsTerminal(os.Stdin.Fd()) || isatty.IsCygwinTerminal(os.Stdin.Fd()) {
				return &clierr.CLIError{
					Type:     "usage_error",
					Code:     2,
					Message:  "Provide message as argument or pipe via stdin",
					Recovery: "Usage: gowa send text --to PHONE 'message' or echo 'message' | gowa send text --to PHONE",
				}
			}
			data, err := io.ReadAll(io.LimitReader(os.Stdin, 64*1024))
			if err != nil {
				return fmt.Errorf("reading stdin: %w", err)
			}
			message = strings.TrimSpace(string(data))
		}

		if message == "" {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  "message text is required",
				Recovery: "Provide a non-empty message as argument or pipe via stdin",
			}
		}

		// Dry-run: preview without sending
		if dryRun {
			if len(recipients) == 1 {
				return runCtx.Formatter.FormatSingle(map[string]interface{}{
					"dry_run":            true,
					"command":            "send text",
					"to":                 recipients[0],
					"message":            message,
					"reply_to":           reply,
					"would_send":         true,
					"validations_passed": true,
				})
			}
			// Batch dry-run: show all recipients
			previews := make([]map[string]interface{}, 0, len(recipients))
			for _, phone := range recipients {
				previews = append(previews, map[string]interface{}{
					"dry_run":            true,
					"command":            "send text",
					"to":                 phone,
					"message":            message,
					"reply_to":           reply,
					"would_send":         true,
					"validations_passed": true,
				})
			}
			return runCtx.Formatter.Format(previews, []output.Column{
				{Name: "TO", Field: "to"},
				{Name: "COMMAND", Field: "command"},
				{Name: "MESSAGE", Field: "message"},
				{Name: "WOULD_SEND", Field: "would_send"},
			})
		}

		// Single recipient
		if len(recipients) == 1 {
			result, err := runCtx.Messenger.SendText(cmd.Context(), recipients[0], message, reply)
			if err != nil {
				return err
			}
			return runCtx.Formatter.FormatSingle(result)
		}

		// Batch send with randomized delays
		results := make([]BatchResult, 0, len(recipients))
		for i, phone := range recipients {
			if i > 0 {
				time.Sleep(randomBatchDelay())
			}
			result, err := runCtx.Messenger.SendText(cmd.Context(), phone, message, reply)
			if err != nil {
				// Check if rate limit error — stop batch
				var cliErr *clierr.CLIError
				if errors.As(err, &cliErr) && cliErr.Type == "rate_limit" {
					results = append(results, BatchResult{
						Recipient: phone,
						Status:    "rate_limited",
						Error:     err.Error(),
					})
					// Output partial results and return the rate limit error
					_ = runCtx.Formatter.Format(results, batchColumns())
					return err
				}
				results = append(results, BatchResult{
					Recipient: phone,
					Status:    "error",
					Error:     err.Error(),
				})
				continue
			}
			results = append(results, BatchResult{
				Recipient: phone,
				MessageID: result.MessageID,
				Status:    result.Status,
			})
		}

		return runCtx.Formatter.Format(results, batchColumns())
	},
}

var sendImageCmd = &cobra.Command{
	Use:   "image",
	Short: "Send image",
	Example: `  gowa send image --to 5511999999999 --file photo.jpg
  gowa send image --to 5511999999999 --file photo.jpg --caption "Look at this!"
  gowa send image --to-file recipients.txt --file photo.jpg
  gowa send image --to 5511999999999 --file photo.jpg --dry-run`,
	RunE: func(cmd *cobra.Command, args []string) error {
		file, _ := cmd.Flags().GetString("file")
		caption, _ := cmd.Flags().GetString("caption")
		dryRun, _ := cmd.Flags().GetBool("dry-run")

		recipients, err := checkToFlags(cmd)
		if err != nil {
			return err
		}

		if file == "" {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  "--file flag is required",
				Recovery: "Provide an image file path: gowa send image --to PHONE --file photo.jpg",
			}
		}

		// Validate all recipients
		if err := validateRecipients(recipients); err != nil {
			return err
		}
		if err := safety.ValidateFilePath(file); err != nil {
			return err
		}
		if err := safety.ValidateFileExtension(file, []string{".jpg", ".jpeg", ".png", ".gif", ".webp"}); err != nil {
			return err
		}

		// Get file size for dry-run/preview
		var fileSize int64
		if info, err := os.Stat(file); err == nil {
			fileSize = info.Size()
		}

		// Dry-run: preview without sending
		if dryRun {
			if len(recipients) == 1 {
				return runCtx.Formatter.FormatSingle(map[string]interface{}{
					"dry_run":            true,
					"command":            "send image",
					"to":                 recipients[0],
					"file":               file,
					"file_size":          fileSize,
					"caption":            caption,
					"would_send":         true,
					"validations_passed": true,
				})
			}
			previews := make([]map[string]interface{}, 0, len(recipients))
			for _, phone := range recipients {
				previews = append(previews, map[string]interface{}{
					"dry_run":            true,
					"command":            "send image",
					"to":                 phone,
					"file":               file,
					"file_size":          fileSize,
					"caption":            caption,
					"would_send":         true,
					"validations_passed": true,
				})
			}
			return runCtx.Formatter.Format(previews, []output.Column{
				{Name: "TO", Field: "to"},
				{Name: "COMMAND", Field: "command"},
				{Name: "FILE", Field: "file"},
				{Name: "WOULD_SEND", Field: "would_send"},
			})
		}

		// Single recipient
		if len(recipients) == 1 {
			result, err := runCtx.Messenger.SendImage(cmd.Context(), recipients[0], file, caption)
			if err != nil {
				return err
			}
			return runCtx.Formatter.FormatSingle(result)
		}

		// Batch send with randomized delays
		results := make([]BatchResult, 0, len(recipients))
		for i, phone := range recipients {
			if i > 0 {
				time.Sleep(randomBatchDelay())
			}
			result, err := runCtx.Messenger.SendImage(cmd.Context(), phone, file, caption)
			if err != nil {
				var cliErr *clierr.CLIError
				if errors.As(err, &cliErr) && cliErr.Type == "rate_limit" {
					results = append(results, BatchResult{
						Recipient: phone,
						Status:    "rate_limited",
						Error:     err.Error(),
					})
					_ = runCtx.Formatter.Format(results, batchColumns())
					return err
				}
				results = append(results, BatchResult{
					Recipient: phone,
					Status:    "error",
					Error:     err.Error(),
				})
				continue
			}
			results = append(results, BatchResult{
				Recipient: phone,
				MessageID: result.MessageID,
				Status:    result.Status,
			})
		}

		return runCtx.Formatter.Format(results, batchColumns())
	},
}

var sendFileCmd = &cobra.Command{
	Use:   "file",
	Short: "Send document/file",
	Example: `  gowa send file --to 5511999999999 --file report.pdf
  gowa send file --to-file recipients.txt --file report.pdf
  gowa send file --to 5511999999999 --file report.pdf --dry-run`,
	RunE: func(cmd *cobra.Command, args []string) error {
		file, _ := cmd.Flags().GetString("file")
		dryRun, _ := cmd.Flags().GetBool("dry-run")

		recipients, err := checkToFlags(cmd)
		if err != nil {
			return err
		}

		if file == "" {
			return &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  "--file flag is required",
				Recovery: "Provide a file path: gowa send file --to PHONE --file report.pdf",
			}
		}

		// Validate all recipients
		if err := validateRecipients(recipients); err != nil {
			return err
		}
		if err := safety.ValidateFilePath(file); err != nil {
			return err
		}

		// Get file size for dry-run/preview
		var fileSize int64
		if info, err := os.Stat(file); err == nil {
			fileSize = info.Size()
		}

		// Dry-run: preview without sending
		if dryRun {
			if len(recipients) == 1 {
				return runCtx.Formatter.FormatSingle(map[string]interface{}{
					"dry_run":            true,
					"command":            "send file",
					"to":                 recipients[0],
					"file":               file,
					"file_size":          fileSize,
					"would_send":         true,
					"validations_passed": true,
				})
			}
			previews := make([]map[string]interface{}, 0, len(recipients))
			for _, phone := range recipients {
				previews = append(previews, map[string]interface{}{
					"dry_run":            true,
					"command":            "send file",
					"to":                 phone,
					"file":               file,
					"file_size":          fileSize,
					"would_send":         true,
					"validations_passed": true,
				})
			}
			return runCtx.Formatter.Format(previews, []output.Column{
				{Name: "TO", Field: "to"},
				{Name: "COMMAND", Field: "command"},
				{Name: "FILE", Field: "file"},
				{Name: "WOULD_SEND", Field: "would_send"},
			})
		}

		// Single recipient
		if len(recipients) == 1 {
			result, err := runCtx.Messenger.SendFile(cmd.Context(), recipients[0], file)
			if err != nil {
				return err
			}
			return runCtx.Formatter.FormatSingle(result)
		}

		// Batch send with randomized delays
		results := make([]BatchResult, 0, len(recipients))
		for i, phone := range recipients {
			if i > 0 {
				time.Sleep(randomBatchDelay())
			}
			result, err := runCtx.Messenger.SendFile(cmd.Context(), phone, file)
			if err != nil {
				var cliErr *clierr.CLIError
				if errors.As(err, &cliErr) && cliErr.Type == "rate_limit" {
					results = append(results, BatchResult{
						Recipient: phone,
						Status:    "rate_limited",
						Error:     err.Error(),
					})
					_ = runCtx.Formatter.Format(results, batchColumns())
					return err
				}
				results = append(results, BatchResult{
					Recipient: phone,
					Status:    "error",
					Error:     err.Error(),
				})
				continue
			}
			results = append(results, BatchResult{
				Recipient: phone,
				MessageID: result.MessageID,
				Status:    result.Status,
			})
		}

		return runCtx.Formatter.Format(results, batchColumns())
	},
}

// batchColumns returns the standard column definitions for batch send results.
func batchColumns() []output.Column {
	return []output.Column{
		{Name: "RECIPIENT", Field: "recipient"},
		{Name: "MESSAGE_ID", Field: "message_id"},
		{Name: "STATUS", Field: "status"},
		{Name: "ERROR", Field: "error"},
	}
}

func init() {
	// Dry-run flag on send parent (available to all subcommands)
	sendCmd.PersistentFlags().Bool("dry-run", false, "Validate inputs and preview the request without sending")
	sendCmd.PersistentFlags().Bool("accept-risk", false, "Acknowledge WhatsApp ban risk")

	sendTextCmd.Flags().String("to", "", "Recipient phone number or JID")
	sendTextCmd.Flags().String("to-file", "", "File with one phone number per line for batch sending")
	sendTextCmd.Flags().String("reply", "", "Message ID to reply to")

	sendImageCmd.Flags().String("to", "", "Recipient phone number or JID")
	sendImageCmd.Flags().String("to-file", "", "File with one phone number per line for batch sending")
	sendImageCmd.Flags().String("file", "", "Image file path (required)")
	sendImageCmd.Flags().String("caption", "", "Image caption")

	sendFileCmd.Flags().String("to", "", "Recipient phone number or JID")
	sendFileCmd.Flags().String("to-file", "", "File with one phone number per line for batch sending")
	sendFileCmd.Flags().String("file", "", "File path (required)")

	sendCmd.AddCommand(sendTextCmd)
	sendCmd.AddCommand(sendImageCmd)
	sendCmd.AddCommand(sendFileCmd)
	rootCmd.AddCommand(sendCmd)
}
