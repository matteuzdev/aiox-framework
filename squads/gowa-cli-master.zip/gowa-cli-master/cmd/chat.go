package cmd

import (
	"encoding/json"
	"fmt"

	"github.com/spf13/cobra"
	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/output"
	"github.com/murilloimparavel/gowa-cli/internal/safety"
)

var chatCmd = &cobra.Command{
	Use:   "chat",
	Short: "Manage conversations",
	Long: `List chats and retrieve message history from your WhatsApp account.

Requires the daemon to be running (gowa daemon start). The daemon maintains
the WhatsApp connection in the background and serves chat data over local RPC.`,
}

var chatListCmd = &cobra.Command{
	Use:   "list",
	Short: "List chats",
	Example: `  gowa chat list
  gowa chat list --limit 20 --search "john"
  gowa chat list --json`,
	RunE: func(cmd *cobra.Command, args []string) error {
		limit, _ := cmd.Flags().GetInt("limit")
		search, _ := cmd.Flags().GetString("search")

		resp, err := runCtx.DaemonClient.Call("chat.list", map[string]interface{}{
			"limit":  limit,
			"search": search,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to list chats: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		// Parse result into slice of maps for formatter
		data, _ := json.Marshal(resp.Result)
		var chats []map[string]interface{}
		if err := json.Unmarshal(data, &chats); err != nil {
			return fmt.Errorf("parsing chat list: %w", err)
		}

		return runCtx.Formatter.Format(chats, []output.Column{
			{Name: "JID", Field: "jid"},
			{Name: "NAME", Field: "name"},
			{Name: "LAST MESSAGE", Field: "last_message"},
			{Name: "UNREAD", Field: "unread_count"},
		})
	},
}

var chatMessagesCmd = &cobra.Command{
	Use:   "messages <jid>",
	Short: "Get messages from a chat",
	Example: `  gowa chat messages 5511999999999
  gowa chat messages 5511999999999 --limit 50 --since 2024-01-15T00:00:00Z
  gowa chat messages GROUP_JID --json`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		jid := args[0]
		limit, _ := cmd.Flags().GetInt("limit")
		since, _ := cmd.Flags().GetString("since")
		until, _ := cmd.Flags().GetString("until")
		search, _ := cmd.Flags().GetString("search")

		if since != "" {
			if err := safety.ValidateRFC3339(since, "since"); err != nil {
				return err
			}
		}
		if until != "" {
			if err := safety.ValidateRFC3339(until, "until"); err != nil {
				return err
			}
		}

		resp, err := runCtx.DaemonClient.Call("chat.messages", map[string]interface{}{
			"jid":    jid,
			"limit":  limit,
			"since":  since,
			"until":  until,
			"search": search,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to get messages: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var messages []map[string]interface{}
		if err := json.Unmarshal(data, &messages); err != nil {
			return fmt.Errorf("parsing messages: %w", err)
		}

		return runCtx.Formatter.Format(messages, []output.Column{
			{Name: "ID", Field: "id"},
			{Name: "FROM", Field: "from"},
			{Name: "TYPE", Field: "type"},
			{Name: "TEXT", Field: "text"},
			{Name: "STATUS", Field: "status"},
		})
	},
}

var chatUnreadCmd = &cobra.Command{
	Use:   "unread",
	Short: "List chats with unread messages",
	Example: `  gowa chat unread
  gowa chat unread --json`,
	RunE: func(cmd *cobra.Command, args []string) error {
		resp, err := runCtx.DaemonClient.Call("chat.unread", nil)
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to list unread chats: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var chats []map[string]interface{}
		if err := json.Unmarshal(data, &chats); err != nil {
			return fmt.Errorf("parsing unread chats: %w", err)
		}

		return runCtx.Formatter.Format(chats, []output.Column{
			{Name: "JID", Field: "jid"},
			{Name: "NAME", Field: "name"},
			{Name: "LAST MESSAGE", Field: "last_msg_preview"},
			{Name: "UNREAD", Field: "unread_count"},
		})
	},
}

var chatReadCmd = &cobra.Command{
	Use:   "read <jid>",
	Short: "Mark a chat as read",
	Example: `  gowa chat read 5511999999999
  gowa chat read 5511999999999@s.whatsapp.net --json`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		jid := args[0]

		resp, err := runCtx.DaemonClient.Call("chat.read", map[string]interface{}{
			"jid": jid,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to mark chat as read: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		return runCtx.Formatter.FormatSingle(map[string]interface{}{
			"jid":    jid,
			"status": "read",
		})
	},
}

var chatSearchCmd = &cobra.Command{
	Use:   "search <query>",
	Short: "Search messages across all chats",
	Example: `  gowa chat search "meeting"
  gowa chat search "invoice" --limit 10 --json`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		query := args[0]
		limit, _ := cmd.Flags().GetInt("limit")

		resp, err := runCtx.DaemonClient.Call("chat.search", map[string]interface{}{
			"query": query,
			"limit": limit,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to search messages: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var messages []map[string]interface{}
		if err := json.Unmarshal(data, &messages); err != nil {
			return fmt.Errorf("parsing search results: %w", err)
		}

		return runCtx.Formatter.Format(messages, []output.Column{
			{Name: "ID", Field: "id"},
			{Name: "CHAT", Field: "chat_jid"},
			{Name: "FROM", Field: "sender_jid"},
			{Name: "TEXT", Field: "text"},
			{Name: "TIME", Field: "timestamp"},
		})
	},
}

func init() {
	chatListCmd.Flags().Int("limit", 25, "Maximum number of chats")
	chatListCmd.Flags().String("search", "", "Search filter")

	chatMessagesCmd.Flags().Int("limit", 50, "Maximum number of messages")
	chatMessagesCmd.Flags().String("since", "", "Start date (RFC3339)")
	chatMessagesCmd.Flags().String("until", "", "End date (RFC3339)")
	chatMessagesCmd.Flags().String("search", "", "Search in message text")

	chatSearchCmd.Flags().Int("limit", 50, "Maximum number of results")

	chatCmd.AddCommand(chatListCmd)
	chatCmd.AddCommand(chatMessagesCmd)
	chatCmd.AddCommand(chatUnreadCmd)
	chatCmd.AddCommand(chatReadCmd)
	chatCmd.AddCommand(chatSearchCmd)
	rootCmd.AddCommand(chatCmd)
}
