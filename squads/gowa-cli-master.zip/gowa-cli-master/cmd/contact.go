package cmd

import (
	"encoding/json"
	"fmt"

	"github.com/spf13/cobra"
	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/output"
)

var contactColumns = []output.Column{
	{Name: "JID", Field: "jid"},
	{Name: "NAME", Field: "push_name"},
	{Name: "FULL NAME", Field: "full_name"},
	{Name: "BUSINESS", Field: "business_name"},
	{Name: "PHONE", Field: "phone"},
}

var contactCmd = &cobra.Command{
	Use:   "contact",
	Short: "Manage WhatsApp contacts",
	Long: `List and search your WhatsApp contacts.

Requires the daemon to be running (gowa daemon start).`,
}

var contactListCmd = &cobra.Command{
	Use:   "list",
	Short: "List contacts",
	Example: `  gowa contact list
  gowa contact list --limit 50 --json`,
	RunE: func(cmd *cobra.Command, args []string) error {
		limit, _ := cmd.Flags().GetInt("limit")

		resp, err := runCtx.DaemonClient.Call("contact.list", map[string]interface{}{
			"limit": limit,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to list contacts: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var contacts []map[string]interface{}
		if err := json.Unmarshal(data, &contacts); err != nil {
			return fmt.Errorf("parsing contacts: %w", err)
		}

		return runCtx.Formatter.Format(contacts, contactColumns)
	},
}

var contactSearchCmd = &cobra.Command{
	Use:   "search <query>",
	Short: "Search contacts by name or phone",
	Example: `  gowa contact search "John"
  gowa contact search "+5511" --limit 10 --json`,
	Args: cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		query := args[0]
		limit, _ := cmd.Flags().GetInt("limit")

		resp, err := runCtx.DaemonClient.Call("contact.search", map[string]interface{}{
			"query": query,
			"limit": limit,
		})
		if err != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  fmt.Sprintf("Failed to search contacts: %s", err),
				Recovery: "Check daemon status with 'gowa daemon status'",
				Original: err,
			}
		}
		if resp.Error != nil {
			return &clierr.CLIError{
				Type:     "daemon_error",
				Code:     5,
				Message:  resp.Error.Message,
				Recovery: "Check daemon logs with 'gowa daemon logs'",
			}
		}

		data, _ := json.Marshal(resp.Result)
		var contacts []map[string]interface{}
		if err := json.Unmarshal(data, &contacts); err != nil {
			return fmt.Errorf("parsing contacts: %w", err)
		}

		return runCtx.Formatter.Format(contacts, contactColumns)
	},
}

func init() {
	contactListCmd.Flags().Int("limit", 100, "Maximum number of contacts")
	contactSearchCmd.Flags().Int("limit", 50, "Maximum number of results")

	contactCmd.AddCommand(contactListCmd)
	contactCmd.AddCommand(contactSearchCmd)
	rootCmd.AddCommand(contactCmd)
}
