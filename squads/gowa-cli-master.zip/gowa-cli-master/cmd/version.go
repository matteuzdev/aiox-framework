package cmd

import (
	"os"

	"github.com/spf13/cobra"
	"github.com/murilloimparavel/gowa-cli/internal/output"
)

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Show CLI version",
	Example: `  gowa version
  gowa version --json`,
	RunE: func(cmd *cobra.Command, args []string) error {
		info := map[string]string{
			"cli_version": cliVersion,
			"commit":      cliCommit,
			"build_date":  cliDate,
		}

		f := runCtx.Formatter
		if f == nil {
			// Defense-in-depth: PersistentPreRunE should have already set the
			// Formatter, but version may be invoked in contexts where it hasn't
			// run (e.g., early --version flag). Create a fallback to stay safe.
			jsonFlag, _ := cmd.Flags().GetBool("json")
			quietFlag, _ := cmd.Flags().GetBool("quiet")
			format := output.AutoDetect(jsonFlag, quietFlag)
			f = output.New(format, os.Stdout)
		}

		return f.FormatSingle(info)
	},
}

func init() {
	rootCmd.AddCommand(versionCmd)
}
