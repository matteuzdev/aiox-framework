package config

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/spf13/viper"
)

const (
	DefaultOutput  = "table"
	configFileName = "config"
	configFileType = "yaml"
)

type Config struct {
	v       *viper.Viper
	userSet map[string]bool // tracks keys explicitly set by the user
}

func New() (*Config, error) {
	v := viper.New()

	v.SetDefault("device_id", "")
	v.SetDefault("output", DefaultOutput)
	v.SetDefault("risk_accepted", false)
	v.SetDefault("timeout", "30s")

	v.SetEnvPrefix("GOWA")
	v.AutomaticEnv()

	// L-23: Explicit BindEnv so each config key maps to its GOWA_ env var.
	_ = v.BindEnv("device_id", "GOWA_DEVICE_ID")
	_ = v.BindEnv("output", "GOWA_OUTPUT")
	_ = v.BindEnv("risk_accepted", "GOWA_RISK_ACCEPTED")
	_ = v.BindEnv("timeout", "GOWA_TIMEOUT")

	configDir, err := configPath()
	if err != nil {
		return &Config{v: v, userSet: make(map[string]bool)}, nil
	}

	v.SetConfigName(configFileName)
	v.SetConfigType(configFileType)
	v.AddConfigPath(configDir)

	if err := v.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); !ok {
			return nil, fmt.Errorf("reading config: %w", err)
		}
	}

	// Mark keys loaded from the config file as user-set.
	cfg := &Config{v: v, userSet: make(map[string]bool)}
	for _, k := range v.AllKeys() {
		if v.InConfig(k) {
			cfg.userSet[k] = true
		}
	}
	return cfg, nil
}

func (c *Config) DeviceID() string    { return c.v.GetString("device_id") }
func (c *Config) OutputFormat() string { return c.v.GetString("output") }
func (c *Config) RiskAccepted() bool   { return c.v.GetBool("risk_accepted") }
func (c *Config) Timeout() string       { return c.v.GetString("timeout") }

func (c *Config) Set(key, value string) {
	c.v.Set(key, value)
	c.userSet[key] = true
}

func (c *Config) SetValue(key string, value interface{}) {
	c.v.Set(key, value)
	c.userSet[key] = true
}

func (c *Config) GetBool(key string) bool {
	return c.v.GetBool(key)
}

// Save writes only user-modified keys to the config file, avoiding
// pollution with default values (L-24).
func (c *Config) Save() error {
	dir, err := configPath()
	if err != nil {
		return fmt.Errorf("resolving config dir: %w", err)
	}

	if err := os.MkdirAll(dir, 0700); err != nil {
		return fmt.Errorf("creating config dir: %w", err)
	}

	fp := filepath.Join(dir, configFileName+"."+configFileType)

	// Build a viper instance with only user-set keys so defaults
	// are not persisted to disk.
	sparse := viper.New()
	for k := range c.userSet {
		sparse.Set(k, c.v.Get(k))
	}

	if err := sparse.WriteConfigAs(fp); err != nil {
		return fmt.Errorf("writing config: %w", err)
	}

	return os.Chmod(fp, 0600)
}

// ConfigPath returns the full path to the config file, propagating any
// error from the underlying configPath call (L-25).
func (c *Config) ConfigPath() (string, error) {
	dir, err := configPath()
	if err != nil {
		return "", fmt.Errorf("resolving config dir: %w", err)
	}
	return filepath.Join(dir, configFileName+"."+configFileType), nil
}

func configPath() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(home, ".config", "gowa"), nil
}
