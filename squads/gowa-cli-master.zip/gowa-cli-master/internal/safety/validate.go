package safety

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

// phoneRegex matches E.164 numbers (10-15 digits) with optional WhatsApp JID suffix.
var phoneRegex = regexp.MustCompile(`^\d{10,15}(@s\.whatsapp\.net)?$`)

// lidRegex matches WhatsApp LID JIDs (numeric@lid).
var lidRegex = regexp.MustCompile(`^\d+@lid$`)

// groupRegex matches WhatsApp group JIDs (numeric@g.us).
var groupRegex = regexp.MustCompile(`^\d+@g\.us$`)

// ValidatePhone checks that phone is a valid E.164 number, WhatsApp JID, LID JID, or group JID.
// Accepts optional + prefix, spaces, and dashes which are stripped before validation.
// JID suffixes (@s.whatsapp.net, @lid, @g.us) are preserved when present.
func ValidatePhone(phone string) error {
	// If input contains @, validate as a full JID
	if idx := strings.Index(phone, "@"); idx != -1 {
		// Accept @lid JIDs (WhatsApp LID migration)
		if lidRegex.MatchString(phone) {
			return nil
		}
		// Accept @g.us JIDs (group chats)
		if groupRegex.MatchString(phone) {
			return nil
		}
		// Accept @s.whatsapp.net JIDs (standard phone JIDs)
		suffix := phone[idx:]
		numberPart := phone[:idx]
		cleaned := strings.Map(func(r rune) rune {
			if r >= '0' && r <= '9' {
				return r
			}
			return -1
		}, numberPart)
		if phoneRegex.MatchString(cleaned + suffix) {
			return nil
		}
		return fmt.Errorf("invalid JID %q: expected format like 5511999999999@s.whatsapp.net, 123456@lid, or group-id@g.us", phone)
	}

	// No @ — treat as phone number. Strip +, spaces, dashes.
	cleaned := strings.Map(func(r rune) rune {
		if r >= '0' && r <= '9' {
			return r
		}
		return -1
	}, phone)

	if !phoneRegex.MatchString(cleaned) {
		return fmt.Errorf("invalid phone number %q: expected 10-15 digits (e.g. 5511999999999 or +55 11 99999-9999)", phone)
	}
	return nil
}

// ValidateFilePath checks that the file at path exists and is accessible.
func ValidateFilePath(path string) error {
	info, err := os.Stat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return fmt.Errorf("file not found: %s", path)
		}
		return fmt.Errorf("cannot access file %s: %w", path, err)
	}
	if info.IsDir() {
		return fmt.Errorf("path is a directory, not a file: %s", path)
	}
	return nil
}

// ValidateFileExtension checks that the file extension is in the allowed list.
// Extensions in allowed should include the leading dot (e.g. ".jpg").
func ValidateFileExtension(path string, allowed []string) error {
	ext := strings.ToLower(filepath.Ext(path))
	for _, a := range allowed {
		if ext == strings.ToLower(a) {
			return nil
		}
	}
	return fmt.Errorf("unsupported file extension %q for %s: allowed extensions are %s", ext, filepath.Base(path), strings.Join(allowed, ", "))
}

// ValidateRFC3339 checks that value is a valid RFC3339 timestamp.
// flagName is used in the error message to identify which flag is invalid.
func ValidateRFC3339(value, flagName string) error {
	_, err := time.Parse(time.RFC3339, value)
	if err != nil {
		return fmt.Errorf("invalid --%s value %q: expected RFC3339 format (e.g. 2024-01-15T10:30:00Z)", flagName, value)
	}
	return nil
}

// groupJIDPattern validates the format: digits-digits@g.us or digits@g.us
var groupJIDPattern = regexp.MustCompile(`^[\d]+-?\d+@g\.us$`)

// ValidateGroupJID checks that jid is a valid WhatsApp group JID.
// Format: digits-timestamp@g.us (e.g., 120363012345678901@g.us)
func ValidateGroupJID(jid string) error {
	if !groupJIDPattern.MatchString(jid) {
		return fmt.Errorf("invalid group JID %q: must match format digits-timestamp@g.us (e.g., 120363012345678901@g.us)", jid)
	}
	return nil
}

// ValidateGroupName checks that name is a valid WhatsApp group name (1-25 characters).
func ValidateGroupName(name string) error {
	if name == "" {
		return fmt.Errorf("group name is required")
	}
	if len(name) > 25 {
		return fmt.Errorf("group name too long (%d chars): WhatsApp allows max 25 characters", len(name))
	}
	return nil
}

// inviteCodeRegex validates WhatsApp invite codes: alphanumeric, 10-30 characters.
var inviteCodeRegex = regexp.MustCompile(`^[A-Za-z0-9]{10,30}$`)

// ParseInviteCode extracts the invite code from a WhatsApp invite URL or returns the input as-is.
// Returns the code and an error if the extracted code does not match the expected alphanumeric format.
func ParseInviteCode(input string) (string, error) {
	input = strings.TrimSpace(input)
	// Handle full URLs: https://chat.whatsapp.com/AbCdEfGhIjKl
	if strings.Contains(input, "chat.whatsapp.com/") {
		parts := strings.SplitAfter(input, "chat.whatsapp.com/")
		if len(parts) > 1 {
			input = strings.TrimSpace(parts[1])
		}
	}
	if !inviteCodeRegex.MatchString(input) {
		return "", fmt.Errorf("invalid invite code %q: expected 10-30 alphanumeric characters", input)
	}
	return input, nil
}
