package safety

import (
	"os"
	"path/filepath"
	"testing"
)

func TestValidatePhone_Valid(t *testing.T) {
	tests := []struct {
		name  string
		phone string
	}{
		{"bare digits", "5511999999999"},
		{"with plus", "+5511999999999"},
		{"with spaces and dashes", "+55 11 99999-9999"},
		{"JID format", "5511999999999@s.whatsapp.net"},
		{"plus and JID", "+5511999999999@s.whatsapp.net"},
		{"10 digits min", "1234567890"},
		{"15 digits max", "123456789012345"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := ValidatePhone(tt.phone); err != nil {
				t.Errorf("ValidatePhone(%q) = %v, want nil", tt.phone, err)
			}
		})
	}
}

func TestValidatePhone_Invalid(t *testing.T) {
	tests := []struct {
		name  string
		phone string
	}{
		{"too short", "123"},
		{"too long 16 digits", "1234567890123456"},
		{"empty", ""},
		{"no digits", "abcdef"},
		{"only plus", "+"},
		{"only spaces", "   "},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := ValidatePhone(tt.phone); err == nil {
				t.Errorf("ValidatePhone(%q) = nil, want error", tt.phone)
			}
		})
	}
}

func TestValidateFilePath_Valid(t *testing.T) {
	dir := t.TempDir()
	file := filepath.Join(dir, "test.txt")
	if err := os.WriteFile(file, []byte("hello"), 0600); err != nil {
		t.Fatal(err)
	}

	if err := ValidateFilePath(file); err != nil {
		t.Errorf("ValidateFilePath(%q) = %v, want nil", file, err)
	}
}

func TestValidateFilePath_NotFound(t *testing.T) {
	err := ValidateFilePath("/nonexistent/path/to/file.txt")
	if err == nil {
		t.Error("ValidateFilePath(nonexistent) = nil, want error")
	}
}

func TestValidateFilePath_IsDirectory(t *testing.T) {
	dir := t.TempDir()
	err := ValidateFilePath(dir)
	if err == nil {
		t.Errorf("ValidateFilePath(%q) = nil, want error for directory", dir)
	}
}

func TestValidateFileExtension_Valid(t *testing.T) {
	allowed := []string{".jpg", ".jpeg", ".png", ".gif", ".webp"}
	tests := []string{"photo.jpg", "image.JPEG", "pic.png", "anim.gif", "sticker.webp"}
	for _, name := range tests {
		if err := ValidateFileExtension(name, allowed); err != nil {
			t.Errorf("ValidateFileExtension(%q) = %v, want nil", name, err)
		}
	}
}

func TestValidateFileExtension_Invalid(t *testing.T) {
	allowed := []string{".jpg", ".png"}
	if err := ValidateFileExtension("doc.pdf", allowed); err == nil {
		t.Error("ValidateFileExtension(doc.pdf) = nil, want error")
	}
}

func TestValidateRFC3339_Valid(t *testing.T) {
	if err := ValidateRFC3339("2024-01-15T10:30:00Z", "since"); err != nil {
		t.Errorf("ValidateRFC3339(valid) = %v, want nil", err)
	}
}

func TestValidateRFC3339_Invalid(t *testing.T) {
	tests := []string{
		"not-a-date",
		"2024-01-15",
		"",
	}
	for _, v := range tests {
		if err := ValidateRFC3339(v, "since"); err == nil {
			t.Errorf("ValidateRFC3339(%q) = nil, want error", v)
		}
	}
}

func TestValidateGroupJID_Valid(t *testing.T) {
	tests := []string{
		"120363012345678901@g.us",
		"999999999@g.us",
	}
	for _, jid := range tests {
		if err := ValidateGroupJID(jid); err != nil {
			t.Errorf("ValidateGroupJID(%q) = %v, want nil", jid, err)
		}
	}
}

func TestValidateGroupJID_Invalid(t *testing.T) {
	tests := []struct {
		name string
		jid  string
	}{
		{"user JID", "5511999999999@s.whatsapp.net"},
		{"empty string", ""},
		{"no suffix", "120363012345678901"},
		{"wrong suffix", "120363012345678901@c.us"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := ValidateGroupJID(tt.jid); err == nil {
				t.Errorf("ValidateGroupJID(%q) = nil, want error", tt.jid)
			}
		})
	}
}

func TestValidateGroupName_Valid(t *testing.T) {
	tests := []struct {
		name  string
		input string
	}{
		{"single char", "A"},
		{"max 25 chars", "1234567890123456789012345"},
		{"normal name", "Dev Team"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := ValidateGroupName(tt.input); err != nil {
				t.Errorf("ValidateGroupName(%q) = %v, want nil", tt.input, err)
			}
		})
	}
}

func TestValidateGroupName_Invalid(t *testing.T) {
	tests := []struct {
		name  string
		input string
	}{
		{"empty", ""},
		{"26 chars", "12345678901234567890123456"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := ValidateGroupName(tt.input); err == nil {
				t.Errorf("ValidateGroupName(%q) = nil, want error", tt.input)
			}
		})
	}
}

func TestParseInviteCode_FullURL(t *testing.T) {
	tests := []struct {
		name    string
		input   string
		want    string
		wantErr bool
	}{
		{"https URL", "https://chat.whatsapp.com/AbCdEfGhIjKl", "AbCdEfGhIjKl", false},
		{"http URL", "http://chat.whatsapp.com/XyZ1234567890", "XyZ1234567890", false},
		{"code only", "AbCdEfGhIjKl", "AbCdEfGhIjKl", false},
		{"URL with trailing spaces", "https://chat.whatsapp.com/AbCdEfGhIjKl  ", "AbCdEfGhIjKl", false},
		{"code with spaces", "  AbCdEfGhIjKl  ", "AbCdEfGhIjKl", false},
		{"too short code", "abc", "", true},
		{"invalid chars", "abc!@#$%^&*()", "", true},
		{"empty string", "", "", true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseInviteCode(tt.input)
			if (err != nil) != tt.wantErr {
				t.Errorf("ParseInviteCode(%q) error = %v, wantErr %v", tt.input, err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("ParseInviteCode(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}
