package safety

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"math"
	"os"
	"path/filepath"
	"time"

	"github.com/gofrs/flock"
	"github.com/murilloimparavel/gowa-cli/internal/clierr"
)

// RateLimits defines the conservative message sending thresholds.
type RateLimits struct {
	PerMinute int
	PerHour   int
	PerDay    int
}

// DefaultLimits are intentionally conservative to protect WhatsApp accounts
// from being flagged or banned for spamming.
var DefaultLimits = RateLimits{
	PerMinute: 3,
	PerHour:   30,
	PerDay:    200,
}

// GroupLimits defines the rate thresholds for group create/join operations.
// More conservative than message sending because WhatsApp is stricter on group ops.
var GroupLimits = RateLimits{
	PerMinute: 0, // no per-minute limit for group ops
	PerHour:   5,
	PerDay:    20,
}

// rateLimitResult holds details when a limit is exceeded.
type rateLimitResult struct {
	count       int
	period      string
	waitSeconds int
}

// checkLimits evaluates timestamp counts against the provided limits and
// returns a rateLimitResult if any window is exceeded, or nil if all are
// within bounds. When a limit value is 0 that window is skipped (no limit).
func checkLimits(timestamps []string, now time.Time, limits RateLimits) *rateLimitResult {
	type window struct {
		duration time.Duration
		limit    int
		label    string
	}

	windows := []window{
		{time.Minute, limits.PerMinute, "minute"},
		{time.Hour, limits.PerHour, "hour"},
		// Design decision: "day" uses a rolling 24h window (not calendar day).
		// This avoids edge cases around midnight where a burst right before and
		// after 00:00 could bypass a calendar-day limit.
		{24 * time.Hour, limits.PerDay, "day"},
	}

	for _, w := range windows {
		if w.limit == 0 {
			continue // skip disabled windows
		}

		cutoff := now.Add(-w.duration)
		var count int
		var oldest time.Time

		for _, ts := range timestamps {
			t, err := time.Parse(time.RFC3339, ts)
			if err != nil {
				continue
			}
			if !t.Before(cutoff) {
				count++
				if oldest.IsZero() || t.Before(oldest) {
					oldest = t
				}
			}
		}

		if count >= w.limit {
			// Calculate wait: time until the oldest entry in this window expires.
			waitSeconds := int(math.Ceil(w.duration.Seconds() - now.Sub(oldest).Seconds()))
			if waitSeconds < 1 {
				waitSeconds = 1
			}
			return &rateLimitResult{
				count:       count,
				period:      w.label,
				waitSeconds: waitSeconds,
			}
		}
	}

	return nil
}

// CheckAndRecordSend atomically checks the rate limit and records a new send
// under a single file lock acquisition, eliminating the TOCTOU race that would
// exist if CheckRateLimit and RecordSend were called separately. Expired
// entries are cleaned before saving so the state file stays compact.
func CheckAndRecordSend(statePath string) error {
	// 1. Acquire file lock directly (not via LoadState/SaveState).
	lock := flock.New(statePath + ".lock")
	if err := lock.Lock(); err != nil {
		return fmt.Errorf("acquiring lock: %w", err)
	}
	defer lock.Unlock()

	// 2. Read state file directly.
	var state State
	data, err := os.ReadFile(statePath)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("reading state file: %w", err)
		}
		state.MessagesSent = []string{}
	} else {
		if err := json.Unmarshal(data, &state); err != nil {
			// State file is corrupted — auto-recover like LoadState does
			slog.Warn("state file corrupted in CheckAndRecordSend, resetting to empty state",
				"path", statePath,
				"error", err,
			)
			corruptedPath := statePath + ".corrupted"
			_ = os.Rename(statePath, corruptedPath)

			auditPath := filepath.Join(filepath.Dir(statePath), "audit.log")
			LogSendOperationTo(auditPath, AuditEntry{
				Timestamp:    time.Now().UTC().Format(time.RFC3339),
				Operation:    "state_corruption_recovery",
				Result:       "auto_reset",
				ErrorMessage: fmt.Sprintf("corrupted state renamed to %s: %v", corruptedPath, err),
			})

			state.MessagesSent = []string{}
		}
		if state.MessagesSent == nil {
			state.MessagesSent = []string{}
		}
	}

	// 3. Clean expired entries (FIX 2: cleaned state will be saved below).
	state.CleanExpiredEntries()

	// 4. Check rate limits.
	now := time.Now().UTC()
	result := checkLimits(state.MessagesSent, now, DefaultLimits)
	if result != nil {
		return rateLimitError(result)
	}

	// 5. Record: append current timestamp.
	state.MessagesSent = append(state.MessagesSent, now.Format(time.RFC3339))

	// 6. Save state atomically (temp file + rename) without SaveState's own lock.
	dir := filepath.Dir(statePath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return fmt.Errorf("creating state directory: %w", err)
	}

	out, err := json.MarshalIndent(&state, "", "  ")
	if err != nil {
		return fmt.Errorf("marshaling state: %w", err)
	}

	tmpFile := statePath + ".tmp"
	f, err := os.OpenFile(tmpFile, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if err != nil {
		return fmt.Errorf("creating temp file: %w", err)
	}
	if _, err := f.Write(out); err != nil {
		f.Close()
		os.Remove(tmpFile)
		return fmt.Errorf("writing temp file: %w", err)
	}
	if err := f.Sync(); err != nil {
		f.Close()
		os.Remove(tmpFile)
		return fmt.Errorf("syncing temp file: %w", err)
	}
	f.Close()

	if err := os.Rename(tmpFile, statePath); err != nil {
		os.Remove(tmpFile) // best-effort cleanup
		return fmt.Errorf("renaming temp file: %w", err)
	}

	return nil
}

// rateLimitError constructs a *clierr.CLIError with exit code 6 from a
// rateLimitResult so that agents can programmatically detect rate limiting.
func rateLimitError(r *rateLimitResult) *clierr.CLIError {
	return &clierr.CLIError{
		Type: "rate_limit",
		Code: 6,
		Message: fmt.Sprintf(
			"Rate limit exceeded: %d messages sent in last %s. Wait %d seconds before sending again.",
			r.count, r.period, r.waitSeconds,
		),
		Recovery: "Wait before sending again, or check limits with: gowa send text --dry-run",
	}
}

// CheckAndRecordGroupOp atomically checks the group rate limit and records a
// new group operation (create or join) under a single file lock acquisition.
func CheckAndRecordGroupOp(statePath string, opType string) error {
	// 1. Acquire file lock directly (not via LoadState/SaveState).
	lock := flock.New(statePath + ".lock")
	if err := lock.Lock(); err != nil {
		return fmt.Errorf("acquiring lock: %w", err)
	}
	defer lock.Unlock()

	// 2. Read state file directly.
	var state State
	data, err := os.ReadFile(statePath)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			return fmt.Errorf("reading state file: %w", err)
		}
		state.MessagesSent = []string{}
	} else {
		if err := json.Unmarshal(data, &state); err != nil {
			slog.Warn("state file corrupted in CheckAndRecordGroupOp, resetting to empty state",
				"path", statePath,
				"error", err,
			)
			corruptedPath := statePath + ".corrupted"
			_ = os.Rename(statePath, corruptedPath)

			auditPath := filepath.Join(filepath.Dir(statePath), "audit.log")
			LogSendOperationTo(auditPath, AuditEntry{
				Timestamp:    time.Now().UTC().Format(time.RFC3339),
				Operation:    "state_corruption_recovery",
				Result:       "auto_reset",
				ErrorMessage: fmt.Sprintf("corrupted state renamed to %s: %v", corruptedPath, err),
			})

			state.MessagesSent = []string{}
		}
		if state.MessagesSent == nil {
			state.MessagesSent = []string{}
		}
	}

	// 3. Clean expired entries.
	state.CleanExpiredEntries()

	// 4. Select timestamps array based on opType.
	var timestamps *[]string
	switch opType {
	case "group_create":
		timestamps = &state.GroupCreateTimestamps
	case "group_join":
		timestamps = &state.GroupJoinTimestamps
	default:
		return fmt.Errorf("unknown group op type: %s", opType)
	}

	// 5. Check rate limits.
	now := time.Now().UTC()
	result := checkLimits(*timestamps, now, GroupLimits)
	if result != nil {
		return groupRateLimitError(result, opType)
	}

	// 6. Record: append current timestamp.
	*timestamps = append(*timestamps, now.Format(time.RFC3339))

	// 7. Save state atomically (temp file + rename) without SaveState's own lock.
	dir := filepath.Dir(statePath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return fmt.Errorf("creating state directory: %w", err)
	}

	out, err := json.MarshalIndent(&state, "", "  ")
	if err != nil {
		return fmt.Errorf("marshaling state: %w", err)
	}

	tmpFile := statePath + ".tmp"
	f2, err := os.OpenFile(tmpFile, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if err != nil {
		return fmt.Errorf("creating temp file: %w", err)
	}
	if _, err := f2.Write(out); err != nil {
		f2.Close()
		os.Remove(tmpFile)
		return fmt.Errorf("writing temp file: %w", err)
	}
	if err := f2.Sync(); err != nil {
		f2.Close()
		os.Remove(tmpFile)
		return fmt.Errorf("syncing temp file: %w", err)
	}
	f2.Close()

	if err := os.Rename(tmpFile, statePath); err != nil {
		os.Remove(tmpFile) // best-effort cleanup
		return fmt.Errorf("renaming temp file: %w", err)
	}

	return nil
}

// groupRateLimitError constructs a *clierr.CLIError with exit code 6 from a
// rateLimitResult for group operations.
func groupRateLimitError(r *rateLimitResult, opType string) *clierr.CLIError {
	return &clierr.CLIError{
		Type: "rate_limit",
		Code: 6,
		Message: fmt.Sprintf(
			"Rate limit exceeded: %d %s operations in last %s. Wait %d seconds.",
			r.count, opType, r.period, r.waitSeconds,
		),
		Recovery: fmt.Sprintf("Wait before trying again. Limit: %d/hour, %d/day for %s",
			GroupLimits.PerHour, GroupLimits.PerDay, opType),
	}
}

// RateStatus holds the remaining quota for each time window.
type RateStatus struct {
	MinuteRemaining int `json:"minute_remaining"`
	HourRemaining   int `json:"hour_remaining"`
	DayRemaining    int `json:"day_remaining"`
	MinuteLimit     int `json:"minute_limit"`
	HourLimit       int `json:"hour_limit"`
	DayLimit        int `json:"day_limit"`
	// Group operation counters
	GroupCreateHourRemaining int `json:"group_create_hour_remaining"`
	GroupCreateDayRemaining  int `json:"group_create_day_remaining"`
	GroupJoinHourRemaining   int `json:"group_join_hour_remaining"`
	GroupJoinDayRemaining    int `json:"group_join_day_remaining"`
	GroupHourLimit           int `json:"group_hour_limit"`
	GroupDayLimit            int `json:"group_day_limit"`
}

// GetRateStatus returns remaining quotas for each rate limit window.
func GetRateStatus(statePath string) (*RateStatus, error) {
	state, err := LoadState(statePath)
	if err != nil {
		return nil, fmt.Errorf("loading state: %w", err)
	}
	state.CleanExpiredEntries()

	now := time.Now().UTC()

	countInWindow := func(timestamps []string, d time.Duration) int {
		cutoff := now.Add(-d)
		count := 0
		for _, ts := range timestamps {
			t, err := time.Parse(time.RFC3339, ts)
			if err != nil {
				continue
			}
			if !t.Before(cutoff) {
				count++
			}
		}
		return count
	}

	return &RateStatus{
		MinuteRemaining:          max(0, DefaultLimits.PerMinute-countInWindow(state.MessagesSent, time.Minute)),
		HourRemaining:            max(0, DefaultLimits.PerHour-countInWindow(state.MessagesSent, time.Hour)),
		DayRemaining:             max(0, DefaultLimits.PerDay-countInWindow(state.MessagesSent, 24*time.Hour)),
		MinuteLimit:              DefaultLimits.PerMinute,
		HourLimit:                DefaultLimits.PerHour,
		DayLimit:                 DefaultLimits.PerDay,
		GroupCreateHourRemaining: max(0, GroupLimits.PerHour-countInWindow(state.GroupCreateTimestamps, time.Hour)),
		GroupCreateDayRemaining:  max(0, GroupLimits.PerDay-countInWindow(state.GroupCreateTimestamps, 24*time.Hour)),
		GroupJoinHourRemaining:   max(0, GroupLimits.PerHour-countInWindow(state.GroupJoinTimestamps, time.Hour)),
		GroupJoinDayRemaining:    max(0, GroupLimits.PerDay-countInWindow(state.GroupJoinTimestamps, 24*time.Hour)),
		GroupHourLimit:           GroupLimits.PerHour,
		GroupDayLimit:            GroupLimits.PerDay,
	}, nil
}

