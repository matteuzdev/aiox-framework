package safety

import (
	"fmt"
	"math"
	"math/rand"
	"sync"
	"time"
)

// CircuitState represents the current state of the circuit breaker.
type CircuitState string

const (
	CircuitClosed   CircuitState = "closed"   // normal operation
	CircuitOpen     CircuitState = "open"     // failures exceeded threshold, blocking
	CircuitHalfOpen CircuitState = "half_open" // testing if service recovered
)

// CircuitBreaker prevents aggressive reconnection loops.
// After consecutive failures within a window, it "opens" and blocks further attempts
// for a cooldown period. This prevents WhatsApp from interpreting reconnection
// attempts as abusive behavior.
//
// NOTE: CircuitBreaker is intentionally in-memory only. All state (failure count,
// circuit state, timestamps) resets when the process restarts. This is by design:
// a fresh process should be allowed to attempt connections without carrying over
// stale failure state from a previous run.
type CircuitBreaker struct {
	mu              sync.Mutex
	state           CircuitState
	failures        int
	lastFailure     time.Time
	openedAt        time.Time
	maxFailures     int           // consecutive failures to trigger open (default 5)
	failureWindow   time.Duration // window for counting failures (default 30min)
	cooldownPeriod  time.Duration // how long to stay open (default 30min)
}

// NewCircuitBreaker creates a circuit breaker with the given thresholds.
func NewCircuitBreaker(maxFailures int, failureWindow, cooldownPeriod time.Duration) *CircuitBreaker {
	if maxFailures <= 0 {
		maxFailures = 5
	}
	if failureWindow <= 0 {
		failureWindow = 30 * time.Minute
	}
	if cooldownPeriod <= 0 {
		cooldownPeriod = 30 * time.Minute
	}

	return &CircuitBreaker{
		state:          CircuitClosed,
		maxFailures:    maxFailures,
		failureWindow:  failureWindow,
		cooldownPeriod: cooldownPeriod,
	}
}

// Allow returns nil if the operation is allowed, or an error if the circuit is open.
func (cb *CircuitBreaker) Allow() error {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	switch cb.state {
	case CircuitClosed:
		return nil
	case CircuitOpen:
		if time.Since(cb.openedAt) > cb.cooldownPeriod {
			cb.state = CircuitHalfOpen
			return nil
		}
		remaining := cb.cooldownPeriod - time.Since(cb.openedAt)
		return fmt.Errorf("circuit breaker open: too many connection failures. Retry in %s", remaining.Truncate(time.Second))
	case CircuitHalfOpen:
		return nil
	}
	return nil
}

// RecordSuccess records a successful operation.
func (cb *CircuitBreaker) RecordSuccess() {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	cb.failures = 0
	cb.state = CircuitClosed
}

// RecordFailure records a failed operation.
func (cb *CircuitBreaker) RecordFailure() {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	now := time.Now()

	// Reset failures if outside window
	if cb.failures > 0 && now.Sub(cb.lastFailure) > cb.failureWindow {
		cb.failures = 0
	}

	cb.failures++
	cb.lastFailure = now

	if cb.failures >= cb.maxFailures {
		cb.state = CircuitOpen
		cb.openedAt = now
	}
}

// State returns the current circuit state.
func (cb *CircuitBreaker) State() CircuitState {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	// Auto-transition from open to half-open
	if cb.state == CircuitOpen && time.Since(cb.openedAt) > cb.cooldownPeriod {
		cb.state = CircuitHalfOpen
	}
	return cb.state
}

// Failures returns the current consecutive failure count.
func (cb *CircuitBreaker) Failures() int {
	cb.mu.Lock()
	defer cb.mu.Unlock()
	return cb.failures
}

// ExponentialBackoff calculates the backoff duration for a given attempt.
// Uses exponential backoff with 0-20% jitter.
func ExponentialBackoff(attempt int, maxBackoff time.Duration) time.Duration {
	if maxBackoff <= 0 {
		maxBackoff = 5 * time.Minute
	}

	// Base backoff: 2^attempt seconds, starting at 2s.
	// Guard against overflow: math.Pow(2, float64(attempt+1)) can exceed
	// float64 precision or Duration range for large attempt values.
	base := math.Pow(2, float64(attempt+1))
	if base > maxBackoff.Seconds() {
		return maxBackoff
	}
	backoff := time.Duration(base) * time.Second

	if backoff > maxBackoff {
		backoff = maxBackoff
	}

	// Add 0-20% jitter
	jitter := time.Duration(float64(backoff) * 0.2 * rand.Float64())
	return backoff + jitter
}
