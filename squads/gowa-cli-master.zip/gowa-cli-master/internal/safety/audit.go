package safety

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/gofrs/flock"
)

// maxAuditSize is the maximum audit log file size before rotation (1 MB).
const maxAuditSize = 1 * 1024 * 1024

// AuditEntry represents a single audit log record for a send operation.
type AuditEntry struct {
	Timestamp    string `json:"timestamp"`
	Operation    string `json:"operation"`
	Recipient    string `json:"recipient"`
	Result       string `json:"result"`
	ErrorMessage string `json:"error_message,omitempty"`
}

// DefaultAuditPath returns the default path for the audit log:
// ~/.config/gowa/audit.log
func DefaultAuditPath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		home = "."
	}
	return filepath.Join(home, ".config", "gowa", "audit.log")
}

// LogSendOperation appends an audit entry to the default audit log.
func LogSendOperation(entry AuditEntry) error {
	return LogSendOperationTo(DefaultAuditPath(), entry)
}

// LogSendOperationTo appends an audit entry to the given audit log path.
// It uses file locking for safe concurrent access and performs simple rotation
// when the file exceeds 1 MB.
func LogSendOperationTo(auditPath string, entry AuditEntry) error {
	lock := flock.New(auditPath + ".lock")
	if err := lock.Lock(); err != nil {
		return fmt.Errorf("acquiring audit lock: %w", err)
	}
	defer lock.Unlock()

	// Ensure directory exists.
	dir := filepath.Dir(auditPath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return fmt.Errorf("creating audit directory: %w", err)
	}

	// Check file size for rotation.
	if info, err := os.Stat(auditPath); err == nil && info.Size() > maxAuditSize {
		// Rotate: preserve .1 as .2 before overwriting.
		_ = os.Rename(auditPath+".1", auditPath+".2")
		_ = os.Rename(auditPath, auditPath+".1")
	}

	// Marshal entry as compact JSON (single line).
	data, err := json.Marshal(entry)
	if err != nil {
		return fmt.Errorf("marshaling audit entry: %w", err)
	}

	// Append to file.
	f, err := os.OpenFile(auditPath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return fmt.Errorf("opening audit log: %w", err)
	}
	defer f.Close()

	if _, err := f.Write(append(data, '\n')); err != nil {
		return fmt.Errorf("writing audit entry: %w", err)
	}

	return nil
}
