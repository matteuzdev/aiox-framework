package safety

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"time"

	"github.com/gofrs/flock"
)

// State holds persistent rate limiter state across CLI invocations.
type State struct {
	MessagesSent          []string `json:"messages_sent"`
	GroupCreateTimestamps []string `json:"group_create_timestamps,omitempty"`
	GroupJoinTimestamps   []string `json:"group_join_timestamps,omitempty"`
}

// DefaultStatePath returns the default path for the state file:
// ~/.config/gowa/state.json
func DefaultStatePath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		home = "."
	}
	return filepath.Join(home, ".config", "gowa", "state.json")
}

// LoadState reads the state from the given path. If the file does not exist,
// it returns an empty State. File locking is used for safe concurrent access.
func LoadState(statePath string) (*State, error) {
	lock := flock.New(statePath + ".lock")
	if err := lock.Lock(); err != nil {
		return nil, fmt.Errorf("acquiring lock: %w", err)
	}
	defer lock.Unlock()

	data, err := os.ReadFile(statePath)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return &State{MessagesSent: []string{}}, nil
		}
		return nil, fmt.Errorf("reading state file: %w", err)
	}

	var state State
	if err := json.Unmarshal(data, &state); err != nil {
		// State file is corrupted — rename to .corrupted and reset
		slog.Warn("state file corrupted, resetting to empty state",
			"path", statePath,
			"error", err,
		)
		corruptedPath := statePath + ".corrupted"
		_ = os.Rename(statePath, corruptedPath)

		// Log corruption event to audit log
		auditPath := filepath.Join(filepath.Dir(statePath), "audit.log")
		LogSendOperationTo(auditPath, AuditEntry{
			Timestamp:    time.Now().UTC().Format(time.RFC3339),
			Operation:    "state_corruption_recovery",
			Result:       "auto_reset",
			ErrorMessage: fmt.Sprintf("corrupted state renamed to %s: %v", corruptedPath, err),
		})

		return &State{MessagesSent: []string{}}, nil
	}

	if state.MessagesSent == nil {
		state.MessagesSent = []string{}
	}

	return &state, nil
}

// SaveState writes the state atomically to the given path using a temp file
// and os.Rename. The file is created with permission 0600. File locking is
// used for safe concurrent access.
func SaveState(statePath string, state *State) error {
	lock := flock.New(statePath + ".lock")
	if err := lock.Lock(); err != nil {
		return fmt.Errorf("acquiring lock: %w", err)
	}
	defer lock.Unlock()

	dir := filepath.Dir(statePath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return fmt.Errorf("creating state directory: %w", err)
	}

	data, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return fmt.Errorf("marshaling state: %w", err)
	}

	tmpFile := statePath + ".tmp"
	f, err := os.OpenFile(tmpFile, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if err != nil {
		return fmt.Errorf("creating temp file: %w", err)
	}
	if _, err := f.Write(data); err != nil {
		f.Close()
		os.Remove(tmpFile)
		return fmt.Errorf("writing temp file: %w", err)
	}
	if err := f.Sync(); err != nil {
		f.Close()
		os.Remove(tmpFile)
		return fmt.Errorf("syncing temp file: %w", err)
	}
	f.Close()

	if err := os.Rename(tmpFile, statePath); err != nil {
		os.Remove(tmpFile) // best-effort cleanup
		return fmt.Errorf("renaming temp file: %w", err)
	}

	return nil
}

// CleanExpiredEntries removes timestamps older than 24 hours from
// MessagesSent, GroupCreateTimestamps, and GroupJoinTimestamps.
func (s *State) CleanExpiredEntries() {
	cutoff := time.Now().UTC().Add(-24 * time.Hour)

	s.MessagesSent = cleanTimestamps(s.MessagesSent, cutoff)
	s.GroupCreateTimestamps = cleanTimestamps(s.GroupCreateTimestamps, cutoff)
	s.GroupJoinTimestamps = cleanTimestamps(s.GroupJoinTimestamps, cutoff)
}

// cleanTimestamps filters a slice of RFC3339 timestamps, keeping only those
// at or after the cutoff. Unparseable entries are discarded to prevent
// unbounded accumulation of malformed data.
func cleanTimestamps(timestamps []string, cutoff time.Time) []string {
	kept := make([]string, 0, len(timestamps))
	for _, ts := range timestamps {
		t, err := time.Parse(time.RFC3339, ts)
		if err != nil {
			slog.Warn("discarding unparseable timestamp during cleanup",
				"value", ts,
			)
			continue
		}
		if !t.Before(cutoff) {
			kept = append(kept, ts)
		}
	}
	return kept
}
