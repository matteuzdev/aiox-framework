package safety

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
)

func TestCheckAndRecordSend_AllowsWithinLimit(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	// Empty state (no file) — should allow.
	if err := CheckAndRecordSend(statePath); err != nil {
		t.Fatalf("expected nil error for empty state, got: %v", err)
	}
}

func TestCheckAndRecordSend_BlocksPerMinute(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	// Fill with 3 timestamps within the last minute (hits PerMinute=3 limit).
	now := time.Now().UTC()
	timestamps := make([]string, DefaultLimits.PerMinute)
	for i := range timestamps {
		timestamps[i] = now.Add(-time.Duration(i*10) * time.Second).Format(time.RFC3339)
	}
	writeState(t, statePath, timestamps)

	err := CheckAndRecordSend(statePath)
	if err == nil {
		t.Fatal("expected rate limit error, got nil")
	}
	if !strings.Contains(err.Error(), "minute") {
		t.Errorf("error should mention 'minute', got: %v", err)
	}
	assertCLIErrorCode(t, err, 6)
}

func TestCheckAndRecordSend_BlocksPerHour(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	// Fill with 30 timestamps spread across the last hour.
	now := time.Now().UTC()
	timestamps := make([]string, DefaultLimits.PerHour)
	for i := range timestamps {
		offset := time.Duration(i) * 2 * time.Minute
		timestamps[i] = now.Add(-offset).Format(time.RFC3339)
	}
	writeState(t, statePath, timestamps)

	err := CheckAndRecordSend(statePath)
	if err == nil {
		t.Fatal("expected rate limit error, got nil")
	}
	if !strings.Contains(err.Error(), "Rate limit exceeded") {
		t.Errorf("error should contain 'Rate limit exceeded', got: %v", err)
	}
	assertCLIErrorCode(t, err, 6)
}

func TestCheckAndRecordSend_BlocksPerDay(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	// Fill with 200 timestamps spread across 24h.
	now := time.Now().UTC()
	timestamps := make([]string, DefaultLimits.PerDay)
	for i := range timestamps {
		offset := time.Duration(i) * 7 * time.Minute
		timestamps[i] = now.Add(-offset).Format(time.RFC3339)
	}
	writeState(t, statePath, timestamps)

	err := CheckAndRecordSend(statePath)
	if err == nil {
		t.Fatal("expected rate limit error, got nil")
	}
	if !strings.Contains(err.Error(), "Rate limit exceeded") {
		t.Errorf("error should contain 'Rate limit exceeded', got: %v", err)
	}
	assertCLIErrorCode(t, err, 6)
}

func TestCheckAndRecordSend_ErrorFormat(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	now := time.Now().UTC()
	timestamps := make([]string, DefaultLimits.PerMinute)
	for i := range timestamps {
		timestamps[i] = now.Add(-time.Duration(i*5) * time.Second).Format(time.RFC3339)
	}
	writeState(t, statePath, timestamps)

	err := CheckAndRecordSend(statePath)
	if err == nil {
		t.Fatal("expected error, got nil")
	}

	msg := err.Error()
	if !strings.Contains(msg, "Rate limit exceeded") {
		t.Errorf("error should contain 'Rate limit exceeded', got: %s", msg)
	}
	if !strings.Contains(msg, "messages sent in last") {
		t.Errorf("error should contain 'messages sent in last', got: %s", msg)
	}

	var cliErr *clierr.CLIError
	if !errors.As(err, &cliErr) {
		t.Fatalf("expected *clierr.CLIError, got %T", err)
	}
	if cliErr.Code != 6 {
		t.Errorf("expected Code 6, got %d", cliErr.Code)
	}
	if cliErr.Type != "rate_limit" {
		t.Errorf("expected Type 'rate_limit', got %q", cliErr.Type)
	}
	if cliErr.Recovery == "" {
		t.Error("expected non-empty Recovery hint")
	}
}

func TestCheckAndRecordSend_RecordsTimestamp(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	if err := CheckAndRecordSend(statePath); err != nil {
		t.Fatalf("CheckAndRecordSend: %v", err)
	}

	state, err := LoadState(statePath)
	if err != nil {
		t.Fatalf("LoadState: %v", err)
	}
	if len(state.MessagesSent) != 1 {
		t.Fatalf("expected 1 entry after record, got %d", len(state.MessagesSent))
	}

	ts, err := time.Parse(time.RFC3339, state.MessagesSent[0])
	if err != nil {
		t.Fatalf("recorded timestamp is not RFC3339: %v", err)
	}
	if time.Since(ts) > 5*time.Second {
		t.Errorf("recorded timestamp is too old: %v", ts)
	}
}

func TestCheckAndRecordSend_BlocksAndDoesNotRecord(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	// Pre-fill with PerMinute timestamps.
	now := time.Now().UTC()
	timestamps := make([]string, DefaultLimits.PerMinute)
	for i := range timestamps {
		timestamps[i] = now.Add(-time.Duration(i*5) * time.Second).Format(time.RFC3339)
	}
	writeState(t, statePath, timestamps)

	err := CheckAndRecordSend(statePath)
	if err == nil {
		t.Fatal("expected rate limit error, got nil")
	}
	assertCLIErrorCode(t, err, 6)

	// Verify no new entry was added.
	state, err := LoadState(statePath)
	if err != nil {
		t.Fatalf("LoadState: %v", err)
	}
	if len(state.MessagesSent) != DefaultLimits.PerMinute {
		t.Errorf("expected %d entries (unchanged), got %d", DefaultLimits.PerMinute, len(state.MessagesSent))
	}
}

// assertCLIErrorCode verifies the error is a *clierr.CLIError with the expected exit code.
func assertCLIErrorCode(t *testing.T, err error, expectedCode int) {
	t.Helper()
	var cliErr *clierr.CLIError
	if !errors.As(err, &cliErr) {
		t.Fatalf("expected *clierr.CLIError, got %T: %v", err, err)
	}
	if cliErr.Code != expectedCode {
		t.Errorf("expected exit code %d, got %d", expectedCode, cliErr.Code)
	}
	if cliErr.Type != "rate_limit" {
		t.Errorf("expected Type 'rate_limit', got %q", cliErr.Type)
	}
}

// writeState writes a state file with the given message timestamps.
func writeState(t *testing.T, statePath string, timestamps []string) {
	t.Helper()
	writeStateFull(t, statePath, &State{MessagesSent: timestamps})
}

// writeStateFull writes a full State struct to the given path.
func writeStateFull(t *testing.T, statePath string, state *State) {
	t.Helper()
	data, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		t.Fatalf("marshal state: %v", err)
	}
	dir := filepath.Dir(statePath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatalf("mkdir: %v", err)
	}
	if err := os.WriteFile(statePath, data, 0600); err != nil {
		t.Fatalf("write state: %v", err)
	}
}

// readState reads a State from the given path.
func readState(t *testing.T, statePath string) *State {
	t.Helper()
	data, err := os.ReadFile(statePath)
	if err != nil {
		t.Fatalf("read state: %v", err)
	}
	var s State
	if err := json.Unmarshal(data, &s); err != nil {
		t.Fatalf("unmarshal state: %v", err)
	}
	return &s
}

func TestCheckAndRecordGroupOp_CreateAllowsUpTo5PerHour(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	// Should allow 5 group_create operations
	for i := 0; i < 5; i++ {
		if err := CheckAndRecordGroupOp(statePath, "group_create"); err != nil {
			t.Fatalf("iteration %d: unexpected error: %v", i, err)
		}
	}

	// 6th should fail
	err := CheckAndRecordGroupOp(statePath, "group_create")
	if err == nil {
		t.Fatal("expected rate limit error on 6th group_create, got nil")
	}
	assertCLIErrorCode(t, err, 6)
}

func TestCheckAndRecordGroupOp_JoinAllowsUpTo5PerHour(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	for i := 0; i < 5; i++ {
		if err := CheckAndRecordGroupOp(statePath, "group_join"); err != nil {
			t.Fatalf("iteration %d: unexpected error: %v", i, err)
		}
	}

	err := CheckAndRecordGroupOp(statePath, "group_join")
	if err == nil {
		t.Fatal("expected rate limit error on 6th group_join, got nil")
	}
	assertCLIErrorCode(t, err, 6)
}

func TestCheckAndRecordGroupOp_RateLimitErrorFormat(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	for i := 0; i < GroupLimits.PerHour; i++ {
		if err := CheckAndRecordGroupOp(statePath, "group_create"); err != nil {
			t.Fatalf("iteration %d: %v", i, err)
		}
	}

	err := CheckAndRecordGroupOp(statePath, "group_create")
	if err == nil {
		t.Fatal("expected error")
	}

	var cliErr *clierr.CLIError
	if !errors.As(err, &cliErr) {
		t.Fatalf("expected *clierr.CLIError, got %T", err)
	}
	if cliErr.Code != 6 {
		t.Errorf("expected code 6, got %d", cliErr.Code)
	}
	if cliErr.Type != "rate_limit" {
		t.Errorf("expected type rate_limit, got %s", cliErr.Type)
	}
	if !strings.Contains(cliErr.Message, "group_create") {
		t.Errorf("expected message to contain 'group_create', got: %s", cliErr.Message)
	}
	if cliErr.Recovery == "" {
		t.Error("expected non-empty Recovery hint")
	}
}

func TestCheckAndRecordGroupOp_GroupAndMessageCountersIndependent(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	// Fill group_create hourly limit
	for i := 0; i < GroupLimits.PerHour; i++ {
		if err := CheckAndRecordGroupOp(statePath, "group_create"); err != nil {
			t.Fatalf("group_create %d: %v", i, err)
		}
	}

	// Message sends should still work
	if err := CheckAndRecordSend(statePath); err != nil {
		t.Fatalf("CheckAndRecordSend should succeed: %v", err)
	}

	// group_join should also still work (independent from group_create)
	if err := CheckAndRecordGroupOp(statePath, "group_join"); err != nil {
		t.Fatalf("group_join should succeed: %v", err)
	}

	// Verify state
	s := readState(t, statePath)
	if len(s.GroupCreateTimestamps) != GroupLimits.PerHour {
		t.Errorf("expected %d group_create timestamps, got %d", GroupLimits.PerHour, len(s.GroupCreateTimestamps))
	}
	if len(s.MessagesSent) != 1 {
		t.Errorf("expected 1 message timestamp, got %d", len(s.MessagesSent))
	}
	if len(s.GroupJoinTimestamps) != 1 {
		t.Errorf("expected 1 group_join timestamp, got %d", len(s.GroupJoinTimestamps))
	}
}

func TestCheckAndRecordGroupOp_InvalidOpType(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	err := CheckAndRecordGroupOp(statePath, "invalid_op")
	if err == nil {
		t.Fatal("expected error for invalid opType, got nil")
	}
	if !strings.Contains(err.Error(), "unknown group op type") {
		t.Errorf("expected 'unknown group op type' in error, got: %v", err)
	}
}

func TestGetRateStatus_IncludesGroupCounters(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	now := time.Now().UTC()
	state := &State{
		MessagesSent:          []string{now.Format(time.RFC3339)},
		GroupCreateTimestamps: []string{now.Format(time.RFC3339), now.Format(time.RFC3339)},
		GroupJoinTimestamps:   []string{now.Format(time.RFC3339)},
	}
	writeStateFull(t, statePath, state)

	status, err := GetRateStatus(statePath)
	if err != nil {
		t.Fatalf("GetRateStatus: %v", err)
	}

	// Message counters
	if status.MinuteRemaining != DefaultLimits.PerMinute-1 {
		t.Errorf("MinuteRemaining: expected %d, got %d", DefaultLimits.PerMinute-1, status.MinuteRemaining)
	}

	// Group counters
	if status.GroupCreateHourRemaining != GroupLimits.PerHour-2 {
		t.Errorf("GroupCreateHourRemaining: expected %d, got %d", GroupLimits.PerHour-2, status.GroupCreateHourRemaining)
	}
	if status.GroupCreateDayRemaining != GroupLimits.PerDay-2 {
		t.Errorf("GroupCreateDayRemaining: expected %d, got %d", GroupLimits.PerDay-2, status.GroupCreateDayRemaining)
	}
	if status.GroupJoinHourRemaining != GroupLimits.PerHour-1 {
		t.Errorf("GroupJoinHourRemaining: expected %d, got %d", GroupLimits.PerHour-1, status.GroupJoinHourRemaining)
	}
	if status.GroupJoinDayRemaining != GroupLimits.PerDay-1 {
		t.Errorf("GroupJoinDayRemaining: expected %d, got %d", GroupLimits.PerDay-1, status.GroupJoinDayRemaining)
	}
	if status.GroupHourLimit != GroupLimits.PerHour {
		t.Errorf("GroupHourLimit: expected %d, got %d", GroupLimits.PerHour, status.GroupHourLimit)
	}
	if status.GroupDayLimit != GroupLimits.PerDay {
		t.Errorf("GroupDayLimit: expected %d, got %d", GroupLimits.PerDay, status.GroupDayLimit)
	}
}
