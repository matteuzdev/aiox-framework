package safety

import (
	"testing"
	"time"
)

func TestCircuitBreaker_StartsClased(t *testing.T) {
	cb := NewCircuitBreaker(5, 30*time.Minute, 30*time.Minute)
	if cb.State() != CircuitClosed {
		t.Errorf("initial state = %s, want closed", cb.State())
	}
	if err := cb.Allow(); err != nil {
		t.Errorf("should allow when closed: %v", err)
	}
}

func TestCircuitBreaker_OpensAfterMaxFailures(t *testing.T) {
	cb := NewCircuitBreaker(3, time.Hour, time.Hour)

	cb.RecordFailure()
	cb.RecordFailure()

	// Not yet at threshold
	if cb.State() != CircuitClosed {
		t.Errorf("state = %s after 2 failures, want closed", cb.State())
	}

	cb.RecordFailure() // 3rd failure = threshold

	if cb.State() != CircuitOpen {
		t.Errorf("state = %s after 3 failures, want open", cb.State())
	}

	if err := cb.Allow(); err == nil {
		t.Error("should block when open")
	}
}

func TestCircuitBreaker_ResetsOnSuccess(t *testing.T) {
	cb := NewCircuitBreaker(3, time.Hour, time.Hour)

	cb.RecordFailure()
	cb.RecordFailure()
	cb.RecordSuccess() // resets counter

	cb.RecordFailure() // only 1 failure after reset

	if cb.State() != CircuitClosed {
		t.Errorf("state = %s, want closed (success should reset)", cb.State())
	}
}

func TestCircuitBreaker_FailuresExpireOutsideWindow(t *testing.T) {
	cb := NewCircuitBreaker(3, 100*time.Millisecond, time.Hour)

	cb.RecordFailure()
	cb.RecordFailure()

	time.Sleep(150 * time.Millisecond) // outside window

	cb.RecordFailure() // counter resets, only 1 now

	if cb.State() != CircuitClosed {
		t.Errorf("state = %s, want closed (failures expired)", cb.State())
	}
}

func TestCircuitBreaker_TransitionsToHalfOpen(t *testing.T) {
	cb := NewCircuitBreaker(2, time.Hour, 100*time.Millisecond)

	cb.RecordFailure()
	cb.RecordFailure() // open

	time.Sleep(150 * time.Millisecond) // cooldown elapsed

	if cb.State() != CircuitHalfOpen {
		t.Errorf("state = %s, want half_open", cb.State())
	}

	if err := cb.Allow(); err != nil {
		t.Errorf("should allow in half_open: %v", err)
	}
}

func TestCircuitBreaker_HalfOpenToClosedOnSuccess(t *testing.T) {
	cb := NewCircuitBreaker(2, time.Hour, 100*time.Millisecond)

	cb.RecordFailure()
	cb.RecordFailure()

	time.Sleep(150 * time.Millisecond) // half_open
	cb.State()                          // trigger transition
	cb.RecordSuccess()

	if cb.State() != CircuitClosed {
		t.Errorf("state = %s, want closed", cb.State())
	}
}

func TestCircuitBreaker_HalfOpenToOpenOnFailure(t *testing.T) {
	cb := NewCircuitBreaker(2, time.Hour, 100*time.Millisecond)

	cb.RecordFailure()
	cb.RecordFailure() // open

	time.Sleep(150 * time.Millisecond) // half_open
	cb.State()

	cb.RecordFailure()
	cb.RecordFailure() // back to open

	if cb.State() != CircuitOpen {
		t.Errorf("state = %s, want open", cb.State())
	}
}

func TestExponentialBackoff(t *testing.T) {
	maxBackoff := 5 * time.Minute

	// Verify increasing backoff
	prev := time.Duration(0)
	for i := 0; i < 5; i++ {
		b := ExponentialBackoff(i, maxBackoff)
		if b <= prev {
			t.Errorf("attempt %d: backoff %v should be > %v", i, b, prev)
		}
		prev = b
	}

	// Verify cap at max
	b := ExponentialBackoff(20, maxBackoff)
	if b > maxBackoff+time.Duration(float64(maxBackoff)*0.2) {
		t.Errorf("backoff %v exceeds max %v + 20%% jitter", b, maxBackoff)
	}
}

func TestExponentialBackoff_JitterRange(t *testing.T) {
	// Run many times to verify jitter is within range
	for i := 0; i < 100; i++ {
		b := ExponentialBackoff(0, 5*time.Minute)
		// Attempt 0: base = 2s, max jitter 0.4s → range [2s, 2.4s]
		if b < 2*time.Second || b > 3*time.Second {
			t.Errorf("attempt 0 backoff %v out of expected range [2s, 3s]", b)
		}
	}
}
