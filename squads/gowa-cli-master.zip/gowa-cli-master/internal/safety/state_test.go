package safety

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestLoadState_FileNotFound(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	state, err := LoadState(statePath)
	if err != nil {
		t.Fatalf("expected no error for missing file, got: %v", err)
	}
	if state == nil {
		t.Fatal("expected non-nil state")
	}
	if len(state.MessagesSent) != 0 {
		t.Fatalf("expected empty MessagesSent, got %d entries", len(state.MessagesSent))
	}
}

func TestLoadState_ValidFile(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	now := time.Now().UTC().Format(time.RFC3339)
	original := &State{MessagesSent: []string{now, "2025-01-01T00:00:00Z"}}
	data, err := json.Marshal(original)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if err := os.WriteFile(statePath, data, 0600); err != nil {
		t.Fatalf("write: %v", err)
	}

	state, err := LoadState(statePath)
	if err != nil {
		t.Fatalf("LoadState: %v", err)
	}
	if len(state.MessagesSent) != 2 {
		t.Fatalf("expected 2 entries, got %d", len(state.MessagesSent))
	}
	if state.MessagesSent[0] != now {
		t.Errorf("first entry mismatch: got %q, want %q", state.MessagesSent[0], now)
	}
	if state.MessagesSent[1] != "2025-01-01T00:00:00Z" {
		t.Errorf("second entry mismatch: got %q", state.MessagesSent[1])
	}
}

func TestLoadState_CorruptedFile_AutoRecovers(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	if err := os.WriteFile(statePath, []byte("{bad json!!!"), 0600); err != nil {
		t.Fatalf("write: %v", err)
	}

	state, err := LoadState(statePath)
	if err != nil {
		t.Fatalf("expected auto-recovery, got error: %v", err)
	}
	if len(state.MessagesSent) != 0 {
		t.Errorf("expected empty state after recovery, got %d entries", len(state.MessagesSent))
	}

	// Verify corrupted file was renamed
	corruptedPath := statePath + ".corrupted"
	if _, err := os.Stat(corruptedPath); os.IsNotExist(err) {
		t.Error("expected corrupted file to be renamed to .corrupted")
	}
}

func TestSaveState_CreatesFile(t *testing.T) {
	dir := t.TempDir()
	// Use a subdirectory to verify SaveState creates intermediate dirs.
	statePath := filepath.Join(dir, "sub", "deep", "state.json")
	// Lock file needs its parent dir to exist; SaveState creates statePath's
	// dir but the lock is acquired first. Pre-create the dir so flock works.
	if err := os.MkdirAll(filepath.Dir(statePath), 0700); err != nil {
		t.Fatalf("pre-create dir: %v", err)
	}

	state := &State{MessagesSent: []string{"2025-06-01T12:00:00Z"}}
	if err := SaveState(statePath, state); err != nil {
		t.Fatalf("SaveState: %v", err)
	}

	info, err := os.Stat(statePath)
	if err != nil {
		t.Fatalf("file should exist: %v", err)
	}
	perm := info.Mode().Perm()
	if perm != 0600 {
		t.Errorf("expected permissions 0600, got %04o", perm)
	}
}

func TestSaveState_Atomic(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "state.json")

	state := &State{MessagesSent: []string{"2025-06-01T12:00:00Z", "2025-06-01T13:00:00Z"}}
	if err := SaveState(statePath, state); err != nil {
		t.Fatalf("SaveState: %v", err)
	}

	// Verify file contains valid JSON and correct data.
	data, err := os.ReadFile(statePath)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	var loaded State
	if err := json.Unmarshal(data, &loaded); err != nil {
		t.Fatalf("saved file is not valid JSON: %v", err)
	}
	if len(loaded.MessagesSent) != 2 {
		t.Fatalf("expected 2 entries, got %d", len(loaded.MessagesSent))
	}

	// Verify no leftover temp file.
	tmpFile := statePath + ".tmp"
	if _, err := os.Stat(tmpFile); !os.IsNotExist(err) {
		t.Error("temp file should not exist after successful save")
	}
}

func TestCleanExpiredEntries_RemovesOld(t *testing.T) {
	old := time.Now().UTC().Add(-25 * time.Hour).Format(time.RFC3339)
	veryOld := time.Now().UTC().Add(-48 * time.Hour).Format(time.RFC3339)

	state := &State{MessagesSent: []string{old, veryOld}}
	state.CleanExpiredEntries()

	if len(state.MessagesSent) != 0 {
		t.Fatalf("expected 0 entries after cleaning, got %d", len(state.MessagesSent))
	}
}

func TestCleanExpiredEntries_KeepsRecent(t *testing.T) {
	recent := time.Now().UTC().Add(-5 * time.Minute).Format(time.RFC3339)
	alsoRecent := time.Now().UTC().Add(-23 * time.Hour).Format(time.RFC3339)

	state := &State{MessagesSent: []string{recent, alsoRecent}}
	state.CleanExpiredEntries()

	if len(state.MessagesSent) != 2 {
		t.Fatalf("expected 2 recent entries kept, got %d", len(state.MessagesSent))
	}
}

func TestCleanExpiredEntries_CleansAllThreeArrays(t *testing.T) {
	now := time.Now().UTC()
	old := now.Add(-25 * time.Hour).Format(time.RFC3339)
	recent := now.Add(-1 * time.Hour).Format(time.RFC3339)

	state := &State{
		MessagesSent:          []string{old, recent},
		GroupCreateTimestamps: []string{old, recent, "unparseable"},
		GroupJoinTimestamps:   []string{old},
	}

	state.CleanExpiredEntries()

	if len(state.MessagesSent) != 1 || state.MessagesSent[0] != recent {
		t.Errorf("MessagesSent: expected [%s], got %v", recent, state.MessagesSent)
	}
	// only recent should remain; unparseable is now discarded
	if len(state.GroupCreateTimestamps) != 1 {
		t.Errorf("GroupCreateTimestamps: expected 1 entry, got %d: %v", len(state.GroupCreateTimestamps), state.GroupCreateTimestamps)
	}
	if len(state.GroupJoinTimestamps) != 0 {
		t.Errorf("GroupJoinTimestamps: expected 0 entries, got %d: %v", len(state.GroupJoinTimestamps), state.GroupJoinTimestamps)
	}
}

func TestCleanExpiredEntries_DiscardsUnparseable(t *testing.T) {
	unparseable := "not-a-timestamp"
	old := time.Now().UTC().Add(-25 * time.Hour).Format(time.RFC3339)
	recent := time.Now().UTC().Add(-1 * time.Minute).Format(time.RFC3339)

	state := &State{MessagesSent: []string{unparseable, old, recent}}
	state.CleanExpiredEntries()

	if len(state.MessagesSent) != 1 {
		t.Fatalf("expected 1 entry (recent only), got %d: %v", len(state.MessagesSent), state.MessagesSent)
	}
	if state.MessagesSent[0] != recent {
		t.Errorf("recent entry should be preserved, got %q", state.MessagesSent[0])
	}
}
