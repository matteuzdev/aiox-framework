package msgstore

import (
	"database/sql"
	_ "embed"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"

	_ "modernc.org/sqlite"
)

//go:embed schema_base.sql
var schemaBaseSQL string

//go:embed schema_fts.sql
var schemaFTSSQL string

const currentSchemaVersion = 1

// MsgStore provides local SQLite storage for messages, chats, and contacts.
type MsgStore struct {
	db     *sql.DB
	dbPath string
	hasFTS bool
}

// NewMsgStore opens (or creates) the message database at dbPath.
// Applies schema migrations and configures SQLite for WAL mode.
func NewMsgStore(dbPath string) (*MsgStore, error) {
	dir := filepath.Dir(dbPath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return nil, fmt.Errorf("creating msgstore directory: %w", err)
	}

	dsn := fmt.Sprintf("file:%s", dbPath)
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		return nil, fmt.Errorf("opening message database: %w", err)
	}

	// SQLite single-writer: only 1 connection needed
	db.SetMaxOpenConns(1)

	// Configure SQLite pragmas via Exec (connection string pragmas unreliable with modernc)
	pragmas := []struct{ name, sql string }{
		{"WAL mode", "PRAGMA journal_mode=WAL"},
		{"foreign keys", "PRAGMA foreign_keys=ON"},
		{"busy timeout", "PRAGMA busy_timeout=5000"},
		{"synchronous", "PRAGMA synchronous=NORMAL"},
	}
	for _, p := range pragmas {
		if _, err := db.Exec(p.sql); err != nil {
			db.Close()
			return nil, fmt.Errorf("setting %s: %w", p.name, err)
		}
	}

	store := &MsgStore{
		db:     db,
		dbPath: dbPath,
	}

	if err := store.migrate(); err != nil {
		db.Close()
		return nil, err
	}

	// Set file permissions 0600
	if _, statErr := os.Stat(dbPath); statErr == nil {
		if chmodErr := os.Chmod(dbPath, 0600); chmodErr != nil {
			slog.Warn("failed to set messages.db permissions", "error", chmodErr)
		}
	}

	return store, nil
}

// migrate applies schema migrations using PRAGMA user_version for tracking.
// FTS5 creation may fail gracefully on builds without FTS5 support.
func (s *MsgStore) migrate() error {
	var version int
	if err := s.db.QueryRow("PRAGMA user_version").Scan(&version); err != nil {
		return fmt.Errorf("reading schema version: %w", err)
	}

	if version < 1 {
		// Apply base schema (tables + indexes)
		if _, err := s.db.Exec(schemaBaseSQL); err != nil {
			return fmt.Errorf("applying base schema: %w", err)
		}

		// Try FTS5 (optional — may fail if SQLite lacks FTS5)
		if _, err := s.db.Exec(schemaFTSSQL); err != nil {
			slog.Info("FTS5 not available, using LIKE fallback", "error", err)
			s.hasFTS = false
		} else {
			s.hasFTS = true
		}

		if _, err := s.db.Exec(fmt.Sprintf("PRAGMA user_version = %d", currentSchemaVersion)); err != nil {
			return fmt.Errorf("updating schema version: %w", err)
		}
	} else {
		// Already migrated — check if FTS is available
		var ftsExists int
		err := s.db.QueryRow("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='messages_fts'").Scan(&ftsExists)
		if err == nil && ftsExists > 0 {
			s.hasFTS = true
		}
	}

	return nil
}

// HasFTS returns true if FTS5 full-text search is available.
func (s *MsgStore) HasFTS() bool {
	return s.hasFTS
}

// Close closes the database connection.
func (s *MsgStore) Close() error {
	return s.db.Close()
}
