-- GOWA CLI Message Store Schema — Base Tables
-- Version 1

-- Chats table (must be created before messages due to FK)
CREATE TABLE IF NOT EXISTS chats (
    jid TEXT PRIMARY KEY,
    name TEXT,
    is_group INTEGER NOT NULL DEFAULT 0,
    last_msg_timestamp INTEGER,
    last_msg_preview TEXT,
    unread_count INTEGER NOT NULL DEFAULT 0,
    archived INTEGER NOT NULL DEFAULT 0,
    pinned INTEGER NOT NULL DEFAULT 0,
    muted_until INTEGER NOT NULL DEFAULT 0
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
    id TEXT NOT NULL,
    chat_jid TEXT NOT NULL,
    sender_jid TEXT NOT NULL,
    timestamp INTEGER NOT NULL,
    type TEXT NOT NULL,
    text TEXT,
    media_type TEXT,
    media_path TEXT,
    is_from_me INTEGER NOT NULL DEFAULT 0,
    is_read INTEGER NOT NULL DEFAULT 0,
    reply_to TEXT,
    raw_json TEXT,
    PRIMARY KEY (id, chat_jid),
    FOREIGN KEY (chat_jid) REFERENCES chats(jid)
);

-- Contacts table
CREATE TABLE IF NOT EXISTS contacts (
    jid TEXT PRIMARY KEY,
    push_name TEXT,
    full_name TEXT,
    business_name TEXT,
    phone TEXT
);

-- Indexes for query performance
CREATE INDEX IF NOT EXISTS idx_messages_chat_ts ON messages(chat_jid, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_messages_unread ON messages(chat_jid, is_read) WHERE is_read = 0;
CREATE INDEX IF NOT EXISTS idx_chats_unread ON chats(unread_count) WHERE unread_count > 0;
CREATE INDEX IF NOT EXISTS idx_chats_last_msg ON chats(last_msg_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_contacts_phone ON contacts(phone);
