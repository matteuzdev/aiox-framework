package msgstore

import (
	"testing"
)

func TestUpsertContact_Insert(t *testing.T) {
	store := newTestStore(t)

	contact := &Contact{
		JID:      "5511999999999@s.whatsapp.net",
		PushName: "John",
		Phone:    "5511999999999",
	}

	if err := store.UpsertContact(contact); err != nil {
		t.Fatalf("UpsertContact: %v", err)
	}

	contacts, err := store.GetContacts(10)
	if err != nil {
		t.Fatalf("GetContacts: %v", err)
	}
	if len(contacts) != 1 {
		t.Fatalf("expected 1 contact, got %d", len(contacts))
	}
	if contacts[0].PushName != "John" {
		t.Errorf("PushName = %q, want %q", contacts[0].PushName, "John")
	}
}

func TestUpsertContact_PreservesExistingData(t *testing.T) {
	store := newTestStore(t)

	// First: push_name from WhatsApp
	store.UpsertContact(&Contact{
		JID:      "5511999999999@s.whatsapp.net",
		PushName: "John",
		Phone:    "5511999999999",
	})

	// Second: business name from profile (push_name empty — should not overwrite)
	store.UpsertContact(&Contact{
		JID:          "5511999999999@s.whatsapp.net",
		PushName:     "",
		BusinessName: "John's Shop",
	})

	contacts, _ := store.GetContacts(10)
	if contacts[0].PushName != "John" {
		t.Errorf("PushName = %q, want %q (should be preserved)", contacts[0].PushName, "John")
	}
	if contacts[0].BusinessName != "John's Shop" {
		t.Errorf("BusinessName = %q, want %q", contacts[0].BusinessName, "John's Shop")
	}
	if contacts[0].Phone != "5511999999999" {
		t.Errorf("Phone = %q, want %q (should be preserved)", contacts[0].Phone, "5511999999999")
	}
}

func TestSearchContacts(t *testing.T) {
	store := newTestStore(t)

	store.UpsertContact(&Contact{JID: "a@s.whatsapp.net", PushName: "Alice"})
	store.UpsertContact(&Contact{JID: "b@s.whatsapp.net", PushName: "Bob"})
	store.UpsertContact(&Contact{JID: "c@s.whatsapp.net", PushName: "Charlie", Phone: "5511alice"})

	results, err := store.SearchContacts("alice", 10)
	if err != nil {
		t.Fatalf("SearchContacts: %v", err)
	}
	if len(results) != 2 {
		t.Errorf("expected 2 results (Alice + Charlie with phone containing 'alice'), got %d", len(results))
	}
}

func TestSearchContacts_ByPhone(t *testing.T) {
	store := newTestStore(t)

	store.UpsertContact(&Contact{JID: "a@s.whatsapp.net", PushName: "Alice", Phone: "5511999001234"})
	store.UpsertContact(&Contact{JID: "b@s.whatsapp.net", PushName: "Bob", Phone: "5511888005678"})

	results, err := store.SearchContacts("999001234", 10)
	if err != nil {
		t.Fatalf("SearchContacts: %v", err)
	}
	if len(results) != 1 {
		t.Fatalf("expected 1 result, got %d", len(results))
	}
	if results[0].PushName != "Alice" {
		t.Errorf("PushName = %q, want %q", results[0].PushName, "Alice")
	}
}
