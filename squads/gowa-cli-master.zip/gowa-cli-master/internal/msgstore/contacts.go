package msgstore

import (
	"database/sql"
	"fmt"
)

// Contact represents a stored WhatsApp contact.
type Contact struct {
	JID          string `json:"jid"`
	PushName     string `json:"push_name,omitempty"`
	FullName     string `json:"full_name,omitempty"`
	BusinessName string `json:"business_name,omitempty"`
	Phone        string `json:"phone,omitempty"`
}

// UpsertContact inserts or updates a contact using COALESCE to preserve existing data.
func (s *MsgStore) UpsertContact(contact *Contact) error {
	_, err := s.db.Exec(`
		INSERT INTO contacts (jid, push_name, full_name, business_name, phone)
		VALUES (?, ?, ?, ?, ?)
		ON CONFLICT(jid) DO UPDATE SET
			push_name     = COALESCE(NULLIF(excluded.push_name, ''), contacts.push_name),
			full_name     = COALESCE(NULLIF(excluded.full_name, ''), contacts.full_name),
			business_name = COALESCE(NULLIF(excluded.business_name, ''), contacts.business_name),
			phone         = COALESCE(NULLIF(excluded.phone, ''), contacts.phone)
	`,
		contact.JID, contact.PushName, contact.FullName, contact.BusinessName, contact.Phone,
	)
	if err != nil {
		return fmt.Errorf("upserting contact: %w", err)
	}
	return nil
}

// GetContacts returns contacts ordered by push_name.
func (s *MsgStore) GetContacts(limit int) ([]*Contact, error) {
	if limit <= 0 {
		limit = 100
	}

	rows, err := s.db.Query(`
		SELECT jid, push_name, full_name, business_name, phone
		FROM contacts
		ORDER BY COALESCE(push_name, full_name, jid)
		LIMIT ?
	`, limit)
	if err != nil {
		return nil, fmt.Errorf("querying contacts: %w", err)
	}
	defer rows.Close()

	return scanContacts(rows)
}

// SearchContacts searches contacts by name or phone.
func (s *MsgStore) SearchContacts(query string, limit int) ([]*Contact, error) {
	if limit <= 0 {
		limit = 50
	}

	like := "%" + query + "%"
	rows, err := s.db.Query(`
		SELECT jid, push_name, full_name, business_name, phone
		FROM contacts
		WHERE push_name LIKE ? OR full_name LIKE ? OR business_name LIKE ? OR phone LIKE ?
		ORDER BY COALESCE(push_name, full_name, jid)
		LIMIT ?
	`, like, like, like, like, limit)
	if err != nil {
		return nil, fmt.Errorf("searching contacts: %w", err)
	}
	defer rows.Close()

	return scanContacts(rows)
}

func scanContacts(rows *sql.Rows) ([]*Contact, error) {
	var contacts []*Contact
	for rows.Next() {
		var c Contact
		var pushName, fullName, businessName, phone sql.NullString

		err := rows.Scan(&c.JID, &pushName, &fullName, &businessName, &phone)
		if err != nil {
			return nil, fmt.Errorf("scanning contact row: %w", err)
		}

		c.PushName = pushName.String
		c.FullName = fullName.String
		c.BusinessName = businessName.String
		c.Phone = phone.String

		contacts = append(contacts, &c)
	}
	return contacts, rows.Err()
}
