package msgstore

import (
	"fmt"
	"testing"
)

func ensureChat(t *testing.T, store *MsgStore, jid string) {
	t.Helper()
	err := store.UpsertChat(&Chat{JID: jid, Name: "Test Chat"})
	if err != nil {
		t.Fatalf("UpsertChat: %v", err)
	}
}

func TestSaveMessage_Insert(t *testing.T) {
	store := newTestStore(t)
	ensureChat(t, store, "5511999999999@s.whatsapp.net")

	msg := &Message{
		ID:        "msg-001",
		ChatJID:   "5511999999999@s.whatsapp.net",
		SenderJID: "5511999999999@s.whatsapp.net",
		Timestamp: 1710000000,
		Type:      "text",
		Text:      "Hello World",
		IsFromMe:  false,
	}

	if err := store.SaveMessage(msg); err != nil {
		t.Fatalf("SaveMessage: %v", err)
	}

	msgs, err := store.GetMessages("5511999999999@s.whatsapp.net", 10, MessageFilter{})
	if err != nil {
		t.Fatalf("GetMessages: %v", err)
	}
	if len(msgs) != 1 {
		t.Fatalf("expected 1 message, got %d", len(msgs))
	}
	if msgs[0].Text != "Hello World" {
		t.Errorf("Text = %q, want %q", msgs[0].Text, "Hello World")
	}
}

func TestSaveMessage_Idempotent(t *testing.T) {
	store := newTestStore(t)
	ensureChat(t, store, "5511999999999@s.whatsapp.net")

	msg := &Message{
		ID:        "msg-dup",
		ChatJID:   "5511999999999@s.whatsapp.net",
		SenderJID: "5511999999999@s.whatsapp.net",
		Timestamp: 1710000000,
		Type:      "text",
		Text:      "Original",
	}

	if err := store.SaveMessage(msg); err != nil {
		t.Fatalf("SaveMessage (1st): %v", err)
	}

	// Insert same ID again with empty text — should preserve original
	msg2 := &Message{
		ID:        "msg-dup",
		ChatJID:   "5511999999999@s.whatsapp.net",
		SenderJID: "5511999999999@s.whatsapp.net",
		Timestamp: 1710000000,
		Type:      "text",
		Text:      "", // empty — should not overwrite
	}
	if err := store.SaveMessage(msg2); err != nil {
		t.Fatalf("SaveMessage (2nd): %v", err)
	}

	msgs, err := store.GetMessages("5511999999999@s.whatsapp.net", 10, MessageFilter{})
	if err != nil {
		t.Fatalf("GetMessages: %v", err)
	}
	if len(msgs) != 1 {
		t.Fatalf("expected 1 message (upsert), got %d", len(msgs))
	}
	if msgs[0].Text != "Original" {
		t.Errorf("Text = %q, want %q (COALESCE should preserve)", msgs[0].Text, "Original")
	}
}

func TestSaveMessage_UpsertEnrichesData(t *testing.T) {
	store := newTestStore(t)
	ensureChat(t, store, "5511999999999@s.whatsapp.net")

	// First: partial data from history sync
	msg1 := &Message{
		ID:        "msg-enrich",
		ChatJID:   "5511999999999@s.whatsapp.net",
		SenderJID: "5511999999999@s.whatsapp.net",
		Timestamp: 1710000000,
		Type:      "image",
		Text:      "",
		MediaType: "image/jpeg",
	}
	if err := store.SaveMessage(msg1); err != nil {
		t.Fatalf("SaveMessage (1st): %v", err)
	}

	// Second: real-time event adds caption
	msg2 := &Message{
		ID:        "msg-enrich",
		ChatJID:   "5511999999999@s.whatsapp.net",
		SenderJID: "5511999999999@s.whatsapp.net",
		Timestamp: 1710000000,
		Type:      "image",
		Text:      "Nice photo",
		MediaType: "", // empty — should not overwrite
	}
	if err := store.SaveMessage(msg2); err != nil {
		t.Fatalf("SaveMessage (2nd): %v", err)
	}

	msgs, err := store.GetMessages("5511999999999@s.whatsapp.net", 10, MessageFilter{})
	if err != nil {
		t.Fatalf("GetMessages: %v", err)
	}
	if len(msgs) != 1 {
		t.Fatalf("expected 1 message, got %d", len(msgs))
	}
	if msgs[0].Text != "Nice photo" {
		t.Errorf("Text = %q, want %q", msgs[0].Text, "Nice photo")
	}
	if msgs[0].MediaType != "image/jpeg" {
		t.Errorf("MediaType = %q, want %q (should be preserved)", msgs[0].MediaType, "image/jpeg")
	}
}

func TestGetMessages_Pagination(t *testing.T) {
	store := newTestStore(t)
	ensureChat(t, store, "chat@s.whatsapp.net")

	for i := 0; i < 5; i++ {
		store.SaveMessage(&Message{
			ID: "msg-" + string(rune('a'+i)), ChatJID: "chat@s.whatsapp.net",
			SenderJID: "sender@s.whatsapp.net", Timestamp: int64(1710000000 + i),
			Type: "text", Text: "msg",
		})
	}

	// Get first page (newest)
	msgs, err := store.GetMessages("chat@s.whatsapp.net", 3, MessageFilter{})
	if err != nil {
		t.Fatalf("GetMessages: %v", err)
	}
	if len(msgs) != 3 {
		t.Fatalf("expected 3, got %d", len(msgs))
	}

	// Get second page (before oldest of first page)
	msgs2, err := store.GetMessages("chat@s.whatsapp.net", 3, MessageFilter{Before: msgs[len(msgs)-1].Timestamp})
	if err != nil {
		t.Fatalf("GetMessages page 2: %v", err)
	}
	if len(msgs2) != 2 {
		t.Fatalf("expected 2, got %d", len(msgs2))
	}
}

func TestGetMessages_SinceUntilSearch(t *testing.T) {
	store := newTestStore(t)
	ensureChat(t, store, "chat@s.whatsapp.net")

	for i := 0; i < 5; i++ {
		store.SaveMessage(&Message{
			ID: fmt.Sprintf("ts-%d", i), ChatJID: "chat@s.whatsapp.net",
			SenderJID: "sender@s.whatsapp.net", Timestamp: int64(1710000000 + i*3600),
			Type: "text", Text: fmt.Sprintf("message %d", i),
		})
	}

	// Test since (after)
	msgs, err := store.GetMessages("chat@s.whatsapp.net", 10, MessageFilter{After: 1710003600})
	if err != nil {
		t.Fatalf("GetMessages with since: %v", err)
	}
	if len(msgs) != 3 {
		t.Errorf("since filter: expected 3 messages after ts 1710003600, got %d", len(msgs))
	}

	// Test until
	msgs, err = store.GetMessages("chat@s.whatsapp.net", 10, MessageFilter{Until: 1710007200})
	if err != nil {
		t.Fatalf("GetMessages with until: %v", err)
	}
	if len(msgs) != 3 {
		t.Errorf("until filter: expected 3 messages at or before ts 1710007200, got %d", len(msgs))
	}

	// Test since + until (range)
	msgs, err = store.GetMessages("chat@s.whatsapp.net", 10, MessageFilter{After: 1710000000, Until: 1710010800})
	if err != nil {
		t.Fatalf("GetMessages with since+until: %v", err)
	}
	if len(msgs) != 3 {
		t.Errorf("range filter: expected 3 messages, got %d", len(msgs))
	}

	// Test search
	msgs, err = store.GetMessages("chat@s.whatsapp.net", 10, MessageFilter{Search: "message 3"})
	if err != nil {
		t.Fatalf("GetMessages with search: %v", err)
	}
	if len(msgs) != 1 {
		t.Errorf("search filter: expected 1 message, got %d", len(msgs))
	}
}

func TestSearchMessages_LIKE(t *testing.T) {
	store := newTestStore(t)
	ensureChat(t, store, "chat@s.whatsapp.net")

	store.SaveMessage(&Message{
		ID: "s1", ChatJID: "chat@s.whatsapp.net", SenderJID: "sender@s.whatsapp.net",
		Timestamp: 1710000000, Type: "text", Text: "Hello World",
	})
	store.SaveMessage(&Message{
		ID: "s2", ChatJID: "chat@s.whatsapp.net", SenderJID: "sender@s.whatsapp.net",
		Timestamp: 1710000001, Type: "text", Text: "Goodbye World",
	})
	store.SaveMessage(&Message{
		ID: "s3", ChatJID: "chat@s.whatsapp.net", SenderJID: "sender@s.whatsapp.net",
		Timestamp: 1710000002, Type: "text", Text: "No match here",
	})

	// Search with LIKE fallback (FTS may or may not be available)
	msgs, err := store.SearchMessages("World", 10)
	if err != nil {
		t.Fatalf("SearchMessages: %v", err)
	}
	if len(msgs) != 2 {
		t.Errorf("expected 2 results, got %d", len(msgs))
	}
}
