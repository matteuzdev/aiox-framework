package msgstore

import (
	"database/sql"
	"fmt"
)

// Chat represents a stored WhatsApp chat.
type Chat struct {
	JID             string `json:"jid"`
	Name            string `json:"name"`
	IsGroup         bool   `json:"is_group"`
	LastMsgTimestamp int64  `json:"last_msg_timestamp,omitempty"`
	LastMsgPreview  string `json:"last_msg_preview,omitempty"`
	UnreadCount     int    `json:"unread_count"`
	Archived        bool   `json:"archived"`
	Pinned          bool   `json:"pinned"`
	MutedUntil      int64  `json:"muted_until,omitempty"`
}

// UpsertChat inserts or updates a chat. Uses smart name logic to avoid
// overwriting a friendly name with a raw JID.
func (s *MsgStore) UpsertChat(chat *Chat) error {
	_, err := s.db.Exec(`
		INSERT INTO chats (jid, name, is_group, last_msg_timestamp, last_msg_preview, unread_count, archived, pinned, muted_until)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
		ON CONFLICT(jid) DO UPDATE SET
			name = CASE
				WHEN excluded.name IS NOT NULL AND excluded.name != '' AND excluded.name != excluded.jid
				THEN excluded.name
				ELSE COALESCE(chats.name, excluded.name)
			END,
			is_group = excluded.is_group,
			last_msg_timestamp = CASE
				WHEN excluded.last_msg_timestamp > COALESCE(chats.last_msg_timestamp, 0)
				THEN excluded.last_msg_timestamp
				ELSE chats.last_msg_timestamp
			END,
			last_msg_preview = CASE
				WHEN excluded.last_msg_timestamp > COALESCE(chats.last_msg_timestamp, 0)
				THEN excluded.last_msg_preview
				ELSE chats.last_msg_preview
			END,
			unread_count = excluded.unread_count,
			archived = excluded.archived,
			pinned = excluded.pinned,
			muted_until = excluded.muted_until
	`,
		chat.JID, chat.Name, boolToInt(chat.IsGroup),
		chat.LastMsgTimestamp, chat.LastMsgPreview,
		chat.UnreadCount, boolToInt(chat.Archived),
		boolToInt(chat.Pinned), chat.MutedUntil,
	)
	if err != nil {
		return fmt.Errorf("upserting chat: %w", err)
	}
	return nil
}

// GetChats returns chats ordered by last message timestamp DESC.
func (s *MsgStore) GetChats(limit int) ([]*Chat, error) {
	if limit <= 0 {
		limit = 50
	}

	rows, err := s.db.Query(`
		SELECT jid, name, is_group, last_msg_timestamp, last_msg_preview, unread_count, archived, pinned, muted_until
		FROM chats
		ORDER BY last_msg_timestamp DESC
		LIMIT ?
	`, limit)
	if err != nil {
		return nil, fmt.Errorf("querying chats: %w", err)
	}
	defer rows.Close()

	return scanChats(rows)
}

// GetUnreadChats returns only chats with unread messages.
func (s *MsgStore) GetUnreadChats() ([]*Chat, error) {
	rows, err := s.db.Query(`
		SELECT jid, name, is_group, last_msg_timestamp, last_msg_preview, unread_count, archived, pinned, muted_until
		FROM chats
		WHERE unread_count > 0
		ORDER BY last_msg_timestamp DESC
	`)
	if err != nil {
		return nil, fmt.Errorf("querying unread chats: %w", err)
	}
	defer rows.Close()

	return scanChats(rows)
}

// MarkChatRead resets unread count and marks all messages as read for a chat.
func (s *MsgStore) MarkChatRead(chatJID string) error {
	tx, err := s.db.Begin()
	if err != nil {
		return fmt.Errorf("beginning transaction: %w", err)
	}
	defer tx.Rollback()

	if _, err := tx.Exec("UPDATE chats SET unread_count = 0 WHERE jid = ?", chatJID); err != nil {
		return fmt.Errorf("resetting unread count: %w", err)
	}

	if _, err := tx.Exec("UPDATE messages SET is_read = 1 WHERE chat_jid = ? AND is_read = 0", chatJID); err != nil {
		return fmt.Errorf("marking messages read: %w", err)
	}

	return tx.Commit()
}

// IncrementUnread increments the unread count for a chat by 1.
func (s *MsgStore) IncrementUnread(chatJID string) error {
	_, err := s.db.Exec("UPDATE chats SET unread_count = unread_count + 1 WHERE jid = ?", chatJID)
	if err != nil {
		return fmt.Errorf("incrementing unread: %w", err)
	}
	return nil
}

func scanChats(rows *sql.Rows) ([]*Chat, error) {
	var chats []*Chat
	for rows.Next() {
		var chat Chat
		var isGroup, archived, pinned int
		var name, lastMsgPreview sql.NullString
		var lastMsgTs, mutedUntil sql.NullInt64

		err := rows.Scan(
			&chat.JID, &name, &isGroup,
			&lastMsgTs, &lastMsgPreview,
			&chat.UnreadCount, &archived, &pinned, &mutedUntil,
		)
		if err != nil {
			return nil, fmt.Errorf("scanning chat row: %w", err)
		}

		chat.Name = name.String
		chat.IsGroup = isGroup != 0
		chat.LastMsgTimestamp = lastMsgTs.Int64
		chat.LastMsgPreview = lastMsgPreview.String
		chat.Archived = archived != 0
		chat.Pinned = pinned != 0
		chat.MutedUntil = mutedUntil.Int64

		chats = append(chats, &chat)
	}
	return chats, rows.Err()
}
