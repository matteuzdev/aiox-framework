package msgstore

import (
	"testing"
)

func TestUpsertChat_Insert(t *testing.T) {
	store := newTestStore(t)

	chat := &Chat{
		JID:     "5511999999999@s.whatsapp.net",
		Name:    "John Doe",
		IsGroup: false,
	}

	if err := store.UpsertChat(chat); err != nil {
		t.Fatalf("UpsertChat: %v", err)
	}

	chats, err := store.GetChats(10)
	if err != nil {
		t.Fatalf("GetChats: %v", err)
	}
	if len(chats) != 1 {
		t.Fatalf("expected 1 chat, got %d", len(chats))
	}
	if chats[0].Name != "John Doe" {
		t.Errorf("Name = %q, want %q", chats[0].Name, "John Doe")
	}
}

func TestUpsertChat_PreserveFriendlyName(t *testing.T) {
	store := newTestStore(t)

	// First insert with friendly name
	store.UpsertChat(&Chat{JID: "5511999999999@s.whatsapp.net", Name: "John Doe"})

	// Second upsert with JID as name (should NOT overwrite)
	store.UpsertChat(&Chat{JID: "5511999999999@s.whatsapp.net", Name: "5511999999999@s.whatsapp.net"})

	chats, err := store.GetChats(10)
	if err != nil {
		t.Fatalf("GetChats: %v", err)
	}
	if chats[0].Name != "John Doe" {
		t.Errorf("Name = %q, want %q (should preserve friendly name)", chats[0].Name, "John Doe")
	}
}

func TestUpsertChat_UpdatesTimestamp(t *testing.T) {
	store := newTestStore(t)

	store.UpsertChat(&Chat{JID: "chat1@s.whatsapp.net", Name: "Chat", LastMsgTimestamp: 100, LastMsgPreview: "old"})
	store.UpsertChat(&Chat{JID: "chat1@s.whatsapp.net", Name: "Chat", LastMsgTimestamp: 200, LastMsgPreview: "new"})

	chats, _ := store.GetChats(10)
	if chats[0].LastMsgTimestamp != 200 {
		t.Errorf("LastMsgTimestamp = %d, want 200", chats[0].LastMsgTimestamp)
	}
	if chats[0].LastMsgPreview != "new" {
		t.Errorf("LastMsgPreview = %q, want %q", chats[0].LastMsgPreview, "new")
	}
}

func TestGetUnreadChats(t *testing.T) {
	store := newTestStore(t)

	store.UpsertChat(&Chat{JID: "chat1@s.whatsapp.net", Name: "Read Chat", UnreadCount: 0})
	store.UpsertChat(&Chat{JID: "chat2@s.whatsapp.net", Name: "Unread Chat", UnreadCount: 3})

	chats, err := store.GetUnreadChats()
	if err != nil {
		t.Fatalf("GetUnreadChats: %v", err)
	}
	if len(chats) != 1 {
		t.Fatalf("expected 1 unread chat, got %d", len(chats))
	}
	if chats[0].JID != "chat2@s.whatsapp.net" {
		t.Errorf("JID = %q, want chat2", chats[0].JID)
	}
}

func TestMarkChatRead(t *testing.T) {
	store := newTestStore(t)
	chatJID := "chat@s.whatsapp.net"

	store.UpsertChat(&Chat{JID: chatJID, Name: "Test", UnreadCount: 5})
	store.SaveMessage(&Message{
		ID: "m1", ChatJID: chatJID, SenderJID: "sender@s.whatsapp.net",
		Timestamp: 100, Type: "text", Text: "unread", IsRead: false,
	})

	if err := store.MarkChatRead(chatJID); err != nil {
		t.Fatalf("MarkChatRead: %v", err)
	}

	chats, _ := store.GetChats(10)
	if chats[0].UnreadCount != 0 {
		t.Errorf("UnreadCount = %d, want 0", chats[0].UnreadCount)
	}

	msgs, _ := store.GetMessages(chatJID, 10, MessageFilter{})
	if len(msgs) > 0 && !msgs[0].IsRead {
		t.Error("message should be marked as read")
	}
}

func TestIncrementUnread(t *testing.T) {
	store := newTestStore(t)
	chatJID := "chat@s.whatsapp.net"

	store.UpsertChat(&Chat{JID: chatJID, Name: "Test", UnreadCount: 2})

	if err := store.IncrementUnread(chatJID); err != nil {
		t.Fatalf("IncrementUnread: %v", err)
	}

	chats, _ := store.GetChats(10)
	if chats[0].UnreadCount != 3 {
		t.Errorf("UnreadCount = %d, want 3", chats[0].UnreadCount)
	}
}

