package msgstore

import (
	"os"
	"path/filepath"
	"testing"
)

func newTestStore(t *testing.T) *MsgStore {
	t.Helper()
	dbPath := filepath.Join(t.TempDir(), "test.db")
	store, err := NewMsgStore(dbPath)
	if err != nil {
		t.Fatalf("NewMsgStore: %v", err)
	}
	t.Cleanup(func() { store.Close() })
	return store
}

func TestNewMsgStore_Creates(t *testing.T) {
	dbPath := filepath.Join(t.TempDir(), "sub", "messages.db")
	store, err := NewMsgStore(dbPath)
	if err != nil {
		t.Fatalf("NewMsgStore: %v", err)
	}
	defer store.Close()

	if _, err := os.Stat(dbPath); os.IsNotExist(err) {
		t.Error("database file should exist")
	}

	// Check permissions
	info, err := os.Stat(dbPath)
	if err != nil {
		t.Fatalf("stat: %v", err)
	}
	perm := info.Mode().Perm()
	if perm != 0600 {
		t.Errorf("permissions = %o, want 0600", perm)
	}
}

func TestNewMsgStore_WALEnabled(t *testing.T) {
	store := newTestStore(t)

	var mode string
	err := store.db.QueryRow("PRAGMA journal_mode").Scan(&mode)
	if err != nil {
		t.Fatalf("PRAGMA journal_mode: %v", err)
	}
	if mode != "wal" {
		t.Errorf("journal_mode = %q, want %q", mode, "wal")
	}
}

func TestNewMsgStore_ForeignKeys(t *testing.T) {
	store := newTestStore(t)

	var fk int
	err := store.db.QueryRow("PRAGMA foreign_keys").Scan(&fk)
	if err != nil {
		t.Fatalf("PRAGMA foreign_keys: %v", err)
	}
	if fk != 1 {
		t.Errorf("foreign_keys = %d, want 1", fk)
	}
}

func TestClose(t *testing.T) {
	dbPath := filepath.Join(t.TempDir(), "close-test.db")
	store, err := NewMsgStore(dbPath)
	if err != nil {
		t.Fatalf("NewMsgStore: %v", err)
	}

	if err := store.Close(); err != nil {
		t.Errorf("Close: %v", err)
	}

	// Verify DB is unusable after close
	_, err = store.GetChats(10)
	if err == nil {
		t.Error("expected error after close")
	}
}
