package msgstore

import (
	"database/sql"
	"fmt"
	"strings"
)

// Message represents a stored WhatsApp message.
type Message struct {
	ID        string `json:"id"`
	ChatJID   string `json:"chat_jid"`
	SenderJID string `json:"sender_jid"`
	Timestamp int64  `json:"timestamp"`
	Type      string `json:"type"`
	Text      string `json:"text,omitempty"`
	MediaType string `json:"media_type,omitempty"`
	MediaPath string `json:"media_path,omitempty"`
	IsFromMe  bool   `json:"is_from_me"`
	IsRead    bool   `json:"is_read"`
	ReplyTo   string `json:"reply_to,omitempty"`
	RawJSON   string `json:"raw_json,omitempty"`
}

// SaveMessage upserts a message. Idempotent via INSERT OR REPLACE on (id, chat_jid).
// Uses COALESCE to preserve non-empty values from previous inserts.
func (s *MsgStore) SaveMessage(msg *Message) error {
	_, err := s.db.Exec(`
		INSERT INTO messages (id, chat_jid, sender_jid, timestamp, type, text, media_type, media_path, is_from_me, is_read, reply_to, raw_json)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		ON CONFLICT(id, chat_jid) DO UPDATE SET
			sender_jid = COALESCE(NULLIF(excluded.sender_jid, ''), messages.sender_jid),
			timestamp  = CASE WHEN excluded.timestamp > 0 THEN excluded.timestamp ELSE messages.timestamp END,
			type       = COALESCE(NULLIF(excluded.type, ''), messages.type),
			text       = COALESCE(NULLIF(excluded.text, ''), messages.text),
			media_type = COALESCE(NULLIF(excluded.media_type, ''), messages.media_type),
			media_path = COALESCE(NULLIF(excluded.media_path, ''), messages.media_path),
			is_from_me = excluded.is_from_me,
			is_read    = MAX(messages.is_read, excluded.is_read),
			reply_to   = COALESCE(NULLIF(excluded.reply_to, ''), messages.reply_to),
			raw_json   = COALESCE(NULLIF(excluded.raw_json, ''), messages.raw_json)
	`,
		msg.ID, msg.ChatJID, msg.SenderJID, msg.Timestamp, msg.Type,
		msg.Text, msg.MediaType, msg.MediaPath,
		boolToInt(msg.IsFromMe), boolToInt(msg.IsRead),
		msg.ReplyTo, msg.RawJSON,
	)
	if err != nil {
		return fmt.Errorf("saving message: %w", err)
	}
	return nil
}

// MessageFilter holds optional filter parameters for GetMessages.
type MessageFilter struct {
	Before int64  // cursor pagination: messages before this timestamp
	After  int64  // since filter: messages after this timestamp
	Until  int64  // until filter: messages before this timestamp (different from cursor)
	Search string // text content filter
}

// GetMessages returns messages for a chat, ordered by timestamp DESC.
// Filter fields are optional — zero values are ignored.
func (s *MsgStore) GetMessages(chatJID string, limit int, filter MessageFilter) ([]*Message, error) {
	if limit <= 0 {
		limit = 50
	}

	query := `SELECT id, chat_jid, sender_jid, timestamp, type, text, media_type, media_path, is_from_me, is_read, reply_to FROM messages WHERE chat_jid = ?`
	args := []interface{}{chatJID}

	if filter.Before > 0 {
		query += ` AND timestamp < ?`
		args = append(args, filter.Before)
	}
	if filter.After > 0 {
		query += ` AND timestamp > ?`
		args = append(args, filter.After)
	}
	if filter.Until > 0 {
		query += ` AND timestamp <= ?`
		args = append(args, filter.Until)
	}
	if filter.Search != "" {
		query += ` AND text LIKE ? ESCAPE '\'`
		args = append(args, "%"+escapeLike(filter.Search)+"%")
	}

	query += ` ORDER BY timestamp DESC LIMIT ?`
	args = append(args, limit)

	rows, err := s.db.Query(query, args...)
	if err != nil {
		return nil, fmt.Errorf("querying messages: %w", err)
	}
	defer rows.Close()

	return scanMessages(rows)
}

// sanitizeFTS5Query escapes special characters for FTS5 MATCH queries.
// Wraps the query in double quotes for literal matching.
func sanitizeFTS5Query(query string) string {
	// Escape double quotes by doubling them
	escaped := strings.ReplaceAll(query, `"`, `""`)
	return `"` + escaped + `"`
}

// SearchMessages searches messages by text content.
// Uses FTS5 when available, falls back to LIKE.
func (s *MsgStore) SearchMessages(query string, limit int) ([]*Message, error) {
	if limit <= 0 {
		limit = 50
	}

	var rows *sql.Rows
	var err error

	if s.hasFTS {
		rows, err = s.db.Query(`
			SELECT m.id, m.chat_jid, m.sender_jid, m.timestamp, m.type, m.text, m.media_type, m.media_path, m.is_from_me, m.is_read, m.reply_to
			FROM messages m
			JOIN messages_fts fts ON m.rowid = fts.rowid
			WHERE messages_fts MATCH ?
			ORDER BY m.timestamp DESC
			LIMIT ?
		`, sanitizeFTS5Query(query), limit)
	} else {
		rows, err = s.db.Query(`
			SELECT id, chat_jid, sender_jid, timestamp, type, text, media_type, media_path, is_from_me, is_read, reply_to
			FROM messages
			WHERE text LIKE ? ESCAPE '\'
			ORDER BY timestamp DESC
			LIMIT ?
		`, "%"+escapeLike(query)+"%", limit)
	}
	if err != nil {
		return nil, fmt.Errorf("searching messages: %w", err)
	}
	defer rows.Close()

	return scanMessages(rows)
}

func scanMessages(rows *sql.Rows) ([]*Message, error) {
	var messages []*Message
	for rows.Next() {
		var msg Message
		var isFromMe, isRead int
		var text, mediaType, mediaPath, replyTo sql.NullString

		err := rows.Scan(
			&msg.ID, &msg.ChatJID, &msg.SenderJID, &msg.Timestamp, &msg.Type,
			&text, &mediaType, &mediaPath,
			&isFromMe, &isRead, &replyTo,
		)
		if err != nil {
			return nil, fmt.Errorf("scanning message row: %w", err)
		}

		msg.Text = text.String
		msg.MediaType = mediaType.String
		msg.MediaPath = mediaPath.String
		msg.ReplyTo = replyTo.String
		msg.IsFromMe = isFromMe != 0
		msg.IsRead = isRead != 0

		messages = append(messages, &msg)
	}
	return messages, rows.Err()
}

// escapeLike escapes SQL LIKE metacharacters (%, _, \) so user input
// is matched literally. Uses backslash as the ESCAPE character.
func escapeLike(s string) string {
	r := strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`)
	return r.Replace(s)
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}
