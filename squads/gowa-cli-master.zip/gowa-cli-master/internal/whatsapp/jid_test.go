package whatsapp

import (
	"testing"

	"go.mau.fi/whatsmeow/types"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
)

func TestParseJID_PhoneNumber(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		wantUser string
		wantSrv  string
	}{
		{"brazilian mobile", "5511999999999", "5511999999999", types.DefaultUserServer},
		{"us number", "12025551234", "12025551234", types.DefaultUserServer},
		{"short number", "1234567", "1234567", types.DefaultUserServer},
		{"max length", "123456789012345", "123456789012345", types.DefaultUserServer},
		{"with plus prefix", "+5511999999999", "5511999999999", types.DefaultUserServer},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jid, err := parseJID(tt.input)
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			if jid.User != tt.wantUser {
				t.Errorf("User = %q, want %q", jid.User, tt.wantUser)
			}
			if jid.Server != tt.wantSrv {
				t.Errorf("Server = %q, want %q", jid.Server, tt.wantSrv)
			}
		})
	}
}

func TestParseJID_FullJID(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		wantUser string
		wantSrv  string
	}{
		{"user JID", "5511999999999@s.whatsapp.net", "5511999999999", "s.whatsapp.net"},
		{"group JID", "120363001234567890@g.us", "120363001234567890", "g.us"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jid, err := parseJID(tt.input)
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			if jid.User != tt.wantUser {
				t.Errorf("User = %q, want %q", jid.User, tt.wantUser)
			}
			if jid.Server != tt.wantSrv {
				t.Errorf("Server = %q, want %q", jid.Server, tt.wantSrv)
			}
		})
	}
}

func TestParseJID_Errors(t *testing.T) {
	tests := []struct {
		name  string
		input string
		code  int
	}{
		{"empty string", "", 2},
		{"whitespace only", "   ", 2},
		{"too short", "123456", 2},
		{"too long", "1234567890123456", 2},
		{"letters mixed", "551199abc9999", 2},
		{"with dashes", "55-11-999999999", 2},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := parseJID(tt.input)
			if err == nil {
				t.Fatal("expected error, got nil")
			}
			cliErr, ok := err.(*clierr.CLIError)
			if !ok {
				t.Fatalf("expected CLIError, got %T", err)
			}
			if cliErr.Code != tt.code {
				t.Errorf("Code = %d, want %d", cliErr.Code, tt.code)
			}
		})
	}
}
