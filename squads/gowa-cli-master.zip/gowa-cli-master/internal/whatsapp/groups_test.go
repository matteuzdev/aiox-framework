package whatsapp

import (
	"encoding/json"
	"errors"
	"testing"
)

// Compile-time check: WaClient must implement GroupManager.
var _ GroupManager = (*WaClient)(nil)

func TestGroupSummary_JSONMarshal(t *testing.T) {
	s := GroupSummary{
		JID:              "120363012345678901@g.us",
		Name:             "Test Group",
		ParticipantCount: 5,
	}

	data, err := json.Marshal(s)
	if err != nil {
		t.Fatalf("json.Marshal(GroupSummary) failed: %v", err)
	}

	var decoded GroupSummary
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("json.Unmarshal(GroupSummary) failed: %v", err)
	}

	if decoded.JID != s.JID {
		t.Errorf("JID = %q, want %q", decoded.JID, s.JID)
	}
	if decoded.Name != s.Name {
		t.Errorf("Name = %q, want %q", decoded.Name, s.Name)
	}
	if decoded.ParticipantCount != s.ParticipantCount {
		t.Errorf("ParticipantCount = %d, want %d", decoded.ParticipantCount, s.ParticipantCount)
	}
}

func TestGroupDetail_JSONMarshal(t *testing.T) {
	d := GroupDetail{
		JID:              "120363012345678901@g.us",
		Name:             "Dev Team",
		Description:      "Development discussion",
		CreatedAt:        "2024-06-15T10:30:00Z",
		CreatorJID:       "5511999999999@s.whatsapp.net",
		ParticipantCount: 3,
		IsLocked:         true,
		IsAnnounce:       false,
		IsEphemeral:      true,
		Participants: []GroupMember{
			{JID: "5511999999999@s.whatsapp.net", DisplayName: "Admin", Role: "superadmin"},
			{JID: "5511888888888@s.whatsapp.net", DisplayName: "Mod", Role: "admin"},
			{JID: "5511777777777@s.whatsapp.net", DisplayName: "", Role: "member"},
		},
	}

	data, err := json.Marshal(d)
	if err != nil {
		t.Fatalf("json.Marshal(GroupDetail) failed: %v", err)
	}

	var decoded GroupDetail
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("json.Unmarshal(GroupDetail) failed: %v", err)
	}

	if decoded.JID != d.JID {
		t.Errorf("JID = %q, want %q", decoded.JID, d.JID)
	}
	if decoded.Name != d.Name {
		t.Errorf("Name = %q, want %q", decoded.Name, d.Name)
	}
	if decoded.Description != d.Description {
		t.Errorf("Description = %q, want %q", decoded.Description, d.Description)
	}
	if decoded.CreatedAt != d.CreatedAt {
		t.Errorf("CreatedAt = %q, want %q", decoded.CreatedAt, d.CreatedAt)
	}
	if decoded.CreatorJID != d.CreatorJID {
		t.Errorf("CreatorJID = %q, want %q", decoded.CreatorJID, d.CreatorJID)
	}
	if decoded.ParticipantCount != d.ParticipantCount {
		t.Errorf("ParticipantCount = %d, want %d", decoded.ParticipantCount, d.ParticipantCount)
	}
	if decoded.IsLocked != d.IsLocked {
		t.Errorf("IsLocked = %v, want %v", decoded.IsLocked, d.IsLocked)
	}
	if decoded.IsAnnounce != d.IsAnnounce {
		t.Errorf("IsAnnounce = %v, want %v", decoded.IsAnnounce, d.IsAnnounce)
	}
	if decoded.IsEphemeral != d.IsEphemeral {
		t.Errorf("IsEphemeral = %v, want %v", decoded.IsEphemeral, d.IsEphemeral)
	}
	if len(decoded.Participants) != len(d.Participants) {
		t.Fatalf("Participants len = %d, want %d", len(decoded.Participants), len(d.Participants))
	}
	for i, p := range decoded.Participants {
		if p.JID != d.Participants[i].JID {
			t.Errorf("Participants[%d].JID = %q, want %q", i, p.JID, d.Participants[i].JID)
		}
		if p.Role != d.Participants[i].Role {
			t.Errorf("Participants[%d].Role = %q, want %q", i, p.Role, d.Participants[i].Role)
		}
	}
}

func TestGroupDetail_JSONMarshal_NoParticipants(t *testing.T) {
	d := GroupDetail{
		JID:  "120363012345678901@g.us",
		Name: "Empty Group",
	}

	data, err := json.Marshal(d)
	if err != nil {
		t.Fatalf("json.Marshal failed: %v", err)
	}

	// participants should be omitted when nil
	var raw map[string]json.RawMessage
	if err := json.Unmarshal(data, &raw); err != nil {
		t.Fatalf("json.Unmarshal failed: %v", err)
	}
	if _, exists := raw["participants"]; exists {
		t.Error("participants field should be omitted when nil")
	}
}

func TestGroupMember_JSONMarshal(t *testing.T) {
	m := GroupMember{
		JID:         "5511999999999@s.whatsapp.net",
		DisplayName: "Alice",
		Role:        "admin",
	}

	data, err := json.Marshal(m)
	if err != nil {
		t.Fatalf("json.Marshal(GroupMember) failed: %v", err)
	}

	var decoded GroupMember
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatalf("json.Unmarshal(GroupMember) failed: %v", err)
	}

	if decoded != m {
		t.Errorf("decoded = %+v, want %+v", decoded, m)
	}
}

func TestWrapError_NotAuthorized(t *testing.T) {
	err := errors.New("not authorized to perform this action")
	result := wrapError("updating group", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "permission_error" {
		t.Errorf("Type = %q, want %q", result.Type, "permission_error")
	}
	if result.Code != 4 {
		t.Errorf("Code = %d, want 4", result.Code)
	}
}

func TestWrapError_NotAdmin(t *testing.T) {
	err := errors.New("not admin")
	result := wrapError("editing group info", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "permission_error" {
		t.Errorf("Type = %q, want %q", result.Type, "permission_error")
	}
	if result.Code != 4 {
		t.Errorf("Code = %d, want 4", result.Code)
	}
}

func TestWrapError_Forbidden(t *testing.T) {
	err := errors.New("forbidden")
	result := wrapError("getting invite link", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "permission_error" {
		t.Errorf("Type = %q, want %q", result.Type, "permission_error")
	}
	if result.Code != 4 {
		t.Errorf("Code = %d, want 4", result.Code)
	}
}

func TestWrapError_NotFound(t *testing.T) {
	err := errors.New("not found")
	result := wrapError("getting group info", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "not_found" {
		t.Errorf("Type = %q, want %q", result.Type, "not_found")
	}
	if result.Code != 3 {
		t.Errorf("Code = %d, want 3", result.Code)
	}
}

func TestWrapError_ItemNotFound(t *testing.T) {
	err := errors.New("item-not-found")
	result := wrapError("getting group", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "not_found" {
		t.Errorf("Type = %q, want %q", result.Type, "not_found")
	}
	if result.Code != 3 {
		t.Errorf("Code = %d, want 3", result.Code)
	}
}

func TestWrapError_GroupFull(t *testing.T) {
	err := errors.New("group is full")
	result := wrapError("adding participant", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "whatsapp_error" {
		t.Errorf("Type = %q, want %q", result.Type, "whatsapp_error")
	}
	if result.Code != 5 {
		t.Errorf("Code = %d, want 5", result.Code)
	}
}

func TestWrapError_ParticipantsLimit(t *testing.T) {
	err := errors.New("participants limit reached")
	result := wrapError("adding participant", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "whatsapp_error" {
		t.Errorf("Type = %q, want %q", result.Type, "whatsapp_error")
	}
	if result.Code != 5 {
		t.Errorf("Code = %d, want 5", result.Code)
	}
}
