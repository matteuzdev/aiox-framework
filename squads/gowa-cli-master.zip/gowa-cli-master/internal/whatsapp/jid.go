package whatsapp

import (
	"fmt"
	"regexp"
	"strings"

	"go.mau.fi/whatsmeow/types"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
)

var phoneRegex = regexp.MustCompile(`^\d{7,15}$`)

// parseJID converts a phone number (5511999999999) or JID string (5511999999999@s.whatsapp.net)
// to a types.JID. Returns a CLIError on invalid input.
func parseJID(input string) (types.JID, error) {
	input = strings.TrimSpace(input)
	input = strings.TrimPrefix(input, "+")
	if input == "" {
		return types.JID{}, &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  "Recipient is required",
			Recovery: "Provide a phone number (5511999999999) or JID (5511999999999@s.whatsapp.net)",
		}
	}

	// If it contains @, parse as a full JID string
	if strings.Contains(input, "@") {
		jid, err := types.ParseJID(input)
		if err != nil {
			return types.JID{}, &clierr.CLIError{
				Type:     "usage_error",
				Code:     2,
				Message:  fmt.Sprintf("Invalid JID: %s", input),
				Recovery: "Use format: 5511999999999@s.whatsapp.net, group-id@g.us, or newsletter-id@newsletter",
				Original: err,
			}
		}
		return jid, nil
	}

	// Numeric only — treat as phone number
	if !phoneRegex.MatchString(input) {
		return types.JID{}, &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  fmt.Sprintf("Invalid phone number: %s", input),
			Recovery: "Use E.164 format without '+': 5511999999999 (7-15 digits)",
		}
	}

	return types.NewJID(input, types.DefaultUserServer), nil
}
