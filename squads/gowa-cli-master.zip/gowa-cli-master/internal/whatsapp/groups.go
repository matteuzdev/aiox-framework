package whatsapp

import (
	"context"
	"time"

	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/types"
)

// GroupSummary is a lightweight representation of a WhatsApp group.
type GroupSummary struct {
	JID              string `json:"jid"`
	Name             string `json:"name"`
	ParticipantCount int    `json:"participant_count"`
	LastActivity     string `json:"last_activity,omitempty"` // RFC3339, populated by caller via msgstore
}

// GroupDetail is a full representation of a WhatsApp group with metadata.
type GroupDetail struct {
	JID              string        `json:"jid"`
	Name             string        `json:"name"`
	Description      string        `json:"description"`
	CreatedAt        string        `json:"created_at"` // RFC3339
	CreatorJID       string        `json:"creator_jid"`
	ParticipantCount int           `json:"participant_count"`
	IsLocked         bool          `json:"is_locked"`
	IsAnnounce       bool          `json:"is_announce"`
	IsEphemeral      bool          `json:"is_ephemeral"`
	Participants     []GroupMember `json:"participants,omitempty"`
}

// GroupMember represents a participant in a WhatsApp group.
type GroupMember struct {
	JID         string `json:"jid"`
	DisplayName string `json:"display_name"`
	Role        string `json:"role"` // "superadmin", "admin", "member"
}

// GroupManager defines the interface for WhatsApp group operations.
// Consumer-defined interface for testing/mocking.
type GroupManager interface {
	GetJoinedGroups(ctx context.Context) ([]GroupSummary, error)
	GetGroupInfo(ctx context.Context, jid string) (*GroupDetail, error)
	CreateGroup(ctx context.Context, name string, participants []string) (*GroupDetail, error)
	LeaveGroup(ctx context.Context, jid string) error
	GetGroupInviteLink(ctx context.Context, jid string, reset bool) (string, error)
	JoinGroupWithLink(ctx context.Context, code string) (string, error)
	GetGroupInfoFromLink(ctx context.Context, code string) (*GroupDetail, error)
}

// GetJoinedGroups returns a list of all groups the user is a member of.
func (w *WaClient) GetJoinedGroups(ctx context.Context) ([]GroupSummary, error) {
	groups, err := w.client.GetJoinedGroups(ctx)
	if err != nil {
		return nil, wrapError("getting joined groups", err)
	}

	summaries := make([]GroupSummary, len(groups))
	for i, gi := range groups {
		summaries[i] = GroupSummary{
			JID:              gi.JID.String(),
			Name:             gi.Name,
			ParticipantCount: gi.ParticipantCount,
		}
	}
	return summaries, nil
}

// GetGroupInfo returns detailed information about a specific group.
func (w *WaClient) GetGroupInfo(ctx context.Context, jid string) (*GroupDetail, error) {
	groupJID, err := parseJID(jid)
	if err != nil {
		return nil, err
	}

	gi, err := w.client.GetGroupInfo(ctx, groupJID)
	if err != nil {
		return nil, wrapError("getting group info", err)
	}

	return groupInfoToDetail(gi), nil
}

// CreateGroup creates a new WhatsApp group with the given name and participants.
func (w *WaClient) CreateGroup(ctx context.Context, name string, participants []string) (*GroupDetail, error) {
	jids := make([]types.JID, len(participants))
	for i, p := range participants {
		jid, err := parseJID(p)
		if err != nil {
			return nil, err
		}
		jids[i] = jid
	}

	req := whatsmeow.ReqCreateGroup{
		Name:         name,
		Participants: jids,
	}

	gi, err := w.client.CreateGroup(ctx, req)
	if err != nil {
		return nil, wrapError("creating group", err)
	}

	return groupInfoToDetail(gi), nil
}

// LeaveGroup exits the specified group.
func (w *WaClient) LeaveGroup(ctx context.Context, jid string) error {
	groupJID, err := parseJID(jid)
	if err != nil {
		return err
	}

	if err := w.client.LeaveGroup(ctx, groupJID); err != nil {
		return wrapError("leaving group", err)
	}
	return nil
}

// GetGroupInviteLink returns the invite link for a group. If reset is true,
// the existing link is revoked and a new one is generated.
func (w *WaClient) GetGroupInviteLink(ctx context.Context, jid string, reset bool) (string, error) {
	groupJID, err := parseJID(jid)
	if err != nil {
		return "", err
	}

	link, err := w.client.GetGroupInviteLink(ctx, groupJID, reset)
	if err != nil {
		return "", wrapError("getting group invite link", err)
	}
	return link, nil
}

// JoinGroupWithLink joins a group using an invite code or URL.
// Returns the JID of the joined group.
func (w *WaClient) JoinGroupWithLink(ctx context.Context, code string) (string, error) {
	groupJID, err := w.client.JoinGroupWithLink(ctx, code)
	if err != nil {
		return "", wrapError("joining group with link", err)
	}
	return groupJID.String(), nil
}

// GetGroupInfoFromLink returns group information from an invite code or URL
// without joining the group.
func (w *WaClient) GetGroupInfoFromLink(ctx context.Context, code string) (*GroupDetail, error) {
	gi, err := w.client.GetGroupInfoFromLink(ctx, code)
	if err != nil {
		return nil, wrapError("getting group info from link", err)
	}
	return groupInfoToDetail(gi), nil
}

// groupInfoToDetail converts a whatsmeow types.GroupInfo to our GroupDetail.
func groupInfoToDetail(gi *types.GroupInfo) *GroupDetail {
	detail := &GroupDetail{
		JID:              gi.JID.String(),
		Name:             gi.Name,
		Description:      gi.Topic,
		CreatorJID:       gi.OwnerJID.String(),
		ParticipantCount: gi.ParticipantCount,
		IsLocked:         gi.IsLocked,
		IsAnnounce:       gi.IsAnnounce,
		IsEphemeral:      gi.IsEphemeral,
	}

	if !gi.GroupCreated.IsZero() {
		detail.CreatedAt = gi.GroupCreated.UTC().Format(time.RFC3339)
	}

	// Use len(Participants) if ParticipantCount is zero but participants are present
	if detail.ParticipantCount == 0 && len(gi.Participants) > 0 {
		detail.ParticipantCount = len(gi.Participants)
	}

	if len(gi.Participants) > 0 {
		detail.Participants = make([]GroupMember, len(gi.Participants))
		for i, p := range gi.Participants {
			role := "member"
			if p.IsSuperAdmin {
				role = "superadmin"
			} else if p.IsAdmin {
				role = "admin"
			}
			detail.Participants[i] = GroupMember{
				JID:         p.JID.String(),
				DisplayName: p.DisplayName,
				Role:        role,
			}
		}
	}

	return detail
}
