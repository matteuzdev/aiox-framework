package whatsapp

import (
	"sync"
	"testing"
	"time"
)

func TestSafeGo_NormalExecution(t *testing.T) {
	var wg sync.WaitGroup
	var executed bool

	wg.Add(1)
	safeGo(func() {
		defer wg.Done()
		executed = true
	})

	wg.Wait()
	if !executed {
		t.Error("function should have executed")
	}
}

func TestSafeGo_PanicRecovery(t *testing.T) {
	done := make(chan struct{})

	// This should NOT crash the test process
	safeGo(func() {
		defer func() { close(done) }()
		panic("simulated whatsmeow panic (#964)")
	})

	select {
	case <-done:
		// Panic was recovered — test passes
	case <-time.After(2 * time.Second):
		t.Fatal("safeGo did not recover from panic within timeout")
	}
}

func TestSafeGo_NilPanicRecovery(t *testing.T) {
	done := make(chan struct{})

	safeGo(func() {
		defer func() { close(done) }()
		panic(nil)
	})

	select {
	case <-done:
		// Recovered
	case <-time.After(2 * time.Second):
		t.Fatal("safeGo did not recover from nil panic within timeout")
	}
}

func TestSafeGo_MultipleConcurrent(t *testing.T) {
	var wg sync.WaitGroup
	count := 10
	results := make([]bool, count)

	for i := 0; i < count; i++ {
		wg.Add(1)
		idx := i
		safeGo(func() {
			defer wg.Done()
			results[idx] = true
		})
	}

	wg.Wait()
	for i, ok := range results {
		if !ok {
			t.Errorf("goroutine %d did not execute", i)
		}
	}
}
