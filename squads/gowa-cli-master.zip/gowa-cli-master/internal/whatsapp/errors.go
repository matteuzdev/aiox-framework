package whatsapp

import (
	"errors"
	"fmt"
	"strings"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"go.mau.fi/whatsmeow"
)

// wrapError wraps a whatsmeow or internal error into a CLIError
// for consistent error handling across the CLI.
// It maps known whatsmeow sentinel errors to specific exit codes:
//   - ErrNotLoggedIn, ErrNoSession → 7 (session expired)
//   - ErrNotConnected, ErrMessageTimedOut → 5 (server/connection error)
//   - ErrQRStoreContainsID, ErrBroadcastListUnsupported, ErrRecipientADJID → 2 (usage error)
//   - unknown errors → 1 (general)
func wrapError(operation string, err error) *clierr.CLIError {
	if err == nil {
		return nil
	}

	// If already a CLIError, return as-is
	if cliErr, ok := err.(*clierr.CLIError); ok {
		return cliErr
	}

	// Map known whatsmeow errors to specific exit codes
	switch {
	// Session expired — need to re-pair
	case errors.Is(err, whatsmeow.ErrNotLoggedIn):
		return &clierr.CLIError{
			Type:     "auth_error",
			Code:     7,
			Message:  fmt.Sprintf("WhatsApp session expired (%s): %s", operation, err.Error()),
			Recovery: "Session expired. Run 'gowa pair' to re-authenticate",
			Original: err,
		}
	case errors.Is(err, whatsmeow.ErrNoSession):
		return &clierr.CLIError{
			Type:     "auth_error",
			Code:     7,
			Message:  fmt.Sprintf("WhatsApp session not found (%s): %s", operation, err.Error()),
			Recovery: "No active session. Run 'gowa pair' to authenticate",
			Original: err,
		}

	// Connection / server errors
	case errors.Is(err, whatsmeow.ErrNotConnected):
		return &clierr.CLIError{
			Type:     "connection_error",
			Code:     5,
			Message:  fmt.Sprintf("WhatsApp not connected (%s): %s", operation, err.Error()),
			Recovery: "Check your internet connection. Run 'gowa daemon status' for details",
			Original: err,
		}
	case errors.Is(err, whatsmeow.ErrMessageTimedOut):
		return &clierr.CLIError{
			Type:     "server_error",
			Code:     5,
			Message:  fmt.Sprintf("WhatsApp message timed out (%s): %s", operation, err.Error()),
			Recovery: "Message send timed out. Try again or check 'gowa daemon status'",
			Original: err,
		}

	// Usage errors — bad input or unsupported operation
	case errors.Is(err, whatsmeow.ErrQRStoreContainsID):
		return &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  fmt.Sprintf("WhatsApp error (%s): %s", operation, err.Error()),
			Recovery: "Device is already paired. Use 'gowa device list' to check active devices",
			Original: err,
		}
	case errors.Is(err, whatsmeow.ErrBroadcastListUnsupported):
		return &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  fmt.Sprintf("WhatsApp error (%s): %s", operation, err.Error()),
			Recovery: "Broadcast lists are not supported. Send messages individually instead",
			Original: err,
		}
	case errors.Is(err, whatsmeow.ErrRecipientADJID):
		return &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  fmt.Sprintf("WhatsApp error (%s): %s", operation, err.Error()),
			Recovery: "Invalid recipient JID. Use a user JID without device part (e.g., 5511999999999@s.whatsapp.net)",
			Original: err,
		}

	// Group-specific errors
	case strings.Contains(err.Error(), "not authorized"),
		strings.Contains(err.Error(), "not admin"),
		strings.Contains(err.Error(), "forbidden"):
		return &clierr.CLIError{
			Type:     "permission_error",
			Code:     4,
			Message:  fmt.Sprintf("Permission denied (%s): %s", operation, err.Error()),
			Recovery: "You must be a group admin for this operation",
			Original: err,
		}
	case strings.Contains(err.Error(), "not found"),
		strings.Contains(err.Error(), "item-not-found"):
		return &clierr.CLIError{
			Type:     "not_found",
			Code:     3,
			Message:  fmt.Sprintf("Not found (%s): %s", operation, err.Error()),
			Recovery: "Group may have been deleted or JID is incorrect",
			Original: err,
		}
	case strings.Contains(err.Error(), "group is full"),
		strings.Contains(err.Error(), "participants limit"):
		return &clierr.CLIError{
			Type:     "whatsapp_error",
			Code:     5,
			Message:  fmt.Sprintf("Group full (%s): %s", operation, err.Error()),
			Recovery: "Group has reached maximum capacity (1024 members)",
			Original: err,
		}

	// IQ timeout / media connection errors — transient network issues
	case strings.Contains(err.Error(), "IQ timeout"),
		strings.Contains(err.Error(), "iq timed out"):
		return &clierr.CLIError{
			Type:     "server_error",
			Code:     5,
			Message:  fmt.Sprintf("WhatsApp IQ request timed out (%s): %s", operation, err.Error()),
			Recovery: "Server request timed out. Check connection and try again",
			Original: err,
		}
	case strings.Contains(err.Error(), "failed to connect to media"),
		strings.Contains(err.Error(), "media upload"):
		return &clierr.CLIError{
			Type:     "server_error",
			Code:     5,
			Message:  fmt.Sprintf("WhatsApp media connection failed (%s): %s", operation, err.Error()),
			Recovery: "Media server unreachable. Check internet and try again",
			Original: err,
		}

	// "no LID found" — upstream whatsmeow issue after fresh pairing
	case strings.Contains(err.Error(), "no LID found"):
		return &clierr.CLIError{
			Type:     "whatsapp_error",
			Code:     5,
			Message:  fmt.Sprintf("WhatsApp error (%s): %s", operation, err.Error()),
			Recovery: "This may happen after fresh pairing. Wait 2-3 minutes for WhatsApp to sync, then retry. If persistent, restart daemon with 'gowa daemon stop && gowa daemon start'.",
			Original: err,
		}

	// Default — unknown error
	default:
		return &clierr.CLIError{
			Type:     "general",
			Code:     1,
			Message:  fmt.Sprintf("WhatsApp error (%s): %s", operation, err.Error()),
			Recovery: "Check your WhatsApp connection. Run 'gowa daemon status' for details",
			Original: err,
		}
	}
}
