package whatsapp

import (
	"errors"
	"fmt"
	"testing"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"go.mau.fi/whatsmeow"
)

func TestWrapError_NilError(t *testing.T) {
	result := wrapError("test", nil)
	if result != nil {
		t.Errorf("expected nil, got %v", result)
	}
}

func TestWrapError_CLIErrorPassthrough(t *testing.T) {
	original := &clierr.CLIError{
		Type:    "auth_error",
		Code:    3,
		Message: "not authenticated",
	}

	result := wrapError("sending", original)
	if result != original {
		t.Error("CLIError should pass through unchanged")
	}
}

func TestWrapError_ErrNotLoggedIn(t *testing.T) {
	result := wrapError("sending", whatsmeow.ErrNotLoggedIn)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "auth_error" {
		t.Errorf("Type = %q, want %q", result.Type, "auth_error")
	}
	if result.Code != 7 {
		t.Errorf("Code = %d, want 7", result.Code)
	}
	if result.Original != whatsmeow.ErrNotLoggedIn {
		t.Error("Original should reference ErrNotLoggedIn")
	}
}

func TestWrapError_ErrNoSession(t *testing.T) {
	result := wrapError("encrypting", whatsmeow.ErrNoSession)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "auth_error" {
		t.Errorf("Type = %q, want %q", result.Type, "auth_error")
	}
	if result.Code != 7 {
		t.Errorf("Code = %d, want 7", result.Code)
	}
	if result.Original != whatsmeow.ErrNoSession {
		t.Error("Original should reference ErrNoSession")
	}
}

func TestWrapError_ErrNotConnected(t *testing.T) {
	result := wrapError("connecting", whatsmeow.ErrNotConnected)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "connection_error" {
		t.Errorf("Type = %q, want %q", result.Type, "connection_error")
	}
	if result.Code != 5 {
		t.Errorf("Code = %d, want 5", result.Code)
	}
	if result.Original != whatsmeow.ErrNotConnected {
		t.Error("Original should reference ErrNotConnected")
	}
}

func TestWrapError_ErrMessageTimedOut(t *testing.T) {
	result := wrapError("sending", whatsmeow.ErrMessageTimedOut)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "server_error" {
		t.Errorf("Type = %q, want %q", result.Type, "server_error")
	}
	if result.Code != 5 {
		t.Errorf("Code = %d, want 5", result.Code)
	}
	if result.Original != whatsmeow.ErrMessageTimedOut {
		t.Error("Original should reference ErrMessageTimedOut")
	}
}

func TestWrapError_ErrQRStoreContainsID(t *testing.T) {
	result := wrapError("pairing", whatsmeow.ErrQRStoreContainsID)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "usage_error" {
		t.Errorf("Type = %q, want %q", result.Type, "usage_error")
	}
	if result.Code != 2 {
		t.Errorf("Code = %d, want 2", result.Code)
	}
	if result.Original != whatsmeow.ErrQRStoreContainsID {
		t.Error("Original should reference ErrQRStoreContainsID")
	}
}

func TestWrapError_ErrBroadcastListUnsupported(t *testing.T) {
	result := wrapError("sending", whatsmeow.ErrBroadcastListUnsupported)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "usage_error" {
		t.Errorf("Type = %q, want %q", result.Type, "usage_error")
	}
	if result.Code != 2 {
		t.Errorf("Code = %d, want 2", result.Code)
	}
	if result.Original != whatsmeow.ErrBroadcastListUnsupported {
		t.Error("Original should reference ErrBroadcastListUnsupported")
	}
}

func TestWrapError_ErrRecipientADJID(t *testing.T) {
	result := wrapError("sending", whatsmeow.ErrRecipientADJID)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "usage_error" {
		t.Errorf("Type = %q, want %q", result.Type, "usage_error")
	}
	if result.Code != 2 {
		t.Errorf("Code = %d, want 2", result.Code)
	}
	if result.Original != whatsmeow.ErrRecipientADJID {
		t.Error("Original should reference ErrRecipientADJID")
	}
}

func TestWrapError_UnknownError(t *testing.T) {
	err := errors.New("something unexpected")
	result := wrapError("processing", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "general" {
		t.Errorf("Type = %q, want %q", result.Type, "general")
	}
	if result.Code != 1 {
		t.Errorf("Code = %d, want 1", result.Code)
	}
	if result.Original != err {
		t.Error("Original should reference the wrapped error")
	}
	if result.Recovery == "" {
		t.Error("Recovery hint should not be empty")
	}
}

func TestWrapError_WrappedWhatsmeowError(t *testing.T) {
	// errors.Is should match wrapped sentinel errors too
	wrapped := fmt.Errorf("failed to send: %w", whatsmeow.ErrNotLoggedIn)
	result := wrapError("sending", wrapped)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	if result.Type != "auth_error" {
		t.Errorf("Type = %q, want %q", result.Type, "auth_error")
	}
	if result.Code != 7 {
		t.Errorf("Code = %d, want 7", result.Code)
	}
}

func TestWrapError_MessageContainsOperation(t *testing.T) {
	err := whatsmeow.ErrNotConnected
	result := wrapError("uploading image", err)

	if result == nil {
		t.Fatal("expected CLIError, got nil")
	}
	want := fmt.Sprintf("WhatsApp not connected (uploading image): %s", err.Error())
	if result.Message != want {
		t.Errorf("Message = %q, want %q", result.Message, want)
	}
}
