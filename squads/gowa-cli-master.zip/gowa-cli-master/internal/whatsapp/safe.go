package whatsapp

import (
	"context"
	"log/slog"
	"runtime/debug"
	"sync"
)

// SafeGo runs fn in a goroutine with panic recovery.
// Prevents whatsmeow event handler panics (e.g., issue #964 nil SenderChainKey)
// from crashing the entire process. Exported for use by daemon package.
func SafeGo(fn func()) {
	safeGo(fn)
}

// SafeGoCtx runs fn in a goroutine with panic recovery and lifecycle tracking.
// The goroutine is tracked via the WaitGroup and respects context cancellation.
func SafeGoCtx(ctx context.Context, wg *sync.WaitGroup, fn func(ctx context.Context)) {
	wg.Add(1)
	go func() {
		defer wg.Done()
		defer func() {
			if r := recover(); r != nil {
				slog.Error("panic recovered in goroutine",
					"panic", r,
					"stack", string(debug.Stack()),
				)
			}
		}()
		fn(ctx)
	}()
}

// safeGo is the internal implementation.
func safeGo(fn func()) {
	go func() {
		defer func() {
			if r := recover(); r != nil {
				slog.Error("panic recovered in goroutine",
					"panic", r,
					"stack", string(debug.Stack()),
				)
			}
		}()
		fn()
	}()
}
