package whatsapp

import (
	"context"
	"fmt"
	"log/slog"
	"mime"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"

	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/proto/waCompanionReg"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/store"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	"google.golang.org/protobuf/proto"

	_ "modernc.org/sqlite" // register "sqlite" driver for sqlstore
)

// SendResult represents the result of a sent message.
type SendResult struct {
	MessageID string `json:"message_id"`
	Timestamp int64  `json:"timestamp"`
	Status    string `json:"status"`
}

// Messenger defines the interface for WhatsApp messaging operations.
// Consumer-defined interface for testing/mocking.
type Messenger interface {
	Connect(ctx context.Context) error
	Disconnect()
	SendText(ctx context.Context, to, message, replyTo string) (SendResult, error)
	SendImage(ctx context.Context, to, filePath, caption string) (SendResult, error)
	SendFile(ctx context.Context, to, filePath string) (SendResult, error)
	IsConnected() bool
	IsLoggedIn() bool
	NeedsPairing() bool
	Close() error
}

// WaClient wraps whatsmeow.Client with a clean Go interface.
type WaClient struct {
	client    *whatsmeow.Client
	container *sqlstore.Container
	log       waLog.Logger
	sessionDB string
	sendMu    sync.Mutex // protects send operations from concurrent interleaving
}

var devicePropsOnce sync.Once

// initDeviceProps sets the global store.DeviceProps exactly once,
// avoiding race conditions when multiple WaClient instances are
// created concurrently (e.g., in parallel tests).
func initDeviceProps() {
	devicePropsOnce.Do(func() {
		store.DeviceProps.Os = proto.String("GOWA CLI")
		store.DeviceProps.PlatformType = waCompanionReg.DeviceProps_CHROME.Enum()
	})
}

// NewWaClient creates a new WhatsApp client backed by SQLite session storage.
// dbPath is the path to the session database file (e.g., ~/.config/gowa/session.db).
// ctx is used for database operations during initialization.
func NewWaClient(ctx context.Context, dbPath string, log waLog.Logger) (*WaClient, error) {
	if log == nil {
		log = waLog.Noop
	}

	// Ensure parent directory exists
	dir := filepath.Dir(dbPath)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return nil, wrapError("creating session directory", err)
	}

	connStr := fmt.Sprintf("file:%s?_pragma=foreign_keys(1)&_pragma=busy_timeout(10000)", dbPath)
	container, err := sqlstore.New(ctx, "sqlite", connStr, log.Sub("SQLStore"))
	if err != nil {
		return nil, wrapError("opening session database", err)
	}

	deviceStore, err := container.GetFirstDevice(ctx)
	if err != nil {
		container.Close() // L-13: prevent SQLite leak on partial init failure
		return nil, wrapError("getting device store", err)
	}

	// Set device identity — appears in WhatsApp "Linked Devices" list
	initDeviceProps()

	client := whatsmeow.NewClient(deviceStore, log.Sub("Client"))
	client.EnableAutoReconnect = true // whatsmeow handles reconnect with exponential backoff

	// Set PushName — required before SendPresence works
	// Without this, whatsmeow fails with "can't send presence without PushName set"
	if deviceStore.PushName == "" {
		deviceStore.PushName = "GOWA CLI"
	}

	// Set file permissions on session.db (0600)
	if _, statErr := os.Stat(dbPath); statErr == nil {
		if chmodErr := os.Chmod(dbPath, 0600); chmodErr != nil {
			slog.Warn("failed to set session.db permissions", "error", chmodErr)
		}
	}

	return &WaClient{
		client:    client,
		container: container,
		log:       log,
		sessionDB: dbPath,
	}, nil
}

// Connect establishes the WebSocket connection to WhatsApp.
// Uses ConnectContext for proper cancellation/timeout propagation.
// Sets presence to "unavailable" to preserve phone notifications.
func (w *WaClient) Connect(ctx context.Context) error {
	if err := w.client.ConnectContext(ctx); err != nil {
		return wrapError("connecting to WhatsApp", err)
	}

	// Set presence to unavailable — preserves push notifications on user's phone
	// See: whatsmeow discussion #1070
	if err := w.client.SendPresence(ctx, types.PresenceUnavailable); err != nil {
		slog.Warn("failed to set presence to unavailable", "error", err)
	}

	return nil
}

// Disconnect closes the WebSocket connection gracefully.
func (w *WaClient) Disconnect() {
	w.client.Disconnect()
}

// IsConnected returns true if the WebSocket is connected.
func (w *WaClient) IsConnected() bool {
	return w.client.IsConnected()
}

// IsLoggedIn returns true if the client is authenticated with WhatsApp.
func (w *WaClient) IsLoggedIn() bool {
	return w.client.IsLoggedIn()
}

// NeedsPairing returns true when no session exists (first use).
func (w *WaClient) NeedsPairing() bool {
	return w.client.Store.ID == nil
}

// SendText sends a text message to the given recipient.
func (w *WaClient) SendText(ctx context.Context, to, message, replyTo string) (SendResult, error) {
	w.sendMu.Lock()
	defer w.sendMu.Unlock()

	jid, err := parseJID(to)
	if err != nil {
		return SendResult{}, err
	}

	msg := &waE2E.Message{
		Conversation: proto.String(message),
	}

	// If replying to a message, use ExtendedTextMessage with ContextInfo
	if replyTo != "" {
		ctxInfo := &waE2E.ContextInfo{
			StanzaID: proto.String(replyTo),
		}
		// L-9: For group messages, Participant is required in ContextInfo
		if jid.Server == types.GroupServer {
			ownJID := w.client.Store.ID.String()
			ctxInfo.Participant = proto.String(ownJID)
		}
		msg = &waE2E.Message{
			ExtendedTextMessage: &waE2E.ExtendedTextMessage{
				Text:        proto.String(message),
				ContextInfo: ctxInfo,
			},
		}
	}

	resp, err := w.client.SendMessage(ctx, jid, msg)
	if err != nil {
		return SendResult{}, wrapError("sending text message", err)
	}

	return SendResult{
		MessageID: string(resp.ID),
		Timestamp: resp.Timestamp.Unix(),
		Status:    "sent",
	}, nil
}

const (
	maxImageSize = 16 * 1024 * 1024  // 16MB
	maxDocSize   = 100 * 1024 * 1024 // 100MB
)

func checkFileSize(path string, maxBytes int64, fileType string) error {
	info, err := os.Stat(path)
	if err != nil {
		return wrapError("checking file size", err)
	}
	if info.Size() > maxBytes {
		return &clierr.CLIError{
			Type:     "usage_error",
			Code:     2,
			Message:  fmt.Sprintf("File too large: %s is %dMB, max for %s is %dMB", path, info.Size()/(1024*1024), fileType, maxBytes/(1024*1024)),
			Recovery: fmt.Sprintf("Use a file smaller than %dMB", maxBytes/(1024*1024)),
		}
	}
	return nil
}

// SendImage sends an image with optional caption to the given recipient.
func (w *WaClient) SendImage(ctx context.Context, to, filePath, caption string) (SendResult, error) {
	w.sendMu.Lock()
	defer w.sendMu.Unlock()

	jid, err := parseJID(to)
	if err != nil {
		return SendResult{}, err
	}

	if err := checkFileSize(filePath, maxImageSize, "image"); err != nil {
		return SendResult{}, err
	}

	data, err := os.ReadFile(filePath)
	if err != nil {
		return SendResult{}, wrapError("reading image file", err)
	}

	uploadResp, err := w.client.Upload(ctx, data, whatsmeow.MediaImage)
	if err != nil {
		return SendResult{}, wrapError("uploading image", err)
	}

	mimeType := detectMIME(filePath, data)

	msg := &waE2E.Message{
		ImageMessage: &waE2E.ImageMessage{
			Caption:       proto.String(caption),
			Mimetype:      proto.String(mimeType),
			URL:           &uploadResp.URL,
			DirectPath:    &uploadResp.DirectPath,
			MediaKey:      uploadResp.MediaKey,
			FileEncSHA256: uploadResp.FileEncSHA256,
			FileSHA256:    uploadResp.FileSHA256,
			FileLength:    &uploadResp.FileLength,
		},
	}

	resp, err := w.client.SendMessage(ctx, jid, msg)
	if err != nil {
		return SendResult{}, wrapError("sending image message", err)
	}

	return SendResult{
		MessageID: string(resp.ID),
		Timestamp: resp.Timestamp.Unix(),
		Status:    "sent",
	}, nil
}

// SendFile sends a document to the given recipient.
func (w *WaClient) SendFile(ctx context.Context, to, filePath string) (SendResult, error) {
	w.sendMu.Lock()
	defer w.sendMu.Unlock()

	jid, err := parseJID(to)
	if err != nil {
		return SendResult{}, err
	}

	if err := checkFileSize(filePath, maxDocSize, "document"); err != nil {
		return SendResult{}, err
	}

	data, err := os.ReadFile(filePath)
	if err != nil {
		return SendResult{}, wrapError("reading file", err)
	}

	uploadResp, err := w.client.Upload(ctx, data, whatsmeow.MediaDocument)
	if err != nil {
		return SendResult{}, wrapError("uploading file", err)
	}

	mimeType := detectMIME(filePath, data)
	fileName := filepath.Base(filePath)

	msg := &waE2E.Message{
		DocumentMessage: &waE2E.DocumentMessage{
			Title:         proto.String(fileName),
			FileName:      proto.String(fileName),
			Mimetype:      proto.String(mimeType),
			URL:           &uploadResp.URL,
			DirectPath:    &uploadResp.DirectPath,
			MediaKey:      uploadResp.MediaKey,
			FileEncSHA256: uploadResp.FileEncSHA256,
			FileSHA256:    uploadResp.FileSHA256,
			FileLength:    &uploadResp.FileLength,
		},
	}

	resp, err := w.client.SendMessage(ctx, jid, msg)
	if err != nil {
		return SendResult{}, wrapError("sending file message", err)
	}

	return SendResult{
		MessageID: string(resp.ID),
		Timestamp: resp.Timestamp.Unix(),
		Status:    "sent",
	}, nil
}

// GetQRChannel returns a channel for receiving QR pairing events.
// Must be called BEFORE Connect() when Store.ID is nil.
func (w *WaClient) GetQRChannel(ctx context.Context) (<-chan whatsmeow.QRChannelItem, error) {
	ch, err := w.client.GetQRChannel(ctx)
	if err != nil {
		return nil, wrapError("getting QR channel", err)
	}
	return ch, nil
}

// PairPhone initiates phone number pairing and returns the pairing code.
func (w *WaClient) PairPhone(ctx context.Context, phone string) (string, error) {
	code, err := w.client.PairPhone(ctx, phone, true, whatsmeow.PairClientChrome, "Chrome (Linux)")
	if err != nil {
		return "", wrapError("pairing phone", err)
	}
	return code, nil
}

// SendChatPresence sends a typing indicator (composing/paused) to a chat.
func (w *WaClient) SendChatPresence(ctx context.Context, chatJID string, composing bool) error {
	jid, err := parseJID(chatJID)
	if err != nil {
		return err
	}

	state := types.ChatPresencePaused
	if composing {
		state = types.ChatPresenceComposing
	}

	return w.client.SendChatPresence(ctx, jid, state, "")
}

// OnMessage registers a handler for incoming messages.
func (w *WaClient) OnMessage(handler func(evt *events.Message)) {
	w.client.AddEventHandler(func(evt any) {
		if msg, ok := evt.(*events.Message); ok {
			safeGo(func() {
				handler(msg)
			})
		}
	})
}

// OnHistorySync registers a handler for history sync events.
func (w *WaClient) OnHistorySync(handler func(evt *events.HistorySync)) {
	w.client.AddEventHandler(func(evt any) {
		if hs, ok := evt.(*events.HistorySync); ok {
			safeGo(func() {
				handler(hs)
			})
		}
	})
}

// OnDisconnect registers a handler for disconnect events.
func (w *WaClient) OnDisconnect(handler func(evt *events.Disconnected)) {
	w.client.AddEventHandler(func(evt any) {
		if dc, ok := evt.(*events.Disconnected); ok {
			safeGo(func() {
				handler(dc)
			})
		}
	})
}

// Logout sends the WhatsApp unlink IQ to the server, disconnecting this
// linked device. The context controls the timeout.
func (w *WaClient) Logout(ctx context.Context) error {
	return w.client.Logout(ctx)
}

// Close disconnects and closes the session database. Implements io.Closer.
func (w *WaClient) Close() error {
	w.client.Disconnect()
	return w.container.Close()
}

// UnderlyingClient returns the raw whatsmeow client for advanced usage.
// Use sparingly — prefer the wrapper methods.
func (w *WaClient) UnderlyingClient() *whatsmeow.Client {
	return w.client
}

// detectMIME returns the MIME type for a file, using extension first, then content sniffing.
// L-10: Explicit handling for .webp and .opus which net/http may misdetect.
func detectMIME(filePath string, data []byte) string {
	ext := strings.ToLower(filepath.Ext(filePath))
	// Handle extensions that net/http and mime package may not detect correctly
	switch ext {
	case ".webp":
		return "image/webp"
	case ".opus":
		return "audio/ogg"
	}
	if ext != "" {
		if mimeType := mime.TypeByExtension(ext); mimeType != "" {
			return mimeType
		}
	}
	return http.DetectContentType(data)
}
