package clierr

import "fmt"

// CLIError is the standard error type for all gowa-cli errors.
// It provides structured error information for both human and agent consumption.
type CLIError struct {
	Type     string `json:"type"`
	Code     int    `json:"code"`
	Message  string `json:"message"`
	Recovery string `json:"recovery,omitempty"`
	Original error  `json:"-"`
}

func (e *CLIError) Error() string {
	if e.Recovery != "" {
		return fmt.Sprintf("%s\n  Hint: %s", e.Message, e.Recovery)
	}
	return e.Message
}

func (e *CLIError) ExitCode() int {
	return e.Code
}

func (e *CLIError) Unwrap() error {
	return e.Original
}
