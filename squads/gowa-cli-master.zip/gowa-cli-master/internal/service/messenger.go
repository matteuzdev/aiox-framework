package service

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"strings"
	"time"

	"github.com/murilloimparavel/gowa-cli/internal/clierr"
	"github.com/murilloimparavel/gowa-cli/internal/daemon"
	"github.com/murilloimparavel/gowa-cli/internal/safety"
)

// SendResult holds the outcome of a send operation.
type SendResult struct {
	MessageID string `json:"message_id"`
	Status    string `json:"status"`
}

// Messenger is the unified interface for sending WhatsApp messages.
type Messenger interface {
	SendText(ctx context.Context, to, message, replyTo string) (*SendResult, error)
	SendImage(ctx context.Context, to, filePath, caption string) (*SendResult, error)
	SendFile(ctx context.Context, to, filePath string) (*SendResult, error)
	Close() error
}

// DaemonMessenger sends messages via the daemon Unix socket.
type DaemonMessenger struct {
	client    *daemon.Client
	auditPath string
}

// NewDaemonMessenger creates a messenger that routes through the daemon.
func NewDaemonMessenger(dc *daemon.Client) *DaemonMessenger {
	return &DaemonMessenger{
		client:    dc,
		auditPath: safety.DefaultAuditPath(),
	}
}

// logAudit records a send operation to the audit log.
func (m *DaemonMessenger) logAudit(operation, recipient, result string, sendErr error) {
	entry := safety.AuditEntry{
		Timestamp: time.Now().UTC().Format(time.RFC3339),
		Operation: operation,
		Recipient: recipient,
		Result:    result,
	}
	if sendErr != nil {
		entry.ErrorMessage = sendErr.Error()
	}
	if err := safety.LogSendOperationTo(m.auditPath, entry); err != nil {
		slog.Warn("audit log failed", "error", err, "operation", operation, "recipient", recipient)
	}
}

// isTransientError checks if an error is transient (network/connection) and worth retrying.
func isTransientError(err error) bool {
	if err == nil {
		return false
	}
	msg := err.Error()
	return strings.Contains(msg, "connecting to daemon") ||
		strings.Contains(msg, "sending request") ||
		strings.Contains(msg, "reading response") ||
		strings.Contains(msg, "connection refused") ||
		strings.Contains(msg, "broken pipe")
}

// callWithRetry retries transient RPC errors with exponential backoff (max 3 attempts).
func (m *DaemonMessenger) callWithRetry(ctx context.Context, method string, params interface{}) (*daemon.RPCResponse, error) {
	var lastErr error
	for attempt := 0; attempt < 3; attempt++ {
		resp, err := m.client.Call(method, params)
		if err == nil {
			return resp, nil
		}
		if !isTransientError(err) {
			return nil, err
		}
		lastErr = err
		delay := time.Duration(1<<uint(attempt)) * time.Second // 1s, 2s, 4s
		slog.Warn("transient RPC error, retrying", "method", method, "attempt", attempt+1, "delay", delay, "error", err)
		select {
		case <-time.After(delay):
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	}
	return nil, lastErr
}

// doSend is the common send logic shared by SendText, SendImage, and SendFile.
// It calls the daemon RPC method with retry, logs audit entries, parses the result,
// and wraps transport errors into CLIError.
func (m *DaemonMessenger) doSend(ctx context.Context, operation, rpcMethod, to string, params map[string]string) (*SendResult, error) {
	resp, err := m.callWithRetry(ctx, rpcMethod, params)
	if err != nil {
		m.logAudit(operation, to, "error", err)
		return nil, &clierr.CLIError{
			Type:     "whatsapp_error",
			Code:     5,
			Message:  fmt.Sprintf("Daemon send failed: %s", err),
			Recovery: "Check daemon status with 'gowa daemon status'",
			Original: err,
		}
	}
	result, parseErr := parseDaemonResult(resp)
	if parseErr != nil {
		m.logAudit(operation, to, "error", parseErr)
		return nil, parseErr
	}
	m.logAudit(operation, to, "success", nil)
	return result, nil
}

func (m *DaemonMessenger) SendText(ctx context.Context, to, message, replyTo string) (*SendResult, error) {
	return m.doSend(ctx, "send_text", "send.text", to, map[string]string{
		"to":       to,
		"message":  message,
		"reply_to": replyTo,
	})
}

func (m *DaemonMessenger) SendImage(ctx context.Context, to, filePath, caption string) (*SendResult, error) {
	return m.doSend(ctx, "send_image", "send.image", to, map[string]string{
		"to":      to,
		"file":    filePath,
		"caption": caption,
	})
}

func (m *DaemonMessenger) SendFile(ctx context.Context, to, filePath string) (*SendResult, error) {
	return m.doSend(ctx, "send_file", "send.file", to, map[string]string{
		"to":   to,
		"file": filePath,
	})
}

func (m *DaemonMessenger) Close() error { return nil }

func parseDaemonResult(resp *daemon.RPCResponse) (*SendResult, error) {
	if resp.Error != nil {
		return nil, &clierr.CLIError{
			Type:     "whatsapp_error",
			Code:     5,
			Message:  resp.Error.Message,
			Recovery: "Check daemon logs with 'gowa daemon logs'",
		}
	}

	data, err := json.Marshal(resp.Result)
	if err != nil {
		return nil, fmt.Errorf("parsing daemon response: %w", err)
	}

	var result SendResult
	if err := json.Unmarshal(data, &result); err != nil {
		return nil, fmt.Errorf("parsing send result: %w", err)
	}
	return &result, nil
}
