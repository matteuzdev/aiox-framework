package daemon

import (
	"os"
	"path/filepath"
	"testing"
)

func TestAcquireLock(t *testing.T) {
	dir := t.TempDir()
	lockPath := filepath.Join(dir, "test.lock")

	lock, err := AcquireLock(lockPath)
	if err != nil {
		t.Fatalf("AcquireLock: %v", err)
	}
	defer lock.Unlock()

	// Second acquire should fail
	_, err = AcquireLock(lockPath)
	if err == nil {
		t.Error("expected error on second acquire")
	}
}

func TestWriteAndReadPID(t *testing.T) {
	dir := t.TempDir()
	pidPath := filepath.Join(dir, "test.pid")

	if err := WritePID(pidPath); err != nil {
		t.Fatalf("WritePID: %v", err)
	}

	pid, err := ReadPID(pidPath)
	if err != nil {
		t.Fatalf("ReadPID: %v", err)
	}

	if pid != os.Getpid() {
		t.Errorf("PID = %d, want %d", pid, os.Getpid())
	}
}

func TestIsRunning_CurrentProcess(t *testing.T) {
	dir := t.TempDir()
	pidPath := filepath.Join(dir, "test.pid")

	WritePID(pidPath)

	running, pid := IsRunning(pidPath)
	if !running {
		t.Error("current process should be running")
	}
	if pid != os.Getpid() {
		t.Errorf("PID = %d, want %d", pid, os.Getpid())
	}
}

func TestIsRunning_NoPIDFile(t *testing.T) {
	running, _ := IsRunning("/nonexistent/pid")
	if running {
		t.Error("should not be running without PID file")
	}
}

func TestIsRunning_StalePID(t *testing.T) {
	dir := t.TempDir()
	pidPath := filepath.Join(dir, "test.pid")

	// Write a PID that definitely doesn't exist
	os.WriteFile(pidPath, []byte("999999999"), 0600)

	running, _ := IsRunning(pidPath)
	if running {
		t.Error("stale PID should not be running")
	}
}

func TestNewPaths(t *testing.T) {
	paths, err := NewPaths()
	if err != nil {
		t.Fatalf("NewPaths: %v", err)
	}

	if paths.ConfigDir == "" {
		t.Error("ConfigDir should not be empty")
	}
	if paths.Socket == "" {
		t.Error("Socket path should not be empty")
	}
	if paths.PID == "" {
		t.Error("PID path should not be empty")
	}
}
