package daemon

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"

	"github.com/gofrs/flock"
)

// Paths returns the standard daemon file paths under the config directory.
type Paths struct {
	ConfigDir string
	Socket    string
	PID       string
	Lock      string
	Log       string
	Token     string
	SessionDB string
	MsgDB     string
}

// NewPaths returns standard daemon paths under ~/.config/gowa/.
func NewPaths() (*Paths, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return nil, fmt.Errorf("getting home directory: %w", err)
	}

	dir := filepath.Join(home, ".config", "gowa")
	return &Paths{
		ConfigDir: dir,
		Socket:    filepath.Join(dir, "gowa.sock"),
		PID:       filepath.Join(dir, "daemon.pid"),
		Lock:      filepath.Join(dir, "daemon.lock"),
		Log:       filepath.Join(dir, "daemon.log"),
		Token:     filepath.Join(dir, "daemon.token"),
		SessionDB: filepath.Join(dir, "session.db"),
		MsgDB:     filepath.Join(dir, "messages.db"),
	}, nil
}

// AcquireLock attempts to acquire the daemon file lock.
// Returns the flock instance (caller must hold it) or error if already locked.
func AcquireLock(lockPath string) (*flock.Flock, error) {
	fl := flock.New(lockPath)
	locked, err := fl.TryLock()
	if err != nil {
		return nil, fmt.Errorf("acquiring lock: %w", err)
	}
	if !locked {
		return nil, fmt.Errorf("daemon is already running (lock held)")
	}
	return fl, nil
}

// WritePID writes the current process PID to the PID file.
func WritePID(pidPath string) error {
	return os.WriteFile(pidPath, []byte(strconv.Itoa(os.Getpid())), 0600)
}

// ReadPID reads the PID from the PID file.
func ReadPID(pidPath string) (int, error) {
	data, err := os.ReadFile(pidPath)
	if err != nil {
		return 0, err
	}
	pid, err := strconv.Atoi(strings.TrimSpace(string(data)))
	if err != nil {
		return 0, fmt.Errorf("invalid PID file: %w", err)
	}
	return pid, nil
}

// IsProcessRunning checks if a process with the given PID exists.
func IsProcessRunning(pid int) bool {
	process, err := os.FindProcess(pid)
	if err != nil {
		return false
	}
	// On Unix, FindProcess always succeeds. Send signal 0 to check existence.
	return process.Signal(syscall.Signal(0)) == nil
}

// IsRunning checks if the daemon is running by checking PID file and process.
func IsRunning(pidPath string) (bool, int) {
	pid, err := ReadPID(pidPath)
	if err != nil {
		return false, 0
	}
	return IsProcessRunning(pid), pid
}

// CleanStale removes stale PID and socket files if the daemon is not running.
func CleanStale(paths *Paths) {
	running, _ := IsRunning(paths.PID)
	if running {
		return
	}
	os.Remove(paths.PID)
	os.Remove(paths.Socket)
	os.Remove(paths.Token)
	os.Remove(paths.Lock)
}
