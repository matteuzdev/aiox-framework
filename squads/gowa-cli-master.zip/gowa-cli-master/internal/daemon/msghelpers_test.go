package daemon

import (
	"testing"

	"go.mau.fi/whatsmeow/proto/waE2E"
	"google.golang.org/protobuf/proto"
)

func TestDetectMsgType(t *testing.T) {
	tests := []struct {
		name string
		msg  *waE2E.Message
		want string
	}{
		{"nil message", nil, "unknown"},
		{"conversation text", &waE2E.Message{Conversation: proto.String("hello")}, "text"},
		{"extended text", &waE2E.Message{ExtendedTextMessage: &waE2E.ExtendedTextMessage{Text: proto.String("hi")}}, "text"},
		{"image", &waE2E.Message{ImageMessage: &waE2E.ImageMessage{Caption: proto.String("pic")}}, "image"},
		{"video", &waE2E.Message{VideoMessage: &waE2E.VideoMessage{Caption: proto.String("vid")}}, "video"},
		{"audio", &waE2E.Message{AudioMessage: &waE2E.AudioMessage{}}, "audio"},
		{"document", &waE2E.Message{DocumentMessage: &waE2E.DocumentMessage{Title: proto.String("doc.pdf")}}, "document"},
		{"sticker", &waE2E.Message{StickerMessage: &waE2E.StickerMessage{}}, "sticker"},
		{"contact", &waE2E.Message{ContactMessage: &waE2E.ContactMessage{}}, "contact"},
		{"location", &waE2E.Message{LocationMessage: &waE2E.LocationMessage{}}, "location"},
		{"empty message", &waE2E.Message{}, "unknown"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := detectMsgType(tt.msg)
			if got != tt.want {
				t.Errorf("detectMsgType() = %q, want %q", got, tt.want)
			}
		})
	}
}

func TestExtractMsgText(t *testing.T) {
	tests := []struct {
		name string
		msg  *waE2E.Message
		want string
	}{
		{"nil message", nil, ""},
		{"conversation", &waE2E.Message{Conversation: proto.String("hello world")}, "hello world"},
		{"extended text", &waE2E.Message{ExtendedTextMessage: &waE2E.ExtendedTextMessage{Text: proto.String("link text")}}, "link text"},
		{"image caption", &waE2E.Message{ImageMessage: &waE2E.ImageMessage{Caption: proto.String("my photo")}}, "my photo"},
		{"video caption", &waE2E.Message{VideoMessage: &waE2E.VideoMessage{Caption: proto.String("my video")}}, "my video"},
		{"document title", &waE2E.Message{DocumentMessage: &waE2E.DocumentMessage{Title: proto.String("report.pdf")}}, "report.pdf"},
		{"document filename fallback", &waE2E.Message{DocumentMessage: &waE2E.DocumentMessage{FileName: proto.String("file.xlsx")}}, "file.xlsx"},
		{"empty message", &waE2E.Message{}, ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := extractMsgText(tt.msg)
			if got != tt.want {
				t.Errorf("extractMsgText() = %q, want %q", got, tt.want)
			}
		})
	}
}

func TestExtractReplyTo(t *testing.T) {
	tests := []struct {
		name string
		msg  *waE2E.Message
		want string
	}{
		{"nil message", nil, ""},
		{"no context info", &waE2E.Message{Conversation: proto.String("hello")}, ""},
		{"extended text reply", &waE2E.Message{
			ExtendedTextMessage: &waE2E.ExtendedTextMessage{
				Text: proto.String("reply"),
				ContextInfo: &waE2E.ContextInfo{
					StanzaID: proto.String("ABC123"),
				},
			},
		}, "ABC123"},
		{"image reply", &waE2E.Message{
			ImageMessage: &waE2E.ImageMessage{
				Caption: proto.String("pic"),
				ContextInfo: &waE2E.ContextInfo{
					StanzaID: proto.String("DEF456"),
				},
			},
		}, "DEF456"},
		{"video reply", &waE2E.Message{
			VideoMessage: &waE2E.VideoMessage{
				ContextInfo: &waE2E.ContextInfo{
					StanzaID: proto.String("GHI789"),
				},
			},
		}, "GHI789"},
		{"document reply", &waE2E.Message{
			DocumentMessage: &waE2E.DocumentMessage{
				ContextInfo: &waE2E.ContextInfo{
					StanzaID: proto.String("JKL012"),
				},
			},
		}, "JKL012"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := extractReplyTo(tt.msg)
			if got != tt.want {
				t.Errorf("extractReplyTo() = %q, want %q", got, tt.want)
			}
		})
	}
}
