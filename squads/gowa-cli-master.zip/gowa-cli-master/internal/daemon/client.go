package daemon

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"time"
)

// Client connects to the daemon Unix socket for RPC calls.
type Client struct {
	sockPath string
	token    string
	Timeout  time.Duration
}

// NewClient creates a daemon RPC client.
func NewClient(sockPath, tokenPath string) (*Client, error) {
	tokenData, err := os.ReadFile(tokenPath)
	if err != nil {
		return nil, fmt.Errorf("reading daemon token: %w", err)
	}

	return &Client{
		sockPath: sockPath,
		token:    string(tokenData),
		Timeout:  30 * time.Second,
	}, nil
}

// Call sends an RPC request to the daemon and returns the response.
func (c *Client) Call(method string, params interface{}) (*RPCResponse, error) {
	conn, err := net.DialTimeout("unix", c.sockPath, 5*time.Second)
	if err != nil {
		return nil, fmt.Errorf("connecting to daemon: %w", err)
	}
	defer conn.Close()

	// Set deadline
	conn.SetDeadline(time.Now().Add(c.Timeout))

	// Build request
	paramsJSON, err := json.Marshal(params)
	if err != nil {
		return nil, fmt.Errorf("marshaling params: %w", err)
	}

	req := RPCRequest{
		JSONRPC: "2.0",
		Method:  method,
		Params:  paramsJSON,
		ID:      1,
		Token:   c.token,
	}

	reqData, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("marshaling request: %w", err)
	}
	reqData = append(reqData, '\n')

	if _, err := conn.Write(reqData); err != nil {
		return nil, fmt.Errorf("sending request: %w", err)
	}

	// Read response
	scanner := bufio.NewScanner(conn)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024)
	if !scanner.Scan() {
		if err := scanner.Err(); err != nil {
			return nil, fmt.Errorf("reading response: %w", err)
		}
		return nil, fmt.Errorf("daemon closed connection without response")
	}

	var resp RPCResponse
	if err := json.Unmarshal(scanner.Bytes(), &resp); err != nil {
		return nil, fmt.Errorf("parsing response: %w", err)
	}

	return &resp, nil
}

// Ping sends a health check to the daemon.
func (c *Client) Ping() error {
	resp, err := c.Call("daemon.ping", nil)
	if err != nil {
		return err
	}
	if resp.Error != nil {
		return fmt.Errorf("daemon error: %s", resp.Error.Message)
	}
	return nil
}
