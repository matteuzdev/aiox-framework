package daemon

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestServerClientRoundtrip(t *testing.T) {
	dir := t.TempDir()
	sockPath := filepath.Join(dir, "test.sock")
	tokenPath := filepath.Join(dir, "test.token")

	server, err := NewServer(sockPath, tokenPath, 5*time.Minute)
	if err != nil {
		t.Fatalf("NewServer: %v", err)
	}
	defer server.Shutdown()

	// Register test handler
	server.Register("test.echo", func(params json.RawMessage) (interface{}, error) {
		var p map[string]string
		json.Unmarshal(params, &p)
		return map[string]string{"echo": p["msg"]}, nil
	})

	// Start server in goroutine
	go server.Serve()
	time.Sleep(50 * time.Millisecond) // let server start

	// Create client
	client, err := NewClient(sockPath, tokenPath)
	if err != nil {
		t.Fatalf("NewClient: %v", err)
	}

	// Test echo
	resp, err := client.Call("test.echo", map[string]string{"msg": "hello"})
	if err != nil {
		t.Fatalf("Call: %v", err)
	}
	if resp.Error != nil {
		t.Fatalf("RPC error: %s", resp.Error.Message)
	}

	result, ok := resp.Result.(map[string]interface{})
	if !ok {
		t.Fatalf("expected map result, got %T", resp.Result)
	}
	if result["echo"] != "hello" {
		t.Errorf("echo = %q, want %q", result["echo"], "hello")
	}
}

func TestServerTokenAuth(t *testing.T) {
	dir := t.TempDir()
	sockPath := filepath.Join(dir, "test.sock")
	tokenPath := filepath.Join(dir, "test.token")

	server, err := NewServer(sockPath, tokenPath, 5*time.Minute)
	if err != nil {
		t.Fatalf("NewServer: %v", err)
	}
	defer server.Shutdown()

	server.Register("test.ping", func(params json.RawMessage) (interface{}, error) {
		return "pong", nil
	})

	go server.Serve()
	time.Sleep(50 * time.Millisecond)

	// Create client with wrong token
	wrongTokenPath := filepath.Join(dir, "wrong.token")
	os.WriteFile(wrongTokenPath, []byte("wrong-token"), 0600)

	badClient, err := NewClient(sockPath, wrongTokenPath)
	if err != nil {
		t.Fatalf("NewClient: %v", err)
	}

	resp, err := badClient.Call("test.ping", nil)
	if err != nil {
		t.Fatalf("Call: %v", err)
	}
	if resp.Error == nil {
		t.Error("expected auth error, got nil")
	}
	if resp.Error != nil && resp.Error.Code != -32001 {
		t.Errorf("error code = %d, want -32001", resp.Error.Code)
	}
}

func TestServerMethodNotFound(t *testing.T) {
	dir := t.TempDir()
	sockPath := filepath.Join(dir, "test.sock")
	tokenPath := filepath.Join(dir, "test.token")

	server, err := NewServer(sockPath, tokenPath, 5*time.Minute)
	if err != nil {
		t.Fatalf("NewServer: %v", err)
	}
	defer server.Shutdown()

	go server.Serve()
	time.Sleep(50 * time.Millisecond)

	client, err := NewClient(sockPath, tokenPath)
	if err != nil {
		t.Fatalf("NewClient: %v", err)
	}

	resp, err := client.Call("nonexistent.method", nil)
	if err != nil {
		t.Fatalf("Call: %v", err)
	}
	if resp.Error == nil {
		t.Error("expected method not found error")
	}
	if resp.Error != nil && resp.Error.Code != -32601 {
		t.Errorf("error code = %d, want -32601", resp.Error.Code)
	}
}

func TestServerPing(t *testing.T) {
	dir := t.TempDir()
	sockPath := filepath.Join(dir, "test.sock")
	tokenPath := filepath.Join(dir, "test.token")

	server, err := NewServer(sockPath, tokenPath, 5*time.Minute)
	if err != nil {
		t.Fatalf("NewServer: %v", err)
	}
	defer server.Shutdown()

	server.Register("daemon.ping", func(params json.RawMessage) (interface{}, error) {
		return map[string]string{"status": "ok"}, nil
	})

	go server.Serve()
	time.Sleep(50 * time.Millisecond)

	client, err := NewClient(sockPath, tokenPath)
	if err != nil {
		t.Fatalf("NewClient: %v", err)
	}

	if err := client.Ping(); err != nil {
		t.Errorf("Ping: %v", err)
	}
}

func TestSocketPermissions(t *testing.T) {
	dir := t.TempDir()
	sockPath := filepath.Join(dir, "test.sock")
	tokenPath := filepath.Join(dir, "test.token")

	server, err := NewServer(sockPath, tokenPath, 5*time.Minute)
	if err != nil {
		t.Fatalf("NewServer: %v", err)
	}
	defer server.Shutdown()

	// Check socket permissions
	info, err := os.Stat(sockPath)
	if err != nil {
		t.Fatalf("stat socket: %v", err)
	}
	perm := info.Mode().Perm()
	if perm != 0600 {
		t.Errorf("socket permissions = %o, want 0600", perm)
	}

	// Check token permissions
	info, err = os.Stat(tokenPath)
	if err != nil {
		t.Fatalf("stat token: %v", err)
	}
	perm = info.Mode().Perm()
	if perm != 0600 {
		t.Errorf("token permissions = %o, want 0600", perm)
	}
}

func TestLastActive(t *testing.T) {
	dir := t.TempDir()
	sockPath := filepath.Join(dir, "test.sock")
	tokenPath := filepath.Join(dir, "test.token")

	server, err := NewServer(sockPath, tokenPath, 5*time.Minute)
	if err != nil {
		t.Fatalf("NewServer: %v", err)
	}
	defer server.Shutdown()

	before := server.LastActive()
	time.Sleep(10 * time.Millisecond)

	// LastActive should be set on creation
	if before.IsZero() {
		t.Error("LastActive should not be zero")
	}
}
