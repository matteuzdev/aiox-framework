package daemon

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log/slog"
	"net"
	"os"
	"runtime/debug"
	"sync"
	"sync/atomic"
	"time"
)

// RPCRequest represents a JSON-RPC 2.0 request.
type RPCRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params"`
	ID      int             `json:"id"`
	Token   string          `json:"_token"`
}

// RPCResponse represents a JSON-RPC 2.0 response.
type RPCResponse struct {
	JSONRPC string      `json:"jsonrpc"`
	Result  interface{} `json:"result,omitempty"`
	Error   *RPCError   `json:"error,omitempty"`
	ID      int         `json:"id"`
}

// RPCError represents a JSON-RPC 2.0 error.
type RPCError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

// Handler is a function that handles an RPC method.
type Handler func(params json.RawMessage) (interface{}, error)

// Server is a Unix socket JSON-RPC server.
type Server struct {
	sockPath     string
	token        string
	listener     net.Listener
	handlers     map[string]Handler
	mu           sync.RWMutex
	wg           sync.WaitGroup // tracks in-flight RPC handlers
	lastActive   atomic.Value   // time.Time
	idleTimeout  time.Duration
	ctx          context.Context
	cancel       context.CancelFunc
	shutdownOnce sync.Once
}

// NewServer creates a new daemon RPC server.
func NewServer(sockPath, tokenPath string, idleTimeout time.Duration) (*Server, error) {
	// Generate random token
	tokenBytes := make([]byte, 32)
	if _, err := rand.Read(tokenBytes); err != nil {
		return nil, fmt.Errorf("generating token: %w", err)
	}
	token := hex.EncodeToString(tokenBytes)

	// Write token file (0600)
	if err := os.WriteFile(tokenPath, []byte(token), 0600); err != nil {
		return nil, fmt.Errorf("writing token: %w", err)
	}

	// Remove stale socket
	os.Remove(sockPath)

	listener, err := net.Listen("unix", sockPath)
	if err != nil {
		return nil, fmt.Errorf("listening on socket: %w", err)
	}

	// Set socket permissions
	if err := os.Chmod(sockPath, 0600); err != nil {
		listener.Close()
		return nil, fmt.Errorf("setting socket permissions: %w", err)
	}

	ctx, cancel := context.WithCancel(context.Background())

	s := &Server{
		sockPath:    sockPath,
		token:       token,
		listener:    listener,
		handlers:    make(map[string]Handler),
		idleTimeout: idleTimeout,
		ctx:         ctx,
		cancel:      cancel,
	}
	s.lastActive.Store(time.Now())

	return s, nil
}

// Register adds an RPC method handler.
func (s *Server) Register(method string, handler Handler) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.handlers[method] = handler
}

// Serve starts accepting connections. Blocks until context is cancelled.
func (s *Server) Serve() error {
	// Start idle timeout checker (with panic recovery)
	if s.idleTimeout > 0 {
		go func() {
			defer recoverPanic("idleChecker")
			s.idleChecker()
		}()
	}

	for {
		conn, err := s.listener.Accept()
		if err != nil {
			select {
			case <-s.ctx.Done():
				return nil // graceful shutdown
			default:
				slog.Error("accept error", "error", err)
				continue
			}
		}
		s.wg.Add(1)
		go func(c net.Conn) {
			defer s.wg.Done()
			defer recoverPanic("handleConn")
			s.handleConn(c)
		}(conn)
	}
}

// Shutdown gracefully stops the server.
// Stops accepting new connections, waits up to 5 seconds for in-flight handlers to complete.
// Safe to call multiple times — subsequent calls are no-ops.
func (s *Server) Shutdown() {
	s.shutdownOnce.Do(func() {
		s.cancel()
		s.listener.Close()

		// Wait for in-flight handlers with timeout
		done := make(chan struct{})
		go func() {
			s.wg.Wait()
			close(done)
		}()
		select {
		case <-done:
			slog.Info("all RPC handlers drained")
		case <-time.After(5 * time.Second):
			slog.Warn("timed out waiting for RPC handlers to drain")
		}

		os.Remove(s.sockPath)
	})
}

// LastActive returns the time of the last RPC activity.
func (s *Server) LastActive() time.Time {
	return s.lastActive.Load().(time.Time)
}

func (s *Server) handleConn(conn net.Conn) {
	defer conn.Close()

	// Set read deadline for request parsing (5 seconds)
	conn.SetReadDeadline(time.Now().Add(5 * time.Second))

	scanner := bufio.NewScanner(conn)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024) // 1MB max
	if !scanner.Scan() {
		return
	}

	var req RPCRequest
	if err := json.Unmarshal(scanner.Bytes(), &req); err != nil {
		writeResponse(conn, RPCResponse{
			JSONRPC: "2.0",
			Error:   &RPCError{Code: -32700, Message: "Parse error"},
			ID:      0,
		})
		return
	}

	// Token authentication
	if subtle.ConstantTimeCompare([]byte(req.Token), []byte(s.token)) != 1 {
		writeResponse(conn, RPCResponse{
			JSONRPC: "2.0",
			Error:   &RPCError{Code: -32001, Message: "Invalid token"},
			ID:      req.ID,
		})
		return
	}

	// Reset idle timer
	s.lastActive.Store(time.Now())

	// Set full deadline for handler execution + response write (90 seconds)
	conn.SetDeadline(time.Now().Add(90 * time.Second))

	// Find handler
	s.mu.RLock()
	handler, ok := s.handlers[req.Method]
	s.mu.RUnlock()

	if !ok {
		writeResponse(conn, RPCResponse{
			JSONRPC: "2.0",
			Error:   &RPCError{Code: -32601, Message: fmt.Sprintf("Method not found: %s", req.Method)},
			ID:      req.ID,
		})
		return
	}

	// Execute handler
	result, err := handler(req.Params)
	if err != nil {
		writeResponse(conn, RPCResponse{
			JSONRPC: "2.0",
			Error:   &RPCError{Code: -32000, Message: err.Error()},
			ID:      req.ID,
		})
		return
	}

	writeResponse(conn, RPCResponse{
		JSONRPC: "2.0",
		Result:  result,
		ID:      req.ID,
	})
}

func (s *Server) idleChecker() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			idle := time.Since(s.LastActive())
			if idle > s.idleTimeout {
				slog.Info("idle timeout reached, shutting down", "idle", idle.String())
				s.Shutdown()
				return
			}
		case <-s.ctx.Done():
			return
		}
	}
}

// recoverPanic logs panics with stack trace and allows the daemon to continue.
func recoverPanic(label string) {
	if r := recover(); r != nil {
		slog.Error("panic recovered in goroutine",
			"label", label,
			"panic", r,
			"stack", string(debug.Stack()),
		)
	}
}

func writeResponse(conn net.Conn, resp RPCResponse) {
	data, err := json.Marshal(resp)
	if err != nil {
		slog.Error("failed to marshal RPC response", "error", err)
		// Send a minimal error response as fallback
		data = []byte(`{"jsonrpc":"2.0","error":{"code":-32603,"message":"internal marshal error"},"id":0}`)
	}
	data = append(data, '\n')
	if _, err := conn.Write(data); err != nil {
		slog.Error("failed to write RPC response", "error", err)
	}
}
