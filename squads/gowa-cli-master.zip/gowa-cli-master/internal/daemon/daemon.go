package daemon

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strings"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/gofrs/flock"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	"gopkg.in/natefinch/lumberjack.v2"

	"github.com/murilloimparavel/gowa-cli/internal/msgstore"
	"github.com/murilloimparavel/gowa-cli/internal/safety"
	"github.com/murilloimparavel/gowa-cli/internal/whatsapp"
)

// Connection status constants.
const (
	ConnStatusConnected    = "connected"
	ConnStatusReconnecting = "reconnecting"
	ConnStatusBanned       = "banned"
	ConnStatusLoggedOut    = "logged_out"
	ConnStatusKAFailing    = "keepalive_failing"
)

// Daemon manages the WhatsApp connection daemon.
type Daemon struct {
	paths      *Paths
	lock       *flock.Flock
	server     *Server
	wa         *whatsapp.WaClient
	store      *msgstore.MsgStore
	cb         *safety.CircuitBreaker
	started    time.Time
	connStatus atomic.Value // stores string: connected, reconnecting, banned, logged_out, keepalive_failing
	cancelFunc context.CancelFunc
}

// Start spawns the daemon as a background process.
func Start(paths *Paths, idleTimeout time.Duration) (int, error) {
	// Clean stale files
	CleanStale(paths)

	// Check if already running
	if running, pid := IsRunning(paths.PID); running {
		return pid, fmt.Errorf("daemon already running (PID: %d)", pid)
	}

	// Check session exists
	if _, err := os.Stat(paths.SessionDB); os.IsNotExist(err) {
		return 0, fmt.Errorf("no WhatsApp session found. Run 'gowa pair' first")
	}

	// Ensure log directory exists
	if err := os.MkdirAll(filepath.Dir(paths.Log), 0700); err != nil {
		return 0, fmt.Errorf("creating log directory: %w", err)
	}

	// Open log file for spawned process stdout/stderr
	logFile, err := os.OpenFile(paths.Log, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return 0, fmt.Errorf("opening log file: %w", err)
	}

	// Spawn daemon process (log rotation handled inside RunForeground via lumberjack)
	exe, err := os.Executable()
	if err != nil {
		logFile.Close()
		return 0, fmt.Errorf("getting executable path: %w", err)
	}

	cmd := exec.Command(exe, "daemon", "start", "--foreground", "--idle-timeout", idleTimeout.String())
	cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
	cmd.Stdout = logFile
	cmd.Stderr = logFile

	if err := cmd.Start(); err != nil {
		logFile.Close()
		return 0, fmt.Errorf("starting daemon: %w", err)
	}

	pid := cmd.Process.Pid
	logFile.Close()

	// Release the process so it runs independently
	cmd.Process.Release()

	// Wait for socket to appear (up to 5 seconds)
	for i := 0; i < 50; i++ {
		time.Sleep(100 * time.Millisecond)
		if _, err := os.Stat(paths.Socket); err == nil {
			return pid, nil
		}
	}

	return pid, fmt.Errorf("daemon started (PID: %d) but socket not ready after 5s — check 'gowa daemon logs'", pid)
}

// Stop sends SIGTERM to the daemon and waits for it to exit.
func Stop(paths *Paths) error {
	running, pid := IsRunning(paths.PID)
	if !running {
		CleanStale(paths)
		return fmt.Errorf("daemon is not running")
	}

	process, err := os.FindProcess(pid)
	if err != nil {
		return fmt.Errorf("finding process %d: %w", pid, err)
	}

	// Send SIGTERM
	if err := process.Signal(syscall.SIGTERM); err != nil {
		return fmt.Errorf("sending SIGTERM: %w", err)
	}

	// Wait up to 5 seconds
	for i := 0; i < 50; i++ {
		time.Sleep(100 * time.Millisecond)
		if !IsProcessRunning(pid) {
			CleanStale(paths)
			return nil
		}
	}

	// Force kill
	process.Signal(syscall.SIGKILL)
	time.Sleep(500 * time.Millisecond)
	CleanStale(paths)
	return nil
}

// RunForeground runs the daemon in the foreground (called by --foreground flag).
func RunForeground(paths *Paths, idleTimeout time.Duration) error {
	// Acquire lock
	lock, err := AcquireLock(paths.Lock)
	if err != nil {
		return err
	}
	defer lock.Unlock()

	// Write PID
	if err := WritePID(paths.PID); err != nil {
		return fmt.Errorf("writing PID: %w", err)
	}
	defer os.Remove(paths.PID)

	// Set up log rotation (5MB max, 3 backups)
	logWriter := &lumberjack.Logger{
		Filename:   paths.Log,
		MaxSize:    5, // MB
		MaxBackups: 3,
	}
	defer logWriter.Close()

	// Configure slog to write to rotating log file
	logHandler := slog.NewJSONHandler(logWriter, &slog.HandlerOptions{Level: slog.LevelInfo})
	slog.SetDefault(slog.New(logHandler))

	slog.Info("daemon starting", "pid", os.Getpid())

	// Initialize WhatsApp client
	wa, err := whatsapp.NewWaClient(context.Background(), paths.SessionDB, waLog.Stdout("GOWA", "INFO", false))
	if err != nil {
		return fmt.Errorf("creating WhatsApp client: %w", err)
	}

	if wa.NeedsPairing() {
		wa.Close()
		return fmt.Errorf("no WhatsApp session. Run 'gowa pair' first")
	}

	// Initialize message store
	store, err := msgstore.NewMsgStore(paths.MsgDB)
	if err != nil {
		wa.Close()
		return fmt.Errorf("opening message store: %w", err)
	}

	// Create RPC server
	server, err := NewServer(paths.Socket, paths.Token, idleTimeout)
	if err != nil {
		store.Close()
		wa.Close()
		return fmt.Errorf("creating server: %w", err)
	}

	ctx, cancel := context.WithCancel(context.Background())

	// Circuit breaker: 5 failures in 30min window → 30min cooldown
	cb := safety.NewCircuitBreaker(5, 30*time.Minute, 30*time.Minute)

	d := &Daemon{
		paths:      paths,
		lock:       lock,
		server:     server,
		wa:         wa,
		store:      store,
		cb:         cb,
		started:    time.Now(),
		cancelFunc: cancel,
	}
	d.connStatus.Store(ConnStatusReconnecting)

	// Best practice: integrate CircuitBreaker with whatsmeow's AutoReconnectHook.
	// When the CB is open (too many consecutive failures), the hook returns false
	// and whatsmeow skips the reconnection attempt. This prevents aggressive
	// reconnection loops that WhatsApp could interpret as abusive behavior.
	wa.UnderlyingClient().AutoReconnectHook = func(err error) bool {
		return cb.Allow() == nil
	}

	// Register RPC handlers
	d.registerHandlers()

	// Register WhatsApp event handlers
	d.registerEventHandlers()

	// Connect to WhatsApp
	defer cancel()

	if err := wa.Connect(ctx); err != nil {
		server.Shutdown()
		store.Close()
		wa.Close()
		os.Remove(paths.Socket)
		os.Remove(paths.Token)
		return err
	}

	d.connStatus.Store(ConnStatusConnected)
	slog.Info("daemon started, WhatsApp connected")

	// Handle signals
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGTERM, syscall.SIGINT)

	// Run server in goroutine (safeGo for panic protection)
	serverDone := make(chan error, 1)
	whatsapp.SafeGo(func() {
		serverDone <- server.Serve()
	})

	// Wait for signal, server shutdown, or permanent disconnect
	select {
	case sig := <-sigChan:
		slog.Info("received signal, shutting down", "signal", sig)
	case err := <-serverDone:
		if err != nil {
			slog.Error("server error", "error", err)
		} else {
			slog.Info("server stopped (idle timeout)")
		}
	case <-ctx.Done():
		connStatus := d.connStatus.Load().(string)
		slog.Info("permanent disconnect, shutting down", "status", connStatus)
	}

	// Graceful shutdown with 10s hard deadline.
	// Design decision: 10 seconds is enough for WhatsApp disconnect + SQLite WAL
	// flush + socket cleanup. If anything hangs beyond that, force-exit to avoid
	// leaving an orphaned daemon that blocks future starts.
	shutdownDone := make(chan struct{})
	time.AfterFunc(10*time.Second, func() {
		select {
		case <-shutdownDone:
			return // already done
		default:
			slog.Error("graceful shutdown timeout exceeded, forcing exit")
			os.Remove(paths.PID)
			os.Remove(paths.Socket)
			os.Remove(paths.Token)
			os.Exit(1)
		}
	})

	slog.Info("starting graceful shutdown")

	// 1. Stop accepting new RPC requests
	server.Shutdown()

	// 2. Disconnect WhatsApp and flush session DB (container.Close flushes SQLite WAL)
	if err := wa.Close(); err != nil {
		slog.Error("error closing WhatsApp client", "error", err)
	}

	// 3. Close message store
	if err := store.Close(); err != nil {
		slog.Error("error closing message store", "error", err)
	}

	// 4. Clean up files
	os.Remove(paths.Socket)
	os.Remove(paths.Token)

	close(shutdownDone)
	slog.Info("daemon stopped cleanly")

	return nil
}

func (d *Daemon) registerEventHandlers() {
	// Save incoming messages to store
	d.wa.OnMessage(func(evt *events.Message) {
		slog.Debug("message received",
			"chat", evt.Info.Chat.String(),
			"sender", evt.Info.Sender.String(),
			"id", evt.Info.ID,
		)

		chatJID := evt.Info.Chat.String()
		senderJID := evt.Info.Sender.String()
		msgType := detectMsgType(evt.Message)
		text := extractMsgText(evt.Message)
		replyTo := extractReplyTo(evt.Message)

		// Save message
		msg := &msgstore.Message{
			ID:        string(evt.Info.ID),
			ChatJID:   chatJID,
			SenderJID: senderJID,
			Timestamp: evt.Info.Timestamp.Unix(),
			Type:      msgType,
			Text:      text,
			MediaType: evt.Info.MediaType,
			IsFromMe:  evt.Info.IsFromMe,
			ReplyTo:   replyTo,
		}
		if err := d.store.SaveMessage(msg); err != nil {
			slog.Error("failed to save message", "id", evt.Info.ID, "error", err)
		}

		// Upsert chat with last message info
		preview := text
		if len(preview) > 100 {
			preview = preview[:100]
		}
		chat := &msgstore.Chat{
			JID:             chatJID,
			Name:            evt.Info.PushName,
			IsGroup:         evt.Info.IsGroup,
			LastMsgTimestamp: evt.Info.Timestamp.Unix(),
			LastMsgPreview:  preview,
		}
		if err := d.store.UpsertChat(chat); err != nil {
			slog.Error("failed to upsert chat", "jid", chatJID, "error", err)
		}

		// Increment unread for messages NOT from me
		if !evt.Info.IsFromMe {
			if err := d.store.IncrementUnread(chatJID); err != nil {
				slog.Error("failed to increment unread", "jid", chatJID, "error", err)
			}
		}

		// Upsert contact with sender push name
		if evt.Info.PushName != "" {
			contact := &msgstore.Contact{
				JID:      senderJID,
				PushName: evt.Info.PushName,
			}
			if err := d.store.UpsertContact(contact); err != nil {
				slog.Error("failed to upsert contact", "jid", senderJID, "error", err)
			}
		}
	})

	// Handle history sync — persist synced messages via same path
	d.wa.OnHistorySync(func(evt *events.HistorySync) {
		data := evt.Data
		conversations := data.GetConversations()
		slog.Info("history sync received",
			"type", data.GetSyncType(),
			"conversations", len(conversations),
		)

		for _, conv := range conversations {
			chatJID := conv.GetID()
			isGroup := strings.HasSuffix(chatJID, "@g.us")
			name := conv.GetName()
			if name == "" {
				name = conv.GetDisplayName()
			}

			// Upsert chat
			chat := &msgstore.Chat{
				JID:             chatJID,
				Name:            name,
				IsGroup:         isGroup,
				LastMsgTimestamp: int64(conv.GetLastMsgTimestamp()),
				UnreadCount:     int(conv.GetUnreadCount()),
				Archived:        conv.GetArchived(),
				Pinned:          conv.GetPinned() > 0,
				MutedUntil:      int64(conv.GetMuteEndTime()),
			}
			if err := d.store.UpsertChat(chat); err != nil {
				slog.Error("failed to upsert chat from history", "jid", chatJID, "error", err)
				continue
			}

			// Save messages from history
			for _, hsMsg := range conv.GetMessages() {
				webMsg := hsMsg.GetMessage()
				if webMsg == nil {
					continue
				}
				key := webMsg.GetKey()
				if key == nil {
					continue
				}
				waMsg := webMsg.GetMessage()

				senderJID := key.GetRemoteJID()
				if isGroup && key.GetParticipant() != "" {
					senderJID = key.GetParticipant()
				}
				if webMsg.GetParticipant() != "" {
					senderJID = webMsg.GetParticipant()
				}

				msg := &msgstore.Message{
					ID:        key.GetID(),
					ChatJID:   chatJID,
					SenderJID: senderJID,
					Timestamp: int64(webMsg.GetMessageTimestamp()),
					IsFromMe:  key.GetFromMe(),
					Type:      detectMsgType(waMsg),
					Text:      extractMsgText(waMsg),
					ReplyTo:   extractReplyTo(waMsg),
				}
				if err := d.store.SaveMessage(msg); err != nil {
					slog.Error("failed to save history message", "id", key.GetID(), "error", err)
				}
			}

			// Update last message preview from newest message
			if msgs := conv.GetMessages(); len(msgs) > 0 {
				// Messages come newest-first typically
				for _, hsMsg := range msgs {
					webMsg := hsMsg.GetMessage()
					if webMsg == nil || webMsg.GetMessage() == nil {
						continue
					}
					text := extractMsgText(webMsg.GetMessage())
					if text != "" {
						if len(text) > 100 {
							text = text[:100]
						}
						chat.LastMsgPreview = text
						_ = d.store.UpsertChat(chat)
						break
					}
				}
			}
		}

		// Save push names from history sync
		for _, pn := range data.GetPushnames() {
			if pn.GetID() != "" && pn.GetPushname() != "" {
				contact := &msgstore.Contact{
					JID:      pn.GetID(),
					PushName: pn.GetPushname(),
				}
				if err := d.store.UpsertContact(contact); err != nil {
					slog.Error("failed to upsert contact from history", "jid", pn.GetID(), "error", err)
				}
			}
		}

		slog.Info("history sync processed", "conversations", len(conversations))
	})

	// Handle disconnect — transient, whatsmeow auto-reconnects
	d.wa.OnDisconnect(func(evt *events.Disconnected) {
		slog.Warn("WhatsApp disconnected, will auto-reconnect")
		d.connStatus.Store(ConnStatusReconnecting)
		d.cb.RecordFailure()
	})

	// Register handlers for additional event types via underlying client
	waCli := d.wa.UnderlyingClient()

	waCli.AddEventHandler(func(evt any) {
		switch e := evt.(type) {
		case *events.Connected:
			slog.Info("WhatsApp connected")
			d.connStatus.Store(ConnStatusConnected)
			d.cb.RecordSuccess()

		case *events.LoggedOut:
			slog.Error("WhatsApp logged out — session expired, need re-pair",
				"on_connect", e.OnConnect,
				"reason", e.Reason,
			)
			d.connStatus.Store(ConnStatusLoggedOut)
			// Trigger graceful shutdown
			if d.cancelFunc != nil {
				d.cancelFunc()
			}

		case *events.StreamReplaced:
			slog.Error("WhatsApp stream replaced — another client connected with same session")
			d.connStatus.Store(ConnStatusLoggedOut)
			if d.cancelFunc != nil {
				d.cancelFunc()
			}

		case *events.TemporaryBan:
			slog.Error("WhatsApp temporary ban",
				"code", e.Code,
				"expire", e.Expire,
			)
			d.connStatus.Store(ConnStatusBanned)

		case *events.ClientOutdated:
			slog.Error("WhatsApp client outdated — update required")
			d.connStatus.Store(ConnStatusLoggedOut)
			if d.cancelFunc != nil {
				d.cancelFunc()
			}

		case *events.ConnectFailure:
			slog.Error("WhatsApp connect failure",
				"reason", e.Reason,
				"message", e.Message,
			)
			// Permanent failures (401 LoggedOut, 406 Unknown Logout)
			switch e.Reason {
			case events.ConnectFailureLoggedOut, events.ConnectFailureUnknownLogout:
				d.connStatus.Store(ConnStatusLoggedOut)
				if d.cancelFunc != nil {
					d.cancelFunc()
				}
			default:
				d.connStatus.Store(ConnStatusReconnecting)
				d.cb.RecordFailure()
			}

		case *events.KeepAliveTimeout:
			slog.Warn("WhatsApp keepalive timeout",
				"error_count", e.ErrorCount,
				"last_success", e.LastSuccess,
			)
			d.connStatus.Store(ConnStatusKAFailing)

		case *events.KeepAliveRestored:
			slog.Info("WhatsApp keepalive restored")
			d.connStatus.Store(ConnStatusConnected)
		}
	})
}

// detectMsgType determines the message type from a waE2E.Message.
func detectMsgType(msg *waE2E.Message) string {
	if msg == nil {
		return "unknown"
	}
	switch {
	case msg.GetConversation() != "" || msg.GetExtendedTextMessage() != nil:
		return "text"
	case msg.GetImageMessage() != nil:
		return "image"
	case msg.GetVideoMessage() != nil:
		return "video"
	case msg.GetAudioMessage() != nil:
		return "audio"
	case msg.GetDocumentMessage() != nil:
		return "document"
	case msg.GetStickerMessage() != nil:
		return "sticker"
	case msg.GetContactMessage() != nil:
		return "contact"
	case msg.GetLocationMessage() != nil:
		return "location"
	default:
		return "unknown"
	}
}

// extractMsgText extracts human-readable text from a waE2E.Message.
func extractMsgText(msg *waE2E.Message) string {
	if msg == nil {
		return ""
	}
	if msg.GetConversation() != "" {
		return msg.GetConversation()
	}
	if ext := msg.GetExtendedTextMessage(); ext != nil {
		return ext.GetText()
	}
	if img := msg.GetImageMessage(); img != nil {
		return img.GetCaption()
	}
	if vid := msg.GetVideoMessage(); vid != nil {
		return vid.GetCaption()
	}
	if doc := msg.GetDocumentMessage(); doc != nil {
		if doc.GetTitle() != "" {
			return doc.GetTitle()
		}
		return doc.GetFileName()
	}
	return ""
}

// extractReplyTo extracts the quoted message stanza ID if the message is a reply.
func extractReplyTo(msg *waE2E.Message) string {
	if msg == nil {
		return ""
	}
	if ext := msg.GetExtendedTextMessage(); ext != nil {
		if ci := ext.GetContextInfo(); ci != nil {
			return ci.GetStanzaID()
		}
	}
	if img := msg.GetImageMessage(); img != nil {
		if ci := img.GetContextInfo(); ci != nil {
			return ci.GetStanzaID()
		}
	}
	if vid := msg.GetVideoMessage(); vid != nil {
		if ci := vid.GetContextInfo(); ci != nil {
			return ci.GetStanzaID()
		}
	}
	if doc := msg.GetDocumentMessage(); doc != nil {
		if ci := doc.GetContextInfo(); ci != nil {
			return ci.GetStanzaID()
		}
	}
	return ""
}

func (d *Daemon) registerHandlers() {
	// Daemon management
	d.server.Register("daemon.ping", func(params json.RawMessage) (interface{}, error) {
		return map[string]string{"status": "ok"}, nil
	})

	d.server.Register("daemon.status", func(params json.RawMessage) (interface{}, error) {
		status := map[string]interface{}{
			"running":                true,
			"pid":                    os.Getpid(),
			"uptime_seconds":         int(time.Since(d.started).Seconds()),
			"whatsapp_connected":     d.wa.IsConnected(),
			"connection_status":      d.connStatus.Load(),
			"last_activity":          d.server.LastActive().Format(time.RFC3339),
			"idle_timeout_remaining": func() interface{} {
				if d.server.idleTimeout == 0 {
					return "disabled"
				}
				return d.server.idleTimeout - time.Since(d.server.LastActive())
			}(),
			"mode":                   "daemon",
		}

		// Include circuit breaker state
		cbState := d.cb.State()
		status["cb_state"] = string(cbState)
		status["cb_failures"] = d.cb.Failures()

		return status, nil
	})

	d.server.Register("daemon.shutdown", func(params json.RawMessage) (interface{}, error) {
		whatsapp.SafeGo(func() {
			time.Sleep(100 * time.Millisecond)
			d.server.Shutdown()
		})
		return map[string]string{"status": "shutting_down"}, nil
	})

	// Chat operations (read from local store)
	d.server.Register("chat.list", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			Limit int `json:"limit"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		return d.store.GetChats(p.Limit)
	})

	d.server.Register("chat.messages", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			JID    string `json:"jid"`
			Limit  int    `json:"limit"`
			Before int64  `json:"before"`
			Since  string `json:"since"`
			Until  string `json:"until"`
			Search string `json:"search"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.JID == "" {
			return nil, fmt.Errorf("jid is required")
		}

		filter := msgstore.MessageFilter{
			Before: p.Before,
			Search: p.Search,
		}

		// Parse RFC3339 since/until to Unix timestamps
		if p.Since != "" {
			t, err := time.Parse(time.RFC3339, p.Since)
			if err != nil {
				return nil, fmt.Errorf("invalid since format (use RFC3339): %w", err)
			}
			filter.After = t.Unix()
		}
		if p.Until != "" {
			t, err := time.Parse(time.RFC3339, p.Until)
			if err != nil {
				return nil, fmt.Errorf("invalid until format (use RFC3339): %w", err)
			}
			filter.Until = t.Unix()
		}

		return d.store.GetMessages(p.JID, p.Limit, filter)
	})

	d.server.Register("chat.unread", func(params json.RawMessage) (interface{}, error) {
		return d.store.GetUnreadChats()
	})

	d.server.Register("chat.read", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			JID string `json:"jid"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.JID == "" {
			return nil, fmt.Errorf("jid is required")
		}
		return map[string]string{"status": "ok"}, d.store.MarkChatRead(p.JID)
	})

	d.server.Register("chat.search", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			Query string `json:"query"`
			Limit int    `json:"limit"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.Query == "" {
			return nil, fmt.Errorf("query is required")
		}
		return d.store.SearchMessages(p.Query, p.Limit)
	})

	// Contact operations
	d.server.Register("contact.list", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			Limit int `json:"limit"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		return d.store.GetContacts(p.Limit)
	})

	d.server.Register("contact.search", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			Query string `json:"query"`
			Limit int    `json:"limit"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.Query == "" {
			return nil, fmt.Errorf("query is required")
		}
		return d.store.SearchContacts(p.Query, p.Limit)
	})

	// Rate limiter state path (shared between CLI and daemon)
	statePath := filepath.Join(d.paths.ConfigDir, "state.json")

	// Send operations (via WhatsApp) — rate limited at daemon level
	d.server.Register("send.text", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			To      string `json:"to"`
			Message string `json:"message"`
			ReplyTo string `json:"reply_to"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.To == "" || p.Message == "" {
			return nil, fmt.Errorf("'to' and 'message' are required")
		}
		if err := safety.ValidatePhone(p.To); err != nil {
			return nil, fmt.Errorf("invalid phone: %w", err)
		}

		// Rate limit check (authoritative — daemon is the gate)
		if err := safety.CheckAndRecordSend(statePath); err != nil {
			return nil, err
		}

		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()

		// Typing indicator before text messages (anti-ban measure)
		if err := d.wa.SendChatPresence(ctx, p.To, true); err == nil {
			select {
			case <-time.After(1500 * time.Millisecond):
			case <-ctx.Done():
				return nil, ctx.Err()
			}
			d.wa.SendChatPresence(ctx, p.To, false)
		}

		return d.wa.SendText(ctx, p.To, p.Message, p.ReplyTo)
	})

	d.server.Register("send.image", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			To      string `json:"to"`
			File    string `json:"file"`
			Caption string `json:"caption"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.To == "" || p.File == "" {
			return nil, fmt.Errorf("'to' and 'file' are required")
		}
		if err := safety.ValidatePhone(p.To); err != nil {
			return nil, fmt.Errorf("invalid phone: %w", err)
		}
		if err := safety.ValidateFilePath(p.File); err != nil {
			return nil, fmt.Errorf("invalid file path: %w", err)
		}

		if err := safety.CheckAndRecordSend(statePath); err != nil {
			return nil, err
		}

		ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
		defer cancel()
		return d.wa.SendImage(ctx, p.To, p.File, p.Caption)
	})

	d.server.Register("send.file", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			To   string `json:"to"`
			File string `json:"file"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.To == "" || p.File == "" {
			return nil, fmt.Errorf("'to' and 'file' are required")
		}
		if err := safety.ValidatePhone(p.To); err != nil {
			return nil, fmt.Errorf("invalid phone: %w", err)
		}
		if err := safety.ValidateFilePath(p.File); err != nil {
			return nil, fmt.Errorf("invalid file path: %w", err)
		}

		if err := safety.CheckAndRecordSend(statePath); err != nil {
			return nil, err
		}

		ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
		defer cancel()
		return d.wa.SendFile(ctx, p.To, p.File)
	})

	// Safety: rate limit status query
	d.server.Register("safety.rate-status", func(params json.RawMessage) (interface{}, error) {
		return safety.GetRateStatus(statePath)
	})

	d.server.Register("device.status", func(params json.RawMessage) (interface{}, error) {
		return map[string]interface{}{
			"connected":     d.wa.IsConnected(),
			"logged_in":     d.wa.IsLoggedIn(),
			"needs_pairing": d.wa.NeedsPairing(),
		}, nil
	})

	// Group operations (via WhatsApp)
	d.server.Register("group.list", func(params json.RawMessage) (interface{}, error) {
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		groups, err := d.wa.GetJoinedGroups(ctx)
		if err != nil {
			return nil, err
		}

		// Enrich with last_activity from msgstore
		chats, _ := d.store.GetChats(0)
		chatMap := make(map[string]int64, len(chats))
		for _, c := range chats {
			if c.IsGroup && c.LastMsgTimestamp > 0 {
				chatMap[c.JID] = c.LastMsgTimestamp
			}
		}
		for i := range groups {
			if ts, ok := chatMap[groups[i].JID]; ok {
				groups[i].LastActivity = time.Unix(ts, 0).UTC().Format(time.RFC3339)
			}
		}

		return groups, nil
	})

	d.server.Register("group.info", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			JID string `json:"jid"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.JID == "" {
			return nil, fmt.Errorf("'jid' is required")
		}
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		return d.wa.GetGroupInfo(ctx, p.JID)
	})

	d.server.Register("group.create", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			Name         string   `json:"name"`
			Participants []string `json:"participants"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.Name == "" {
			return nil, fmt.Errorf("'name' is required")
		}
		if err := safety.CheckAndRecordGroupOp(statePath, "group_create"); err != nil {
			return nil, err
		}

		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		return d.wa.CreateGroup(ctx, p.Name, p.Participants)
	})

	d.server.Register("group.leave", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			JID string `json:"jid"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.JID == "" {
			return nil, fmt.Errorf("'jid' is required")
		}
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		return nil, d.wa.LeaveGroup(ctx, p.JID)
	})

	d.server.Register("group.inviteLink", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			JID   string `json:"jid"`
			Reset bool   `json:"reset"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.JID == "" {
			return nil, fmt.Errorf("'jid' is required")
		}
		timeout := 15 * time.Second
		if p.Reset {
			timeout = 30 * time.Second
		}
		ctx, cancel := context.WithTimeout(context.Background(), timeout)
		defer cancel()
		link, err := d.wa.GetGroupInviteLink(ctx, p.JID, p.Reset)
		if err != nil {
			return nil, err
		}
		return map[string]string{"link": link}, nil
	})

	d.server.Register("group.join", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			Code string `json:"code"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.Code == "" {
			return nil, fmt.Errorf("'code' is required")
		}

		if err := safety.CheckAndRecordGroupOp(statePath, "group_join"); err != nil {
			return nil, err
		}

		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		jid, err := d.wa.JoinGroupWithLink(ctx, p.Code)
		if err != nil {
			return nil, err
		}
		return map[string]string{"jid": jid}, nil
	})

	d.server.Register("group.infoFromLink", func(params json.RawMessage) (interface{}, error) {
		var p struct {
			Code string `json:"code"`
		}
		if err := json.Unmarshal(params, &p); err != nil {
			return nil, fmt.Errorf("invalid params: %w", err)
		}
		if p.Code == "" {
			return nil, fmt.Errorf("'code' is required")
		}
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		return d.wa.GetGroupInfoFromLink(ctx, p.Code)
	})

}
