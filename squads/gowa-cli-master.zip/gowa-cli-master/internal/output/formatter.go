package output

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"strings"
)

// Formatter is the interface that all output formatters must implement.
type Formatter interface {
	// Format renders a slice of data as a table/list using the given columns.
	Format(data interface{}, columns []Column) error
	// FormatSingle renders a single object.
	FormatSingle(data interface{}) error
}

// Column defines a column for tabular output.
type Column struct {
	Name  string // Display header (e.g. "ID", "STATUS")
	Field string // JSON/map key to extract (e.g. "id", "status")
}

// New creates a Formatter for the given format string.
// Supported formats: "json", "quiet", default is "table".
func New(format string, w io.Writer) Formatter {
	switch format {
	case "json":
		return &JSONFormatter{w: w}
	case "quiet":
		return &QuietFormatter{w: w}
	default:
		return &TableFormatter{w: w}
	}
}

// AutoDetect returns the format string based on flag values.
// When no flag is explicitly set and stdout is not a TTY (pipe/redirect),
// defaults to JSON for agent-friendly output.
func AutoDetect(jsonFlag, quietFlag bool) string {
	if jsonFlag {
		return "json"
	}
	if quietFlag {
		return "quiet"
	}
	// If stdout is not a TTY (piped or redirected), default to JSON
	if fi, err := os.Stdout.Stat(); err == nil {
		if (fi.Mode() & os.ModeCharDevice) == 0 {
			return "json"
		}
	}
	return "table"
}

// FilterFields filters data to include only the specified fields.
// Works with map[string]interface{}, []interface{}, slices of maps,
// and arbitrary structs/slices (via JSON round-trip).
// If fields is nil or empty, data is returned unchanged.
func FilterFields(data interface{}, fields []string) interface{} {
	if len(fields) == 0 || data == nil {
		return data
	}

	fieldSet := make(map[string]bool, len(fields))
	for _, f := range fields {
		fieldSet[f] = true
	}

	// Try direct map assertion
	if m, ok := data.(map[string]interface{}); ok {
		return filterMap(m, fieldSet)
	}

	// Try direct slice of maps
	if items, ok := data.([]map[string]interface{}); ok {
		result := make([]map[string]interface{}, len(items))
		for i, item := range items {
			result[i] = filterMap(item, fieldSet)
		}
		return result
	}

	// Try slice of interface{}
	if items, ok := data.([]interface{}); ok {
		result := make([]interface{}, len(items))
		for i, item := range items {
			if m, ok := item.(map[string]interface{}); ok {
				result[i] = filterMap(m, fieldSet)
			} else {
				result[i] = filterViaJSON(item, fieldSet)
			}
		}
		return result
	}

	// Fallback: JSON round-trip for structs and typed slices
	return filterViaJSON(data, fieldSet)
}

// FilterColumns returns a subset of columns matching the specified field names.
// If fields is nil or empty, all columns are returned.
func FilterColumns(columns []Column, fields []string) []Column {
	if len(fields) == 0 {
		return columns
	}

	fieldSet := make(map[string]bool, len(fields))
	for _, f := range fields {
		fieldSet[f] = true
	}

	var filtered []Column
	for _, col := range columns {
		if fieldSet[col.Field] {
			filtered = append(filtered, col)
		}
	}

	// If no columns matched, warn and return original to avoid empty output
	if len(filtered) == 0 {
		fmt.Fprintf(os.Stderr, "Warning: no columns matched fields [%s]; showing all columns\n",
			strings.Join(fields, ", "))
		return columns
	}
	return filtered
}

func filterMap(m map[string]interface{}, fieldSet map[string]bool) map[string]interface{} {
	result := make(map[string]interface{}, len(fieldSet))
	for field := range fieldSet {
		if strings.Contains(field, ".") {
			// Dot-notation: traverse nested maps (e.g., "status.connection").
			if val, ok := getNestedValue(m, field); ok {
				result[field] = val
			}
		} else {
			if val, ok := m[field]; ok {
				result[field] = val
			}
		}
	}
	return result
}

// getNestedValue traverses nested map[string]interface{} using a dot-separated
// path (e.g., "status.connection" looks up m["status"]["connection"]).
func getNestedValue(m map[string]interface{}, path string) (interface{}, bool) {
	parts := strings.Split(path, ".")
	var current interface{} = m
	for _, part := range parts {
		cm, ok := current.(map[string]interface{})
		if !ok {
			return nil, false
		}
		current, ok = cm[part]
		if !ok {
			return nil, false
		}
	}
	return current, true
}

func filterViaJSON(data interface{}, fieldSet map[string]bool) interface{} {
	b, err := json.Marshal(data)
	if err != nil {
		return data
	}

	// Try as array
	var items []map[string]interface{}
	if err := json.Unmarshal(b, &items); err == nil {
		result := make([]map[string]interface{}, len(items))
		for i, item := range items {
			result[i] = filterMap(item, fieldSet)
		}
		return result
	}

	// Try as single object
	var m map[string]interface{}
	if err := json.Unmarshal(b, &m); err == nil {
		return filterMap(m, fieldSet)
	}

	// Not filterable, return as-is
	return data
}
