package output

import (
	"bytes"
	"encoding/json"
	"os"
	"strings"
	"testing"
)

// ---------------------------------------------------------------------------
// JSONFormatter
// ---------------------------------------------------------------------------

func TestJSONFormatter_FormatSingle(t *testing.T) {
	var buf bytes.Buffer
	f := New("json", &buf)

	data := map[string]string{"id": "123", "status": "connected"}
	if err := f.FormatSingle(data); err != nil {
		t.Fatalf("FormatSingle error: %v", err)
	}

	// Output should be valid JSON
	var parsed map[string]string
	if err := json.Unmarshal(buf.Bytes(), &parsed); err != nil {
		t.Fatalf("output is not valid JSON: %v\nGot: %s", err, buf.String())
	}
	if parsed["id"] != "123" {
		t.Errorf("expected id=123, got %s", parsed["id"])
	}
	if parsed["status"] != "connected" {
		t.Errorf("expected status=connected, got %s", parsed["status"])
	}
}

func TestJSONFormatter_FormatArray(t *testing.T) {
	var buf bytes.Buffer
	f := New("json", &buf)

	data := []map[string]string{
		{"id": "1", "name": "Device A"},
		{"id": "2", "name": "Device B"},
	}
	columns := []Column{
		{Name: "ID", Field: "id"},
		{Name: "Name", Field: "name"},
	}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	// JSON formatter ignores columns and outputs the full data
	var parsed []map[string]string
	if err := json.Unmarshal(buf.Bytes(), &parsed); err != nil {
		t.Fatalf("output is not valid JSON array: %v\nGot: %s", err, buf.String())
	}
	if len(parsed) != 2 {
		t.Errorf("expected 2 items, got %d", len(parsed))
	}
	if parsed[0]["name"] != "Device A" {
		t.Errorf("expected first name=Device A, got %s", parsed[0]["name"])
	}
}

func TestJSONFormatter_FormatSingleStruct(t *testing.T) {
	var buf bytes.Buffer
	f := New("json", &buf)

	type device struct {
		ID     string `json:"id"`
		Status string `json:"status"`
	}
	data := device{ID: "abc", Status: "connected"}
	if err := f.FormatSingle(data); err != nil {
		t.Fatalf("FormatSingle error: %v", err)
	}

	var parsed map[string]string
	if err := json.Unmarshal(buf.Bytes(), &parsed); err != nil {
		t.Fatalf("output is not valid JSON: %v", err)
	}
	if parsed["id"] != "abc" {
		t.Errorf("expected id=abc, got %s", parsed["id"])
	}
}

// ---------------------------------------------------------------------------
// TableFormatter
// ---------------------------------------------------------------------------

func TestTableFormatter_Format(t *testing.T) {
	// Disable color for deterministic output
	os.Setenv("NO_COLOR", "1")
	defer os.Unsetenv("NO_COLOR")

	var buf bytes.Buffer
	f := New("table", &buf)

	data := []map[string]interface{}{
		{"id": "1", "name": "Device A", "status": "connected"},
		{"id": "2", "name": "Device B", "status": "disconnected"},
	}
	columns := []Column{
		{Name: "ID", Field: "id"},
		{Name: "NAME", Field: "name"},
		{Name: "STATUS", Field: "status"},
	}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	out := buf.String()
	// Should contain headers
	if !strings.Contains(out, "ID") {
		t.Error("expected output to contain header ID")
	}
	if !strings.Contains(out, "NAME") {
		t.Error("expected output to contain header NAME")
	}
	if !strings.Contains(out, "STATUS") {
		t.Error("expected output to contain header STATUS")
	}
	// Should contain data values
	if !strings.Contains(out, "Device A") {
		t.Error("expected output to contain 'Device A'")
	}
	if !strings.Contains(out, "disconnected") {
		t.Error("expected output to contain 'disconnected'")
	}
}

func TestTableFormatter_FormatEmpty(t *testing.T) {
	os.Setenv("NO_COLOR", "1")
	defer os.Unsetenv("NO_COLOR")

	var buf bytes.Buffer
	f := New("table", &buf)

	data := []map[string]interface{}{}
	columns := []Column{{Name: "ID", Field: "id"}}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	// "No results found." should go to stderr, not stdout.
	// The stdout buffer should be empty.
	if buf.Len() != 0 {
		t.Errorf("expected empty stdout for no results, got: %s", buf.String())
	}
}

func TestTableFormatter_FormatSingle(t *testing.T) {
	var buf bytes.Buffer
	f := New("table", &buf)

	data := map[string]string{"id": "123", "status": "ok"}
	if err := f.FormatSingle(data); err != nil {
		t.Fatalf("FormatSingle error: %v", err)
	}

	// TableFormatter.FormatSingle outputs JSON
	var parsed map[string]string
	if err := json.Unmarshal(buf.Bytes(), &parsed); err != nil {
		t.Fatalf("expected valid JSON from FormatSingle: %v\nGot: %s", err, buf.String())
	}
	if parsed["id"] != "123" {
		t.Errorf("expected id=123, got %s", parsed["id"])
	}
}

func TestTableFormatter_FormatWithStructSlice(t *testing.T) {
	os.Setenv("NO_COLOR", "1")
	defer os.Unsetenv("NO_COLOR")

	var buf bytes.Buffer
	f := New("table", &buf)

	type item struct {
		ID   string `json:"id"`
		Name string `json:"name"`
	}
	data := []item{
		{ID: "1", Name: "Alpha"},
		{ID: "2", Name: "Beta"},
	}
	columns := []Column{
		{Name: "ID", Field: "id"},
		{Name: "NAME", Field: "name"},
	}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	out := buf.String()
	if !strings.Contains(out, "Alpha") {
		t.Errorf("expected 'Alpha' in output, got: %s", out)
	}
	if !strings.Contains(out, "Beta") {
		t.Errorf("expected 'Beta' in output, got: %s", out)
	}
}

// ---------------------------------------------------------------------------
// QuietFormatter
// ---------------------------------------------------------------------------

func TestQuietFormatter_FormatSingle_ExtractsPrimaryField(t *testing.T) {
	var buf bytes.Buffer
	f := New("quiet", &buf)

	// "id" is a primary field in the priority list
	data := map[string]interface{}{"id": "abc-123", "name": "test"}
	if err := f.FormatSingle(data); err != nil {
		t.Fatalf("FormatSingle error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "abc-123" {
		t.Errorf("expected 'abc-123', got %q", got)
	}
}

func TestQuietFormatter_FormatSingle_MessageID(t *testing.T) {
	var buf bytes.Buffer
	f := New("quiet", &buf)

	// "message_id" has higher priority than "id"
	data := map[string]interface{}{"message_id": "msg-456", "id": "other"}
	if err := f.FormatSingle(data); err != nil {
		t.Fatalf("FormatSingle error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "msg-456" {
		t.Errorf("expected 'msg-456', got %q", got)
	}
}

func TestQuietFormatter_FormatSingle_Status(t *testing.T) {
	var buf bytes.Buffer
	f := New("quiet", &buf)

	data := map[string]interface{}{"status": "connected"}
	if err := f.FormatSingle(data); err != nil {
		t.Fatalf("FormatSingle error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "connected" {
		t.Errorf("expected 'connected', got %q", got)
	}
}

func TestQuietFormatter_Format_WithColumns(t *testing.T) {
	var buf bytes.Buffer
	f := New("quiet", &buf)

	data := []map[string]interface{}{
		{"id": "1", "name": "Alpha"},
		{"id": "2", "name": "Beta"},
		{"id": "3", "name": "Gamma"},
	}
	// Quiet mode with columns extracts the first column's field
	columns := []Column{
		{Name: "ID", Field: "id"},
		{Name: "Name", Field: "name"},
	}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	lines := strings.Split(strings.TrimSpace(buf.String()), "\n")
	if len(lines) != 3 {
		t.Fatalf("expected 3 lines, got %d: %v", len(lines), lines)
	}
	if lines[0] != "1" {
		t.Errorf("line 0: expected '1', got %q", lines[0])
	}
	if lines[1] != "2" {
		t.Errorf("line 1: expected '2', got %q", lines[1])
	}
	if lines[2] != "3" {
		t.Errorf("line 2: expected '3', got %q", lines[2])
	}
}

func TestQuietFormatter_Format_NoColumns(t *testing.T) {
	var buf bytes.Buffer
	f := New("quiet", &buf)

	// When columns is empty, QuietFormatter.Format delegates to FormatSingle
	data := map[string]interface{}{"id": "solo-id"}
	if err := f.Format(data, nil); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "solo-id" {
		t.Errorf("expected 'solo-id', got %q", got)
	}
}

func TestQuietFormatter_FormatSingle_MapStringString(t *testing.T) {
	var buf bytes.Buffer
	f := New("quiet", &buf)

	// Test with map[string]string (direct type assertion path)
	data := map[string]string{"status": "ok", "name": "test"}
	if err := f.FormatSingle(data); err != nil {
		t.Fatalf("FormatSingle error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "ok" {
		t.Errorf("expected 'ok', got %q", got)
	}
}

// ---------------------------------------------------------------------------
// New() factory / AutoDetect
// ---------------------------------------------------------------------------

func TestNew_ReturnsCorrectType(t *testing.T) {
	var buf bytes.Buffer

	formats := []string{"json", "quiet", "table", "", "unknown"}
	for _, format := range formats {
		f := New(format, &buf)
		if f == nil {
			t.Errorf("New(%q) returned nil", format)
		}
	}
}

func TestAutoDetect_JsonFlag(t *testing.T) {
	got := AutoDetect(true, false)
	if got != "json" {
		t.Errorf("expected 'json', got %q", got)
	}
}

func TestAutoDetect_QuietFlag(t *testing.T) {
	got := AutoDetect(false, true)
	if got != "quiet" {
		t.Errorf("expected 'quiet', got %q", got)
	}
}

func TestAutoDetect_JsonTakesPrecedence(t *testing.T) {
	got := AutoDetect(true, true)
	if got != "json" {
		t.Errorf("expected 'json' to take precedence, got %q", got)
	}
}

// ---------------------------------------------------------------------------
// Improvement #6: JSON empty array
// ---------------------------------------------------------------------------

func TestJSONFormatter_FormatNilSlice(t *testing.T) {
	var buf bytes.Buffer
	f := New("json", &buf)

	var data []map[string]interface{} // nil slice
	columns := []Column{{Name: "ID", Field: "id"}}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "[]" {
		t.Errorf("expected '[]' for nil slice, got: %s", got)
	}
}

func TestJSONFormatter_FormatNilData(t *testing.T) {
	var buf bytes.Buffer
	f := New("json", &buf)

	if err := f.Format(nil, nil); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "[]" {
		t.Errorf("expected '[]' for nil data, got: %s", got)
	}
}

func TestJSONFormatter_FormatEmptySlice(t *testing.T) {
	var buf bytes.Buffer
	f := New("json", &buf)

	data := []map[string]interface{}{}
	columns := []Column{{Name: "ID", Field: "id"}}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	got := strings.TrimSpace(buf.String())
	if got != "[]" {
		t.Errorf("expected '[]' for empty slice, got: %s", got)
	}
}

// ---------------------------------------------------------------------------
// Improvement #6: Quiet empty output
// ---------------------------------------------------------------------------

func TestQuietFormatter_FormatNilSlice(t *testing.T) {
	var buf bytes.Buffer
	f := New("quiet", &buf)

	var data []map[string]interface{}
	columns := []Column{{Name: "ID", Field: "id"}}

	if err := f.Format(data, columns); err != nil {
		t.Fatalf("Format error: %v", err)
	}

	if buf.Len() != 0 {
		t.Errorf("expected empty output for nil slice, got: %s", buf.String())
	}
}

// ---------------------------------------------------------------------------
// Improvement #8: FilterFields
// ---------------------------------------------------------------------------

func TestFilterFields_Map(t *testing.T) {
	data := map[string]interface{}{
		"id":     "123",
		"name":   "Alpha",
		"status": "ok",
		"extra":  "ignored",
	}

	result := FilterFields(data, []string{"id", "status"})
	m, ok := result.(map[string]interface{})
	if !ok {
		t.Fatalf("expected map[string]interface{}, got %T", result)
	}
	if len(m) != 2 {
		t.Errorf("expected 2 fields, got %d: %v", len(m), m)
	}
	if m["id"] != "123" {
		t.Errorf("expected id=123, got %v", m["id"])
	}
	if m["status"] != "ok" {
		t.Errorf("expected status=ok, got %v", m["status"])
	}
	if _, exists := m["extra"]; exists {
		t.Error("field 'extra' should have been filtered out")
	}
}

func TestFilterFields_SliceOfMaps(t *testing.T) {
	data := []map[string]interface{}{
		{"id": "1", "name": "Alpha", "extra": "x"},
		{"id": "2", "name": "Beta", "extra": "y"},
	}

	result := FilterFields(data, []string{"id", "name"})
	items, ok := result.([]map[string]interface{})
	if !ok {
		t.Fatalf("expected []map[string]interface{}, got %T", result)
	}
	if len(items) != 2 {
		t.Fatalf("expected 2 items, got %d", len(items))
	}
	if _, exists := items[0]["extra"]; exists {
		t.Error("field 'extra' should have been filtered out")
	}
	if items[1]["name"] != "Beta" {
		t.Errorf("expected name=Beta, got %v", items[1]["name"])
	}
}

func TestFilterFields_Struct(t *testing.T) {
	type device struct {
		ID     string `json:"id"`
		Name   string `json:"name"`
		Status string `json:"status"`
	}
	data := device{ID: "abc", Name: "Test", Status: "ok"}

	result := FilterFields(data, []string{"id", "status"})
	m, ok := result.(map[string]interface{})
	if !ok {
		t.Fatalf("expected map[string]interface{}, got %T", result)
	}
	if m["id"] != "abc" {
		t.Errorf("expected id=abc, got %v", m["id"])
	}
	if _, exists := m["name"]; exists {
		t.Error("field 'name' should have been filtered out")
	}
}

func TestFilterFields_StructSlice(t *testing.T) {
	type device struct {
		ID     string `json:"id"`
		Name   string `json:"name"`
		Status string `json:"status"`
	}
	data := []device{
		{ID: "1", Name: "A", Status: "ok"},
		{ID: "2", Name: "B", Status: "err"},
	}

	result := FilterFields(data, []string{"id"})
	items, ok := result.([]map[string]interface{})
	if !ok {
		t.Fatalf("expected []map[string]interface{}, got %T", result)
	}
	if len(items) != 2 {
		t.Fatalf("expected 2 items, got %d", len(items))
	}
	if len(items[0]) != 1 {
		t.Errorf("expected 1 field per item, got %d: %v", len(items[0]), items[0])
	}
}

func TestFilterFields_NilFields(t *testing.T) {
	data := map[string]interface{}{"id": "123", "name": "test"}
	result := FilterFields(data, nil)
	// Should return data unchanged
	m, ok := result.(map[string]interface{})
	if !ok {
		t.Fatalf("expected map[string]interface{}, got %T", result)
	}
	if len(m) != 2 {
		t.Errorf("nil fields should return all fields, got %d", len(m))
	}
}

func TestFilterFields_EmptyFields(t *testing.T) {
	data := map[string]interface{}{"id": "123"}
	result := FilterFields(data, []string{})
	m, ok := result.(map[string]interface{})
	if !ok {
		t.Fatalf("expected map[string]interface{}, got %T", result)
	}
	if len(m) != 1 {
		t.Errorf("empty fields should return all fields, got %d", len(m))
	}
}

func TestFilterFields_NilData(t *testing.T) {
	result := FilterFields(nil, []string{"id"})
	if result != nil {
		t.Errorf("expected nil for nil data, got %v", result)
	}
}

// ---------------------------------------------------------------------------
// Improvement #8: FilterColumns
// ---------------------------------------------------------------------------

func TestFilterColumns_SubsetMatch(t *testing.T) {
	columns := []Column{
		{Name: "ID", Field: "id"},
		{Name: "NAME", Field: "name"},
		{Name: "STATUS", Field: "status"},
	}

	filtered := FilterColumns(columns, []string{"id", "status"})
	if len(filtered) != 2 {
		t.Fatalf("expected 2 columns, got %d", len(filtered))
	}
	if filtered[0].Field != "id" {
		t.Errorf("expected first column field=id, got %s", filtered[0].Field)
	}
	if filtered[1].Field != "status" {
		t.Errorf("expected second column field=status, got %s", filtered[1].Field)
	}
}

func TestFilterColumns_NilFields(t *testing.T) {
	columns := []Column{
		{Name: "ID", Field: "id"},
		{Name: "NAME", Field: "name"},
	}

	filtered := FilterColumns(columns, nil)
	if len(filtered) != 2 {
		t.Errorf("nil fields should return all columns, got %d", len(filtered))
	}
}

func TestFilterColumns_NoMatch(t *testing.T) {
	columns := []Column{
		{Name: "ID", Field: "id"},
		{Name: "NAME", Field: "name"},
	}

	// No matching fields — should return original columns as fallback
	filtered := FilterColumns(columns, []string{"nonexistent"})
	if len(filtered) != 2 {
		t.Errorf("no-match should return original columns, got %d", len(filtered))
	}
}
