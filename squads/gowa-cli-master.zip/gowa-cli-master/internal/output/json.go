package output

import (
	"encoding/json"
	"fmt"
	"io"
	"reflect"
)

// JSONFormatter outputs data as JSON.
type JSONFormatter struct {
	w io.Writer
}

// Format marshals data as a pretty-printed JSON array.
// For nil or empty slices, outputs "[]" instead of "null".
func (f *JSONFormatter) Format(data interface{}, columns []Column) error {
	// Ensure nil/empty slices render as [] not null
	if data == nil {
		_, err := fmt.Fprintln(f.w, "[]")
		return err
	}
	v := reflect.ValueOf(data)
	if v.Kind() == reflect.Slice && v.IsNil() {
		_, err := fmt.Fprintln(f.w, "[]")
		return err
	}

	b, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return err
	}
	_, err = fmt.Fprintln(f.w, string(b))
	return err
}

// FormatSingle marshals data as a pretty-printed JSON object.
func (f *JSONFormatter) FormatSingle(data interface{}) error {
	b, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return err
	}
	_, err = fmt.Fprintln(f.w, string(b))
	return err
}
