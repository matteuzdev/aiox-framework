package output

import (
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"os"
	"reflect"
	"strings"
	"text/tabwriter"

	"github.com/fatih/color"
)

// TableFormatter renders data as a human-readable aligned table using text/tabwriter.
//
// Known limitation: tabwriter calculates column widths using byte length, not display
// width. Unicode characters that occupy more than one terminal cell (e.g., CJK ideographs,
// some emoji) will cause column misalignment. A future improvement could use
// github.com/mattn/go-runewidth to compute accurate display widths and pad accordingly.
type TableFormatter struct {
	w io.Writer
}

func (f *TableFormatter) Format(data interface{}, columns []Column) error {
	// Respect NO_COLOR env var without mutating global state
	if os.Getenv("NO_COLOR") != "" {
		color.NoColor = true
	}

	rows, err := toRows(data, columns)
	if err != nil {
		return err
	}

	if len(rows) == 0 {
		fmt.Fprintln(os.Stderr, "No results found.")
		return nil
	}

	tw := tabwriter.NewWriter(f.w, 0, 0, 2, ' ', 0)

	headers := make([]string, len(columns))
	for i, c := range columns {
		headers[i] = c.Name
	}
	bold := color.New(color.Bold)
	bold.Fprintln(tw, strings.Join(headers, "\t"))

	for _, row := range rows {
		fmt.Fprintln(tw, strings.Join(row, "\t"))
	}

	return tw.Flush()
}

// FormatSingle outputs a single object as JSON even in table mode.
// This is intentional: key-value table rendering is not implemented,
// and JSON provides a clear, parseable fallback for single-object output.
func (f *TableFormatter) FormatSingle(data interface{}) error {
	b, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return err
	}
	_, err = fmt.Fprintln(f.w, string(b))
	return err
}

func toRows(data interface{}, columns []Column) ([][]string, error) {
	b, err := json.Marshal(data)
	if err != nil {
		return nil, err
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(b, &items); err != nil {
		v := reflect.ValueOf(data)
		if v.Kind() == reflect.Slice {
			for i := 0; i < v.Len(); i++ {
				itemBytes, err := json.Marshal(v.Index(i).Interface())
				if err != nil {
					return nil, fmt.Errorf("failed to marshal item %d: %w", i, err)
				}
				var m map[string]interface{}
				if err := json.Unmarshal(itemBytes, &m); err != nil {
					return nil, fmt.Errorf("failed to parse item %d: %w", i, err)
				}
				items = append(items, m)
			}
		} else {
			var single map[string]interface{}
			if err := json.Unmarshal(b, &single); err != nil {
				return nil, err
			}
			items = []map[string]interface{}{single}
		}
	}

	var rows [][]string
	for _, item := range items {
		row := make([]string, len(columns))
		for i, col := range columns {
			if val, ok := item[col.Field]; ok {
				row[i] = fmt.Sprintf("%v", val)
			} else {
				slog.Debug("table: missing field in data row", "field", col.Field)
			}
		}
		rows = append(rows, row)
	}
	return rows, nil
}
