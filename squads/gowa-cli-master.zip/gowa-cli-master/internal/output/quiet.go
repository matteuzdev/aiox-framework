package output

import (
	"encoding/json"
	"fmt"
	"io"
	"reflect"
	"sort"
)

type QuietFormatter struct {
	w io.Writer
}

func (f *QuietFormatter) Format(data interface{}, columns []Column) error {
	if len(columns) == 0 {
		return f.FormatSingle(data)
	}

	// No output for nil data
	if data == nil {
		return nil
	}
	v := reflect.ValueOf(data)
	if v.Kind() == reflect.Slice && v.IsNil() {
		return nil
	}

	field := columns[0].Field

	b, err := json.Marshal(data)
	if err != nil {
		return err
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(b, &items); err != nil {
		v := reflect.ValueOf(data)
		if v.Kind() == reflect.Slice {
			for i := 0; i < v.Len(); i++ {
				itemBytes, err := json.Marshal(v.Index(i).Interface())
				if err != nil {
					return fmt.Errorf("failed to marshal item %d: %w", i, err)
				}
				var m map[string]interface{}
				if err := json.Unmarshal(itemBytes, &m); err != nil {
					return fmt.Errorf("failed to parse item %d: %w", i, err)
				}
				items = append(items, m)
			}
		} else {
			var single map[string]interface{}
			if err := json.Unmarshal(b, &single); err != nil {
				return err
			}
			items = []map[string]interface{}{single}
		}
	}

	for _, item := range items {
		if val, ok := item[field]; ok {
			fmt.Fprintln(f.w, val)
		}
	}
	return nil
}

func (f *QuietFormatter) FormatSingle(data interface{}) error {
	// Try to extract a primary field from map-like data
	if m, ok := toMapSingle(data); ok {
		for _, key := range []string{"message_id", "id", "status", "authenticated", "cli_version"} {
			if val, exists := m[key]; exists {
				_, err := fmt.Fprintln(f.w, val)
				return err
			}
		}
		// Fallback: first value (sorted keys for deterministic output)
		keys := make([]string, 0, len(m))
		for k := range m {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		if len(keys) > 0 {
			_, err := fmt.Fprintln(f.w, m[keys[0]])
			return err
		}
	}
	_, err := fmt.Fprintln(f.w, data)
	return err
}

// toMapSingle converts data to map[string]interface{} via JSON round-trip.
func toMapSingle(data interface{}) (map[string]interface{}, bool) {
	// Direct type assertions first
	if m, ok := data.(map[string]interface{}); ok {
		return m, true
	}
	if m, ok := data.(map[string]string); ok {
		result := make(map[string]interface{}, len(m))
		for k, v := range m {
			result[k] = v
		}
		return result, true
	}
	// JSON round-trip for structs
	b, err := json.Marshal(data)
	if err != nil {
		return nil, false
	}
	var m map[string]interface{}
	if err := json.Unmarshal(b, &m); err != nil {
		return nil, false
	}
	return m, true
}
