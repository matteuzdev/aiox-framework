---
name: Feature Request
about: Suggest a new feature for GOWA CLI
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## Problem

What problem does this feature solve? What's frustrating or missing?

## Proposed Solution

Describe how you'd like this to work. Include example commands if possible:

```bash
gowa example-command --new-flag value
```

## Alternatives Considered

Any alternative solutions or workarounds you've considered.

## Additional Context

Any other context, screenshots, or references.
