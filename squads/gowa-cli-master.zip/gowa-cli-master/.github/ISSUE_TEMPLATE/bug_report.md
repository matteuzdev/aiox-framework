---
name: Bug Report
about: Report a bug in GOWA CLI
title: "[BUG] "
labels: bug
assignees: ''
---

## Description

A clear description of the bug.

## Steps to Reproduce

1. Run `gowa ...`
2. ...
3. See error

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened. Include error output.

## Environment

- **gowa version:** (`gowa version --json`)
- **OS:** (e.g., Ubuntu 24.04, macOS 15, Windows 11)
- **Go version:** (`go version`)
- **GOWA server version:** (if known)

## Logs / Output

```
Paste relevant output here
```

## Additional Context

Any other context about the problem.
