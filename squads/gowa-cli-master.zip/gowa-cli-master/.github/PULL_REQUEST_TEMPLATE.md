## Summary

Brief description of the changes.

## Type

- [ ] `feat` — New feature
- [ ] `fix` — Bug fix
- [ ] `docs` — Documentation
- [ ] `test` — Tests
- [ ] `chore` — Maintenance

## Changes

-

## Checklist

- [ ] `go build ./...` compiles
- [ ] `go vet ./...` passes
- [ ] `go test ./...` passes
- [ ] Safety rules followed (rate limiter, validation, audit)
- [ ] Documentation updated (if applicable)
- [ ] No secrets or credentials committed
